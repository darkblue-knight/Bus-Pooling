package com.guet.core;

public class LBSTraceClient {

    private static LBSTraceClient instance = new LBSTraceClient();

    private LBSTraceClient() {
    }

    /**
     * 初始化Client
     */
    public void init() {
        AsyncRequestClient.getInstance().init();
        //uploadListeners = new ArrayList<OnUploadListener>();
    }

    /**
     * 开启Client
     */
    public void start() {
        AsyncRequestClient.getInstance().start();
    }

    /**
     * 停止Client
     */
    public void stop() {
        AsyncRequestClient.getInstance().stop();
    }

    /**
     * 销毁Client
     */
    public void destory() {
        AsyncRequestClient.getInstance().destroy();
    }

    /**
     * 设置并发数，默认5000（单位：次/每分钟）
     *
     * @param concurrency
     * @return
     */
    public boolean setConcurrency(int concurrency) {
        if (concurrency <= 0) {
            return false;
        }
        AsyncRequestClient.getInstance().setConcurrency(concurrency);
        return true;
    }

    /**
     * 开启HTTPS
     */
    public void enableHttps(boolean enable) {
        HttpClient.isEnableHttps = enable;
    }

    /**
     * 获取轨迹客户端实例
     *
     * @return
     */
    public static LBSTraceClient getInstance() {
        if (null == instance) {
            synchronized (LBSTraceClient.class) {
                if (null == instance) {
                    instance = new LBSTraceClient();
                    instance.init();
                }
            }
        }
        return instance;
    }
}
