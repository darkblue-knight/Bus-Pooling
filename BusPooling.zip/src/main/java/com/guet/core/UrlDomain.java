package com.guet.core;

/**
 * url域名
 *
 * @author baidu
 *
 */
public class UrlDomain {

    public static final String BAIDU_MAP_API_ROUTEMATRIX_HTTP_URL = "https://api.map.baidu.com/routematrix/v2/";

    public static final String BAIDU_MAP_API_ROUTEMATRIX_HTTPS_URL = "https://api.map.baidu.com/routematrix/v2/";

    public static final String BAIDU_MAP_API_PARKING_HTTP_URL = "http://api.map.baidu.com/parking/";

    public static final String BAIDU_MAP_API_DIRECTION_HTTP_URL = "http://api.map.baidu.com/direction/v2/";

    public static final String BAIDU_MAP_API_PLACE_HTTP_URL = "http://api.map.baidu.com/place/v2/";

    public static final String ACTION_DRIVING = "driving";

    public static final String ACTION_RIDING = "riding";

    public static final String ACTION_WALKING = "walking";

    public static final String ACTION_SEARCH = "search";
}
