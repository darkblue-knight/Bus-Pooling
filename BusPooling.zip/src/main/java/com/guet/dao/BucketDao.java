package com.guet.dao;

import org.apache.ibatis.annotations.Param;
import com.guet.entity.Bucket;

import java.util.List;

public interface BucketDao {

    boolean add(List<Bucket> list);

    boolean update(@Param("id") String id, @Param("s_distance") int s_distance, @Param("s_duration") int s_duration, @Param("d_distance") int d_distance, @Param("d_duration") int d_duration, @Param("riding_distance") int riding_distance, @Param("riding_duration") int riding_duration, @Param("driving_distance") int driving_distance, @Param("driving_duration") int driving_duration);

    List<Bucket> queryAll(@Param("code") int code);

    int queryExist(@Param("code") int code, @Param("bus_share_id") String bus_share_id);

    int queryBucketNo();

    List<Bucket> queryUpdateBucketNo();
}
