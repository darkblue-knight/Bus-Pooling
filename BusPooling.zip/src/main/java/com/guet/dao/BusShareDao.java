package com.guet.dao;

import java.util.LinkedList;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.guet.entity.*;


public interface BusShareDao {

    boolean add(List<BusShare> list);
    /**
     * 统计记录总数
     *
     * @return
     */
    int queryCount();

    List<BusShare> getList();

    List<BusShare> getAll();

    Scope getScope();

    /**
     * 查询所有乘车需求
     *
     * @param offset 查询起始位置
     * @param limit  查询条数
     * @return
     */
    List<BusShare> queryAll(@Param("offset") int offset, @Param("limit") int limit);

    BusShare queryNext(@Param("offset") int offset);

    List<BusShare> queryBucket(@Param("code") int code);

    LinkedList<BusShare> queryList(@Param("PageSize") int PageSize, @Param("PageCount") int PageCount);

    BusShare getModel(@Param("id") String id);
    /**
     * 删除一条记录
     *
     * @return
     */
    boolean delete(List<BusShare> list);
}