package com.guet.dao;

import com.guet.entity.BusStation;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface BusStationDao {
    int queryCount();

    int queryExist(@Param("id") String id);

    boolean add(List<BusStation> list);

    List<BusStation> getList();
}
