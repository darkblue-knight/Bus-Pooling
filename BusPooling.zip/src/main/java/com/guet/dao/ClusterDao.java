package com.guet.dao;

import com.guet.entity.Clustering;

import java.util.List;

public interface ClusterDao {

    boolean add(List<Clustering> list);
}
