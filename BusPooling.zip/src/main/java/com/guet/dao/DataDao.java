package com.guet.dao;

import com.guet.entity.Data;
import com.guet.entity.Trip;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface DataDao {

    boolean add(List<Data> list);

    List<Integer> queryCode();

    List<Data> getModel(@Param("code") int code);
}
