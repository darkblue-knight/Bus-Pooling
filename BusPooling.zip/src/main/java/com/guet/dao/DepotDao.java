package com.guet.dao;

import com.guet.entity.Location;
import org.apache.ibatis.annotations.Param;

import java.util.List;


public interface DepotDao {

    List<Location> queryAll();

    List<Location> queryStation();

    List<Location> queryClusters(@Param("code") int code);

    List<Location> queryAllClusters();
}
