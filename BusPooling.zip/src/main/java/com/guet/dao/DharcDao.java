package com.guet.dao;

import com.guet.entity.Arc;
import com.guet.entity.Routes;
import org.apache.ibatis.annotations.Param;

import java.sql.Time;
import java.util.LinkedList;
import java.util.List;


public interface DharcDao {

    int queryExist(@Param("s_id") String s_id, @Param("d_id") String d_id);

    boolean add(List<Arc> list);

    boolean update(Arc model);

    boolean updateCost(@Param("id") String id, @Param("cost") Double cost);

    LinkedList<Arc> queryAll();

    Arc getModel(@Param("s_id") String s_id);

    int queryCount();

    LinkedList<Arc> getList(@Param("PageSize") int PageSize, @Param("PageCount") int PageCount);

    boolean delete(List<String> list);

    List<Integer> queryArcNum(Time departureDt);
}
