package com.guet.dao;

import com.guet.entity.Edge;

import java.util.List;

public interface EdgeDao {

    List<Edge> queryAll();

}
