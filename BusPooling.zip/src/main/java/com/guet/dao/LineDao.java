package com.guet.dao;

import com.guet.entity.Line;

import java.util.List;

public interface LineDao {

    List<Line> queryAll();

    boolean update(Line model);
}
