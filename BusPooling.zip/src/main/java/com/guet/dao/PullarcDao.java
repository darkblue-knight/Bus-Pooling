package com.guet.dao;

import com.guet.entity.Arc;
import org.apache.ibatis.annotations.Param;

import java.util.LinkedList;
import java.util.List;


public interface PullarcDao {

    boolean add(List<Arc> list);

    boolean update(Arc model);

    boolean updateCost(@Param("id") String id, @Param("cost") Double cost);

    LinkedList<Arc> queryAll();

    Arc getModel(@Param("s_id") String s_id);
}
