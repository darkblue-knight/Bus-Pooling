package com.guet.dao;

import com.guet.entity.Routes;

import java.util.List;

public interface RoutesDao {
    int queryCount();

    boolean add(List<Routes> list);

    List<Routes> getList();
}
