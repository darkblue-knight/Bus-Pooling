package com.guet.dao;

import com.guet.entity.Sequence;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface SequenceDao {

    boolean truncate();

    boolean add(List<Sequence> list);

    int queryExist(@Param("code") int code, @Param("trip_id") String trip_id);

    int querySequenceNo();

    List<Sequence> queryAll(@Param("code") int code);
}
