package com.guet.dao;

import com.guet.entity.RecommendStops;
import org.apache.ibatis.annotations.Param;

import java.util.List;


public interface StopDao {
    boolean add(RecommendStops model);

    boolean updateOrig(@Param("id") String id, @Param("s_lng") double s_lng, @Param("s_lat") double s_lat);

    boolean updateDest(@Param("id") String id, @Param("d_lng") double d_lng, @Param("d_lat") double d_lat);

    boolean updateDistance(@Param("id") String id, @Param("distance") int distance, @Param("duration") int duration);

    List<RecommendStops> queryAll();

    RecommendStops getModel(@Param("code") int code);
}
