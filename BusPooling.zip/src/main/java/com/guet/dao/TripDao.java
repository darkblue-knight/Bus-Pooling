package com.guet.dao;

import com.guet.entity.Arc;
import com.guet.entity.Trip;
import org.apache.ibatis.annotations.Param;

import java.sql.Time;
import java.util.List;


public interface TripDao {

    int queryCount();

    boolean add(Trip model);

    boolean update(Trip model);

    List<Time> getTimetable();

    List<Trip> queryAll();

    List<Trip> querySequence(@Param("code") int code);

    Trip getModel(@Param("id") String id);

    boolean delete(List<String> list);
}
