package com.guet.dao;

import com.guet.entity.Vertex;

import java.util.List;

public interface VertexDao {

    List<Vertex> queryAll();

}
