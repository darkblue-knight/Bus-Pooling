package com.guet.entity;

import java.util.Random;
import java.util.Vector;

public class Ant implements Cloneable {

    private Vector<Integer> tabu; // 禁忌表
    private Vector<Integer> allowedVertexs; // 允许搜索的顶点
    private float[][] delta; // 信息素变化矩阵
    private int[][] distance; // 距离矩阵
    private float alpha;
    private float beta;

    private int tourLength; // 路径长度
    private int VertexNum; // 顶点数量
    private int firstVertex; // 起始顶点
    private int currentVertex; // 当前顶点

    public Ant() {
        VertexNum = 78;
        tourLength = 0;
    }

    /**
     * Constructor of Ant
     *
     * @param num 蚂蚁数量
     */
    public Ant(int num) {
        VertexNum = num;
        tourLength = 0;
    }

    /**
     * 初始化蚂蚁，随机选择起始位置
     *
     * @param distance 距离矩阵
     * @param a        alpha
     * @param b        beta
     */

    public void init(int[][] distance, float a, float b) {
        alpha = a;
        beta = b;
        // 初始允许搜索的顶点集合
        allowedVertexs = new Vector<Integer>();
        // 初始禁忌表
        tabu = new Vector<Integer>();
        // 初始距离矩阵
        this.distance = distance;
        // 初始信息数变化矩阵为0
        delta = new float[VertexNum][VertexNum];
        for (int i = 0; i < VertexNum; i++) {
            Integer integer = new Integer(i);
            allowedVertexs.add(integer);
            for (int j = 0; j < VertexNum; j++) {
                delta[i][j] = 0.f;
            }
        }
        // 随机挑选一个顶点作为起始顶点
        Random random = new Random(System.currentTimeMillis());
        firstVertex = random.nextInt(VertexNum);
        // 允许搜索的顶点集合中移除起始顶点
        for (Integer i : allowedVertexs) {
            if (i.intValue() == firstVertex) {
                allowedVertexs.remove(i);
                break;
            }
        }
        // 将起始顶点添加至禁忌表
        tabu.add(Integer.valueOf(firstVertex));
        // 当前顶点为起始顶点
        currentVertex = firstVertex;
    }

    /**
     * 选择下一个顶点
     *
     * @param pheromone 信息素矩阵
     */

    public void selectNextCity(float[][] pheromone) {
        float[] p = new float[VertexNum];
        float sum = 0.0f;
        // 计算分母部分
        for (Integer i : allowedVertexs) {
            sum += Math.pow(pheromone[currentVertex][i.intValue()], alpha)
                    * Math.pow(1.0 / distance[currentVertex][i.intValue()], beta);
        }
        // 计算概率矩阵
        for (int i = 0; i < VertexNum; i++) {
            boolean flag = false;
            for (Integer j : allowedVertexs) {
                if (i == j.intValue()) {
                    p[i] = (float) (Math.pow(pheromone[currentVertex][i], alpha) * Math
                            .pow(1.0 / distance[currentVertex][i], beta)) / sum;
                    flag = true;
                    break;
                }
            }
            if (flag == false) {
                p[i] = 0.f;
            }
        }
        // 轮盘赌选择下一个顶点
        Random random = new Random(System.currentTimeMillis());
        float sleectP = random.nextFloat();
        int selectCity = 0;
        float sum1 = 0.f;
        for (int i = 0; i < VertexNum; i++) {
            sum1 += p[i];
            if (sum1 >= sleectP) {
                selectCity = i;
                break;
            }
        }
        // 从允许选择的顶点中去除select city
        for (Integer i : allowedVertexs) {
            if (i.intValue() == selectCity) {
                allowedVertexs.remove(i);
                break;
            }
        }
        // 在禁忌表中添加select city
        tabu.add(Integer.valueOf(selectCity));
        // 将当前顶点改为选择的顶点
        currentVertex = selectCity;
    }

    /**
     * 计算路径长度
     *
     * @return 路径长度
     */
    private int calculateTourLength() {
        int len = 0;
        //禁忌表tabu最终形式：起始顶点,顶点1,顶点2...顶点n,起始顶点
        for (int i = 0; i < VertexNum; i++) {
            len += distance[this.tabu.get(i).intValue()][this.tabu.get(i + 1)
                    .intValue()];
        }
        return len;
    }

    public Vector<Integer> getAllowedVertexs() {
        return allowedVertexs;
    }

    public void setAllowedVertexs(Vector<Integer> allowedVertexs) {
        this.allowedVertexs = allowedVertexs;
    }

    public int getTourLength() {
        tourLength = calculateTourLength();
        return tourLength;
    }

    public void setTourLength(int tourLength) {
        this.tourLength = tourLength;
    }

    public int getVertexNum() {
        return VertexNum;
    }

    public void setVertexNum(int VertexNum) {
        this.VertexNum = VertexNum;
    }

    public Vector<Integer> getTabu() {
        return tabu;
    }

    public void setTabu(Vector<Integer> tabu) {
        this.tabu = tabu;
    }

    public float[][] getDelta() {
        return delta;
    }

    public void setDelta(float[][] delta) {
        this.delta = delta;
    }

    public int getFirstVertex() {
        return firstVertex;
    }

    public void setFirstVertex(int firstVertex) {
        this.firstVertex = firstVertex;
    }

}