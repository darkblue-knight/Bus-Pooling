package com.guet.entity;

public class Arc implements Comparable<Arc> {
    private String id;
    private String s_id;
    private String d_id;
    private int distance;
    private int duration;
    private Double cost;
    private double probability;
    private double min;
    private double max;

    public String getId() {
        return id;
    }

    public String getSId() {
        return s_id;
    }

    public String getDId() {
        return d_id;
    }

    public int getDistance() {
        return distance;
    }

    public int getDuration() {
        return duration;
    }

    public Double getCost() {
        return cost;
    }

    public Double getMax() { return max; }

    public Double getMin() {
        return min;
    }

    public Double getProbability() {
        return probability;
    }

    public void setMin(Double min) {
        this.min = min;
    }

    public void setMax(Double max) {
        this.max = max;
    }

    public void setProbability(Double probability) {
        this.probability = probability;
    }

    public Arc(String id, String s_id, String d_id, int distance, int duration, Double cost) {
        this.id = id;
        this.s_id = s_id;
        this.d_id = d_id;
        this.distance = distance;
        this.duration = duration;
        this.cost = cost;
    }

    /*升序排列*/
    @Override
    public int compareTo(Arc arc) {
        return this.cost.compareTo(arc.getCost());
    }
}
