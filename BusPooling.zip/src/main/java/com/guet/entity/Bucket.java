package com.guet.entity;

public class Bucket {

    private String id;//唯一标识
    private int code;//编号
    private int child;//编号
    private String bus_share_id;//乘坐需求ID
    private int s_distance;
    private int s_duration;
    private int d_distance;
    private int d_duration;
    private int riding_distance;
    private int riding_duration;
    private int driving_distance;
    private int driving_duration;

    public Bucket(String id, int code, int child, String bus_share_id, int s_distance,int s_duration,int d_distance,int d_duration, int riding_distance, int riding_duration, int driving_distance, int driving_duration) {
        this.id = id;
        this.code = code;
        this.child = child;
        this.bus_share_id = bus_share_id;
        this.s_distance = s_distance;
        this.s_duration = s_duration;
        this.d_distance = d_distance;
        this.d_duration = d_duration;
        this.riding_distance = riding_distance;
        this.riding_duration = riding_duration;
        this.driving_distance = driving_distance;
        this.driving_duration = driving_duration;
    }

    public String getId() {
        return id;
    }

    public int getCode() {
        return code;
    }

    public int getChild() {
        return child;
    }

    public String getBusShareId() {
        return bus_share_id;
    }
}
