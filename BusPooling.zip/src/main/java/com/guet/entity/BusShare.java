package com.guet.entity;

import java.text.SimpleDateFormat;
import java.util.*;

public class BusShare {

    private String id;//唯一标识
    private String code;//出租车编号
    private String s_dt;//出发时间
    private Double s_lng;//出发经度
    private Double s_lat;//出发维度
    private String d_dt;//到达时间
    private Double d_lng;//到达经度
    private Double d_lat;//到达维度
    private int s_idx;
    private int d_idx;

    public BusShare() { }

    public BusShare(String id,String code,Date s_dt,double s_lng, double s_lat,Date d_dt,double d_lng,double d_lat) {

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm");

        this.id = id;
        this.code = code;
        this.s_dt = formatter.format(s_dt);
        this.s_lng = s_lng;
        this.s_lat = s_lat;
        this.d_dt = formatter.format(d_dt);
        this.d_lng = d_lng;
        this.d_lat = d_lat;
    }

    public String getId(){
        return id;
    };

    public String getCode(){
        return code;
    };

    public Double getSLng() {
        return s_lng;
    }

    public Double getSLat() { return s_lat; }

    public Double getDLng() {
        return d_lng;
    }

    public Double getDLat() {
        return d_lat;
    }

    public int getSIdx() {
        return s_idx;
    }

    public int getDIdx() { return d_idx; }

    public void setSidx(int s_idx) {
        this.s_idx = s_idx;
    }
    public void setDidx(int d_idx) {
        this.d_idx = d_idx;
    }
    @Override
    public String toString() {
        return "[id=" + id + ", s_dt=" + s_dt + ", s_dt=" + s_dt + ", s_idx=" + s_idx + ", s_lng=" + s_lng + ", s_lat=" + s_lat + ",d_dt=" + d_dt + ", d_idx=" + d_idx + ", d_lng=" + d_lng + ", d_lat=" + d_lat + "]";
    }
}

