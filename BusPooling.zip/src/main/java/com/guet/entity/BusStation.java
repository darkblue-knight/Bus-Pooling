package com.guet.entity;

public class BusStation {
    private String id;//唯一标识
    private String name;
    private Double lng;//经度
    private Double lat;//维度
    private String address;

    public BusStation() {
    }

    public BusStation(String id, String name, double lng, double lat, String address) {
        this.id = id;
        this.name = name;
        this.lng = lng;
        this.lat = lat;
        this.address = address;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Double getLat() {
        return lat;
    }

    public Double getLng() {
        return lng;
    }

    public String getAddress() {
        return address;
    }
}