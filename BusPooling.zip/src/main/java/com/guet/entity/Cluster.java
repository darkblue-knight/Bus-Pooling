package com.guet.entity;

public class Cluster implements Comparable<Cluster>{

    BusShare busShare;
    double score;

    public Cluster() {
        super();
    }

    public Cluster(BusShare busShare, double score) {
        this.busShare = busShare;
        this.score = score;
    }

    public BusShare getBusShare() {
        return busShare;
    }
    public double getScore() {
        return score;
    }

    @Override
    public int compareTo(Cluster cluster) {
        if (this.score > cluster.getScore())
            return 1;
        else if(this.score == cluster.getScore())
            return 0;
        else return -1;
    }
}
