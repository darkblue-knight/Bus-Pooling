package com.guet.entity;

public class Clustering {

    private String id;//唯一标识
    private int code;//编号
    private double lng;//经度
    private double lat;//维度

    public Clustering() {
    }

    public Clustering(String id, int code, double lng, double lat) {
        this.id = id;
        this.code = code;
        this.lng = lng;
        this.lat = lat;
    }
}
