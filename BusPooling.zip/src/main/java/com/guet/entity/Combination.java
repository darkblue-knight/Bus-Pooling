package com.guet.entity;

import java.util.List;

public class Combination{

    private List<Integer> codes;
    private List<Travel> list;
    private int capacity;
    private boolean enable;

    public int getCapacity() { return capacity; }
    public int getCodeSize() { return codes.size(); }
    public List<Integer> getCode() { return codes; }
    public List<Travel> getList() { return list; }

    public int getCount() {
        int count = 0;
        for (Travel item : this.list) {
            count += item.getList().size();
        }
        return count;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }
    public void setList(List<Travel> list) {
        this.list = list;
    }
    public boolean getEnable() { return enable; }
    public void setEnable(boolean enable) { this.enable = enable; }

    public Combination() { }

    public Combination(List<Integer> codes) {
        this.codes = codes;
    }
}
