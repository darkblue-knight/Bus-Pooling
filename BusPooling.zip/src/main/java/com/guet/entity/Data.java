package com.guet.entity;

import java.util.Date;

public class Data {

    private int code;//编号
    private Date dt;//时间
    private Double lng;//经度
    private Double lat;//维度
    private int is_carry;//是否载客

    public Data() { }

    public Data(int code, double lat, double lng, int is_carry, Date dt) {
        this.code = code;
        this.dt = dt;
        this.lng = lng;
        this.lat = lat;
        this.is_carry = is_carry;
    }

    public Date getDt() {
        return dt;
    }

    public int getCode() {
        return code;
    }

    public double getLat() {
        return lat;
    }

    public double getLng() {
        return lng;
    }

    public int getiscarry() {
        return is_carry;
    }
}