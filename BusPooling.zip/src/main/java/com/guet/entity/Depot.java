package com.guet.entity;

public class Depot {
    private String id;
    private int code;
    private String name;
    private Double lng;//经度
    private Double lat;//维度

    public String getId() {
        return id;
    }

    public int getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public Double getLng() {
        return lng;
    }

    public Double getLat() {
        return lat;
    }

    public Depot() { }

    public Depot(String id, int code, String name, Double lng, Double lat) {
        this.id = id;
        this.code = code;
        this.name = name;
        this.lng = lng;
        this.lat = lat;
    }
}
