package com.guet.entity;

import java.sql.Time;
import java.util.Date;
import java.util.List;

public class Duty implements Comparable<Duty> {

    private String depot_id;//乘坐需求ID
    List<Trip> trip;
    private int tripsize;
    List<Arc> arc;
    private Date startTime;
    private Date endTime;
    private long duration;
    private Integer waitTime;
    private Integer travelTime;
    private Integer idleTime;
    private Integer travelMileage;
    private Integer idleMileage;
    private Double travelCost;
    private Double idleCost;
    private Double totalCost;

    public Duty() {
        super();
    }

    public String getDepotId() {
        return depot_id;
    }

    public List<Trip> getTrip() {
        return trip;
    }

    public Date getStartTime() {
        return startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public long getDuration() {
        return duration;
    }

    public Integer getWaitTime() {
        return waitTime;
    }

    public Integer getTravelTime() {
        return travelTime;
    }

    public Integer getIdleTime() {
        return idleTime;
    }

    public Integer getTravelMileage() {
        return travelMileage;
    }

    public Integer getIdleMileage() {
        return idleMileage;
    }

    public Double getTravelCost() {
        return travelCost;
    }

    public Double getIdleCost() {
        return idleCost;
    }

    public Double getTotalCost() {
        return totalCost;
    }

    public int getTripSize() {
        return tripsize;
    }

    public Duty(String depot_id, List<Trip> trip, List<Arc> arc, Date start_time, Date end_time, long duration, int waitTime, int travelTime, int idleTime, int travelMileage, int idleMileage, Double travelCost, Double idleCost, Double totalCost) {
        this.depot_id = depot_id;
        this.trip = trip;
        this.tripsize = trip.size();
        this.arc = arc;
        this.startTime = start_time;
        this.endTime = end_time;
        this.duration = duration;
        this.waitTime = waitTime;
        this.travelTime = travelTime;
        this.idleTime = idleTime;
        this.travelMileage = travelMileage;
        this.idleMileage = idleMileage;
        this.travelCost = travelCost;
        this.idleCost = idleCost;
        this.totalCost = totalCost;
    }

    /*降序排列*/
    @Override
    public int compareTo(Duty duty) {

        if (this.tripsize < duty.getTripSize())
            return 1;
        else if (this.tripsize > duty.getTripSize())
            return -1;
        else
            return this.idleCost.compareTo(duty.getIdleCost());
    }
}
