package com.guet.entity;

public class Edge {

    private String head;
    private String tail;
    private int weight;

    public Edge(String head, String tail, int weight) {
        this.head = head;
        this.tail = tail;
        this.weight = weight;
    }

    public String getHead() {
        return head;
    }

    public String getTail() {
        return tail;
    }

    public int getWeight() {
        return weight;
    }
}
