package com.guet.entity;

import java.util.List;

public class Graph implements Comparable<Graph>{

    //顶点
    List<BusShare> node;

    //平均权重
    double weight;

    public Graph() {
        super();
    }

    public Graph(List<BusShare> node, double weight) {
        this.node = node;
        this.weight = weight;
    }

    public List<BusShare> getNode() {
        return node;
    }

    public void setNode(List<BusShare> node) {
        this.node = node;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    @Override
    public int compareTo(Graph graph) {
        if (this.weight > graph.getWeight())
            return 1;
        else if(this.weight == graph.getWeight())
            return 0;
        else return -1;
    }
}
