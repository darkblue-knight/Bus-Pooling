package com.guet.entity;

public class Grid {

    int id;
    double lng_lower, lng_upper, lat_lower, lat_upper, probability;

    public Grid(int id, double lng_lower, double lng_upper, double lat_lower, double lat_upper) {
        this.id = id;
        this.lng_lower = lng_lower;
        this.lng_upper = lng_upper;
        this.lat_lower = lat_lower;
        this.lat_upper = lat_upper;
    }

    public int getId() {
        return id;
    }

    public double getLngLower() {
        return lng_lower;
    }

    public double getLngUpper() {
        return lng_upper;
    }

    public double getLatLower() {
        return lat_lower;
    }

    public double getLatUpper() {
        return lat_upper;
    }

    public Double getProbability() {
        return probability;
    }

    public void setProbability(Double probability) {
        this.probability = probability;
    }
}
