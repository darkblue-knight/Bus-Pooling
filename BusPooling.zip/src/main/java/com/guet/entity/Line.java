package com.guet.entity;

import java.util.Date;

public class Line {

    private String id;
    private int code;
    private String s_trip;
    private String d_trip;
    private String s_depot;
    private String d_depot;
    private Date s_dt;
    private Date d_dt;

    public String getId() {
        return id;
    }

    public int getCode() {
        return code;
    }

    public String getStrip() {
        return s_trip;
    }

    public String getDtrip() {
        return d_trip;
    }

    public Line() {
        super();
    }

    public Line(String id, int code, String s_trip, String d_trip, String s_depot, String d_depot, Date s_dt, Date d_dt) {
        this.id = id;
        this.code = code;
        this.s_trip = s_trip;
        this.d_trip = d_trip;
        this.s_depot = s_depot;
        this.d_depot = d_depot;
        this.s_dt = s_dt;
        this.d_dt = d_dt;
    }
}