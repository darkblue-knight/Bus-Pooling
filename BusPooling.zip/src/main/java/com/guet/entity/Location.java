package com.guet.entity;

public class Location {
    private String id;
    private int code;
    private Double lng;//经度
    private Double lat;//维度

    public String getId() {
        return id;
    }

    public int getCode() {
        return code;
    }

    public Double getLng() {
        return lng;
    }

    public Double getLat() {
        return lat;
    }

    public Location() { }

    public Location(String id, int code, Double lng, Double lat) {
        this.id = id;
        this.code = code;
        this.lng = lng;
        this.lat = lat;
    }
}
