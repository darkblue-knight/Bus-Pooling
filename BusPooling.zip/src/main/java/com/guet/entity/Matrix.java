package com.guet.entity;

import java.text.SimpleDateFormat;
import java.util.*;

public class Matrix {
    private double[][] entry;//矩阵的元
    private int Max_Row_Id;//矩阵行之和最大的索引号

    public Matrix() { }

    public Matrix(double[][] entry,int maxRowId) {
        this.entry=entry;
        this.Max_Row_Id=maxRowId;
    }

    public double[][] getEntry() {
        return entry;
    };

    public int getMaxRowId() {
        return Max_Row_Id;
    }
}
