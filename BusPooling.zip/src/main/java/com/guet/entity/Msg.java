package com.guet.entity;

public class Msg {
    private int distance;
    private int duration;
}
