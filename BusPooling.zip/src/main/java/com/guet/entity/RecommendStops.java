package com.guet.entity;

public class RecommendStops {

    private String id;
    private int code;
    private int child;
    private double s_lng;
    private double s_lat;
    private double d_lng;
    private double d_lat;
    private int distance;
    private int duration;

    public String getId() {
        return id;
    }

    public int getCode() {
        return code;
    }

    public int getChild() {
        return child;
    }

    public double getSLng() {
        return s_lng;
    }

    public double getSLat() {
        return s_lat;
    }

    public double getDLng() {
        return d_lng;
    }

    public double getDLat() {
        return d_lat;
    }

    public RecommendStops(String id, int code, int child, double s_lng, double s_lat, double d_lng, double d_lat, int distance, int duration) {
        this.id = id;
        this.code = code;
        this.child = child;
        this.s_lng = s_lng;
        this.s_lat = s_lat;
        this.d_lng = d_lng;
        this.d_lat = d_lat;
        this.distance = distance;
        this.duration = duration;
    }
}