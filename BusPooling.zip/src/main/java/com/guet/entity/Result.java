package com.guet.entity;

public class Result {

    private int distance;

    private int duration;

    public int getDistance() {
        return distance;
    }

    public int getDuration() {
        return duration;
    }

    public Result(int distance, int duration) {
        super();
        this.distance = distance;
        this.duration = duration;
    }

    @Override
    public String toString() {
        return "result [distance=" + distance + ", duration=" + duration + "]";
    }
}
