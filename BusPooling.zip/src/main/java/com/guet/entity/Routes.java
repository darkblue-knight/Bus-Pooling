package com.guet.entity;

public class Routes implements Comparable<Routes>{
    private String id;//唯一标识
    private String bus_share_id;
    private int idx;
    private Double lng;//经度
    private Double lat;//维度

    public Routes() { }

    public Routes(String id, String bus_share_id, int idx, double lng, double lat) {
        this.id = id;
        this.bus_share_id = bus_share_id;
        this.idx = idx;
        this.lng = lng;
        this.lat = lat;
    }

    public String getId() {
        return id;
    }

    public String getBusShareId() {
        return bus_share_id;
    }

    public Double getLat() {
        return lat;
    }

    public Double getLng() {
        return lng;
    }

    public int getIdx() {
        return idx;
    }

    @Override
    public int compareTo(Routes routes) {
        if (this.idx > routes.getIdx())
            return 1;
        else if(this.idx == routes.getIdx())
            return 0;
        else return -1;
    }
}