package com.guet.entity;

public class Scope {

    private double s_lng_max;
    private double s_lng_min;
    private double s_lat_max;
    private double s_lat_min;

    private double d_lng_max;
    private double d_lng_min;
    private double d_lat_max;
    private double d_lat_min;

    public Scope() { }

    public Scope(double s_lng_max, double s_lng_min, double s_lat_max, double s_lat_min, double d_lng_max, double d_lng_min, double d_lat_max, double d_lat_min) {
        this.s_lng_max = s_lng_max;
        this.s_lng_min = s_lng_min;
        this.s_lat_max = s_lat_max;
        this.s_lat_min = s_lat_min;
        this.d_lng_max = d_lng_max;
        this.d_lng_min = d_lng_min;
        this.d_lat_max = d_lat_max;
        this.d_lat_min = d_lat_min;
    }

    public double getSLngMax() {
        return s_lng_max;
    }

    public double getSLngMin() {
        return s_lng_min;
    }

    public double getSLatMax() {
        return s_lat_max;
    }

    public double getSLatMin() {
        return s_lat_min;
    }

    public double getDLngMax() {
        return d_lng_max;
    }

    public double getDLngMin() {
        return d_lng_min;
    }

    public double getDLatMax() {
        return d_lat_max;
    }

    public double getDLatMin() {
        return d_lat_min;
    }
}
