package com.guet.entity;

public class Score implements Comparable<Score> {
    private int x_id;
    private int y_id;
    private Double min;

    public int getXid() {
        return x_id;
    }
    public int getYid() {
        return y_id;
    }
    public Double getMin() {
        return min;
    }

    public Score(int x_id, int y_id, double min) {
        this.x_id = x_id;
        this.y_id = y_id;
        this.min = min;
    }

    @Override
    public int compareTo(Score score) {
        return this.min.compareTo(score.getMin());
    }
}
