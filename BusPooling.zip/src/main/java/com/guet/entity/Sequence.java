package com.guet.entity;

public class Sequence {

    private String id;//唯一标识
    private int code;//编号
    private String trip_id;//乘坐需求ID
    private String depot_id;//乘坐需求ID

    public Sequence(String id, int code, String trip_id, String depot_id) {
        this.id = id;
        this.code = code;
        this.trip_id = trip_id;
        this.depot_id = depot_id;
    }

    public String getId() {
        return id;
    }

    public int getCode() {
        return code;
    }

    public String getTripId() {
        return trip_id;
    }
}
