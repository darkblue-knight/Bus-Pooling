package com.guet.entity;

import java.util.List;

public class Solution {

    private List<List<Trip>> trip;

    public Solution() {
        super();
    }

    public Solution(List<List<Trip>> trip) {
        super();
        this.trip = trip;
    }

    public List<List<Trip>> getTrip() {
        return trip;
    }
}
