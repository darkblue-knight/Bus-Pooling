package com.guet.entity;

public class Stops {
    private int code;
    private LatLng latLng;

    public int getCode() {
        return code;
    }
    public LatLng getLatLng() { return latLng; }

    public Stops() { }

    public Stops(int code, LatLng latLng) {
        this.code = code;
        this.latLng = latLng;
    }
}
