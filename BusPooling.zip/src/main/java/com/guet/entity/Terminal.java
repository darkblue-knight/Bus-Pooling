package com.guet.entity;

public class Terminal implements Comparable<Terminal> {

    int id;
    LatLng latLng;
    int distance;

    public Terminal(int id, LatLng latLng, int distance) {
        this.id = id;
        this.latLng = latLng;
        this.distance = distance;
    }

    public int getId() {
        return id;
    }

    public LatLng getLatLng() {
        return latLng;
    }

    public int getDistance() {
        return distance;
    }

    @Override
    public int compareTo(Terminal t) {
        if (this.distance > t.getDistance())
            return 1;
        else if (this.distance == t.getDistance())
            return 0;
        else return -1;
    }
}
