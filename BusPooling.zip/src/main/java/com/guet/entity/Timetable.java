package com.guet.entity;

import java.util.Date;

public class Timetable implements Comparable<Timetable> {

    private Date departureDt;

    private double probability;

    private double min;

    private double max;

    public Date getDepartureDt() { return departureDt; }

    public Double getMax() {
        return max;
    }

    public Double getMin() {
        return min;
    }

    public Double getProbability() {
        return probability;
    }

    public void setProbability(Double probability) {
        this.probability = probability;
    }

    public void setMin(Double min) {
        this.min = min;
    }

    public void setMax(Double max) {
        this.max = max;
    }

    public Timetable() {
        super();
    }

    public Timetable(Date departureDt, double probability) {
        this.departureDt = departureDt;
        this.probability = probability;
    }

    /*降序排列*/
    @Override
    public int compareTo(Timetable timetable) {
        if (this.max < timetable.getMax())
            return 1;
        else if (this.max > timetable.getMax())
            return -1;
        else
            return 0;
    }
}
