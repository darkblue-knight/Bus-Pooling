package com.guet.entity;

import java.util.List;

public class Travel {

    private int s;
    private int d;
    private List<BusShare> list;

    public int getS() { return s; }
    public int getD() { return d; }
    public List<BusShare> getList() { return list; }

    public Travel() { }

    public Travel(int s, int d, List<BusShare> list) {
        this.s = s;
        this.d = d;
        this.list = list;
    }
}
