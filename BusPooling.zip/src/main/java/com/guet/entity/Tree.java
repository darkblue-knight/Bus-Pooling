package com.guet.entity;

//kd树的代码
public class Tree {
    public Tree left;//左节点
    public Tree father;//父节点
    public Tree right;//右节点
    public LatLng mData;//节点的数据
    public int split;//判断维数

    public void setSplit(int split) {
        this.split = split;
    }

    public int getSplit() {
        return split;
    }
}
