package com.guet.entity;

import java.sql.Time;
import java.util.Date;

public class Trip implements Comparable<Trip> {

    private String id;
    private int code;
    private Date departure;
    private double s_lng;
    private double s_lat;
    private double d_lng;
    private double d_lat;
    private int distance;
    private int duration;
    private Double cost;

    public Trip() {
        super();
    }

    public String getId() {
        return id;
    }

    public int getCode() {
        return code;
    }

    public Date getDeparture() { return departure; }

    public double getSLng() {
        return s_lng;
    }

    public double getSLat() {
        return s_lat;
    }

    public double getDLng() {
        return d_lng;
    }

    public double getDLat() {
        return d_lat;
    }

    public int getDistance() {
        return distance;
    }

    public int getDuration() {
        return duration;
    }

    public Double getCost() {
        return cost;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public Trip(String id, int code, Time departure, double s_lng, double s_lat, double d_lng, double d_lat, int distance, int duration, Double cost) {
        this.id = id;
        this.code = code;
        this.departure = departure;
        this.s_lng = s_lng;
        this.s_lat = s_lat;
        this.d_lng = d_lng;
        this.d_lat = d_lat;
        this.distance = distance;
        this.duration = duration;
        this.cost = cost;
    }

    @Override
    public int compareTo(Trip trip) {
        if (this.departure.after(trip.getDeparture()))
            return 1;
        else if (this.departure.before(trip.getDeparture()))
            return -1;
        else
            return 0;
    }
}