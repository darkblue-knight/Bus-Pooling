package com.guet.entity;

public class Vertex {

    private String id;//唯一标识
    private int code;//编号
    private double lng;
    private double lat;

    public Vertex(String id, int code, double s_lng, double s_lat) {
        this.id = id;
        this.code = code;
        this.lng = s_lng;
        this.lat = s_lat;
    }

    public String getId() {
        return id;
    }

    public int getCode() {
        return code;
    }

    public double getLat() {
        return lat;
    }

    public double getLng() {
        return lng;
    }
}
