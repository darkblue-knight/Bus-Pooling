package com.guet.entity;

public class Zone {
    private int code;
    private int idx;

    public int getCode() {
        return code;
    }
    public int getIdx() {
        return idx;
    }

    public Zone() { }

    public Zone(int code, int idx) {
        this.code = code;
        this.idx = idx;
    }
}
