package com.guet.service;

import java.util.List;

import com.guet.entity.Bucket;
import com.guet.entity.BusShare;
import com.guet.entity.LatLng;
import com.guet.entity.RecommendStops;
import org.apache.ibatis.annotations.Param;

public interface BucketService {

    boolean add(List<Bucket> list);

    void write(List<String> list);

    boolean update(String id, int s_distance, int d_distance, int s_duration, int d_duration
            , int riding_distance, int riding_duration, int driving_distance, int driving_duration);

    List<Bucket> queryAll(int code);

    boolean queryExist(int code, String bus_share_id);

    int queryBucketNo();

    List<Bucket> queryUpdateBucketNo();

    /**
     * 根据坐标集合找到最适合上车点
     *
     * @return
     */
    LatLng getMinDistanceStop(List<LatLng> list);
}

