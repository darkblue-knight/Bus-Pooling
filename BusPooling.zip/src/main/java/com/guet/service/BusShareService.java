package com.guet.service;

import java.util.LinkedList;
import java.util.List;

import com.guet.entity.*;
import org.apache.ibatis.annotations.Param;

public interface BusShareService {

    boolean add(List<BusShare> list);

    /**
     * 统计记录总数
     *
     * @return
     */
    int queryCount();

    List<BusShare> getAll();

    List<BusShare> getList();

    LinkedList<BusShare> queryList();

    Scope getScope();

    /**
     * 读取乘车需求
     * @param offset
     * @param limit
     * @return
     */
    List<BusShare> getList(int offset,  int limit);


    List<BusShare> getList(int code);

    /**
     * 读取下一条乘车需求
     *
     * @return
     */
    BusShare getCurrentNext(int offset);

    /**
     * 读取一条乘车需求
     *
     * @return
     */
    BusShare getModel(String id);

    /**
     * 获得List<Graph>的结点是否存在
     *
     * @return
     */
    int getExistNodeNo(List<Graph> Graphs,Graph graph);

    /**
     * 计算两个坐标的物理距离矩阵
     *
     * @return
     */
    Matrix getMatrix(List<BusShare> list, List<Routes> routesList);

    int getMaxRowId(List<BusShare> list);
    /**
     * 删除一条记录
     *
     * @return
     */
    boolean delete(List<BusShare> list);

    List<LatLng> getTrajectory(List<Routes> routesList, String id);

    List<BusShare> getBusShare(List<BusShare> list, List<Routes> routesList);

    List<BusShare> getBusShare(List<BusShare> list, List<Routes> routesList, int limit);

    double compareWeightofGraph(List<BusShare> list, BusShare item);

    double getAverageWeight(List<BusShare> list);
}
