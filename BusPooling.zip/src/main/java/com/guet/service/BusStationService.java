package com.guet.service;

import com.guet.entity.BusStation;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface BusStationService {

    int queryExist(@Param("id") String id);

    boolean add(List<BusStation> list);

    List<BusStation> getList();
}
