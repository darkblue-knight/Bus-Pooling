package com.guet.service;

import com.guet.entity.Clustering;

import java.util.List;

public interface ClusterService {

    boolean add(List<Clustering> list);
}
