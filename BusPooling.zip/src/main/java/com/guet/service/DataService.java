package com.guet.service;

import com.guet.entity.Data;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface DataService {

    boolean add(List<Data> list);

    List<Integer> queryCode();

    List<Data> getModel(@Param("code") int code);
}
