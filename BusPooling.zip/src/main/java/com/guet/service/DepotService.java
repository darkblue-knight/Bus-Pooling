package com.guet.service;

import com.guet.entity.Location;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface DepotService {

    List<Location> queryAll();

    List<Location> queryStation();

    List<Location> queryClusters(@Param("code") int code);

    List<Location> queryAllClusters();
}
