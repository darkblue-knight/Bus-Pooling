package com.guet.service;

import com.guet.entity.Arc;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Service;

import java.sql.Time;
import java.util.LinkedList;
import java.util.List;

@Service
public interface DharcService {

    boolean queryExist(@Param("s_id") String s_id, @Param("d_id") String d_id);

    boolean add(List<Arc> list);

    boolean update(Arc model);

    boolean updateCost(@Param("id") String id, @Param("cost") Double cost);

    LinkedList<Arc> queryAll();

    Arc getModel(@Param("s_id") String s_id);

    boolean delete(List<String> list);

    List<Integer> queryArcNum(Time departureDt);
}
