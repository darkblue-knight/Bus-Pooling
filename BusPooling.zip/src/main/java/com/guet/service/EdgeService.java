package com.guet.service;

import com.guet.entity.Edge;

import java.util.List;

public interface EdgeService {

    List<Edge> queryAll();
}

