package com.guet.service;

import com.guet.entity.Line;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface LineService {

    List<Line> queryAll();

    boolean update(Line model);
}
