package com.guet.service;

import com.guet.entity.LatLng;
import com.guet.entity.Routes;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface RoutesService {

    boolean add(List<Routes> list);

    List<Routes> getList();
}
