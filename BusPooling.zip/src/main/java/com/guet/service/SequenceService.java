package com.guet.service;

import com.guet.entity.Sequence;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface SequenceService {

    boolean truncate();

    boolean add(List<Sequence> list);

    void write(String depot_id, List<String> list);

    boolean queryExist(int code, String trip_id);

    int querySequenceNo();

    List<Sequence> queryAll(int code);
}

