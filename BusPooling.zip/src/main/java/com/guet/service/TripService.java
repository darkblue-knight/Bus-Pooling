package com.guet.service;

import com.guet.entity.Trip;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Service;

import java.sql.Time;
import java.util.List;

@Service
public interface TripService {

    int queryCount();

    boolean add(Trip model);

    boolean update(Trip model);

    List<Time> getTimetable();

    List<Trip> queryAll();

    List<Trip> querySequence(@Param("code") int code);

    Trip getModel(@Param("id") String id);

    boolean delete(List<String> list);
}
