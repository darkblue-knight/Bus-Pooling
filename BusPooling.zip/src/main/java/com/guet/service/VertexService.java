package com.guet.service;

import com.guet.entity.Vertex;

import java.util.List;

public interface VertexService {

    List<Vertex> queryAll();
}

