package com.guet.service.impl;

import java.util.*;

import com.guet.dao.BucketDao;
import com.guet.entity.Bucket;
import com.guet.entity.BusShare;
import com.guet.entity.LatLng;
import com.guet.service.BucketService;
import com.guet.util.LocationUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BucketServiceImpl implements BucketService {

    @Autowired
    private BucketDao bucketDao;

    public boolean add(List<Bucket> list) {
        return bucketDao.add(list);
    }

    public void write(List<String> list) {

        List<Bucket> buckets = new ArrayList<Bucket>();

        int bucketNo = queryBucketNo() + 1;

        //将结果写入数据库
        for (String item : list) {
            if (!queryExist(bucketNo, item)) {
                buckets.add(new Bucket(
                        UUID.randomUUID().toString(),
                        bucketNo,
                        0,
                        item,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0));
            }
        }

        add(buckets);
    }

    public boolean update(String id, int s_distance, int s_duration, int d_distance, int d_duration, int riding_distance, int riding_duration, int driving_distance, int driving_duration) {
        return bucketDao.update(id, s_distance, s_duration, d_distance, d_duration, riding_distance, riding_duration, driving_distance, driving_duration);
    }

    public List<Bucket> queryAll(int code) {
        return bucketDao.queryAll(code);
    }

    public boolean queryExist(int code, String bus_share_id) {
        int count = -1;
        count = bucketDao.queryExist(code, bus_share_id);
        if (count > 0)
            return true;
        else return false;
    }

    public int queryBucketNo() {
        return bucketDao.queryBucketNo();
    }

    public List<Bucket> queryUpdateBucketNo() {
        return bucketDao.queryUpdateBucketNo();
    }

    public LatLng getMinDistanceStop(List<LatLng> list) {

        int minRowId = -1;

        List<Integer> distance = new ArrayList<Integer>();

        for (int i = 0; i < list.size(); i++) {

            int d = 0;

            for (LatLng item : list) {
                d += LocationUtils.getDistance(list.get(i), item);
            }

            distance.add(d);
        }

        int min = Collections.min(distance);

        for (int i = 0; i < distance.size(); i++) {
            if (distance.get(i) == min)
                minRowId = i;
        }

        return list.get(minRowId);
    }
}
