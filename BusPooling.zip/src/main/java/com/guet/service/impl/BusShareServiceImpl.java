package com.guet.service.impl;

import java.util.*;
import java.util.stream.Collectors;

import com.guet.entity.*;
import com.guet.util.LocationUtils;
import com.guet.dao.BusShareDao;
import com.guet.service.BusShareService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BusShareServiceImpl implements BusShareService {

    @Autowired
    private BusShareDao busShareDao;

    public boolean add(List<BusShare> list) { return busShareDao.add(list); }

    public int queryCount(){
        return busShareDao.queryCount();
    }

    public List<BusShare> getAll(){
        return busShareDao.getAll();
    }

    public Scope getScope(){
        return busShareDao.getScope();
    }

    public List<BusShare> getList() {
        return busShareDao.getList();
    }

    public LinkedList<BusShare> queryList() {

        LinkedList<BusShare> list = new LinkedList<BusShare>();

        int totalCount = busShareDao.queryCount();
        int PageSize = 990000;
        int PageIndex = (int) Math.ceil(totalCount / PageSize);
        int PageRemainder = totalCount % PageSize;

        for (int i = 0; i < PageIndex; i++) {
            if (i == PageIndex - 1)
                list.addAll(busShareDao.queryList(i * PageSize, PageSize + PageRemainder));
            else list.addAll(busShareDao.queryList(i * PageSize, PageSize));
        }

        return list;
    }

    public List<BusShare> getList(int offset, int limit){
        return busShareDao.queryAll(offset,limit);
    }

    public List<BusShare> getList(int code){
        return busShareDao.queryBucket(code);
    }

    public boolean delete(List<BusShare> list){ return busShareDao.delete(list); }

    public BusShare getCurrentNext(int offset) {
        return busShareDao.queryNext(offset);
    }

    public BusShare getModel(String id) {
        return busShareDao.getModel(id);
    }

    public double getAverageWeight(List<BusShare> list) {

        int n = 0;
        double sum = 0;

        for (int i = 0; i < list.size(); i++) {
            LatLng orig1 = new LatLng(list.get(i).getSLat(), list.get(i).getSLng());
            LatLng dest1 = new LatLng(list.get(i).getDLat(), list.get(i).getDLng());

            for (int j = 0; j < i; j++) {
                LatLng orig2 = new LatLng(list.get(j).getSLat(), list.get(j).getSLng());
                LatLng dest2 = new LatLng(list.get(j).getDLat(), list.get(j).getDLng());

                sum += LocationUtils.getEuclideanDistance(orig1, orig2) + LocationUtils.getEuclideanDistance(dest1, dest2);
                n++;
            }
        }

        return sum / n;
    }

    public int getExistNodeNo(List<Graph> graphs, Graph graph) {
        int result = -1;

        List<BusShare> child = graph.getNode();

        for (int n = 0; n < graphs.size(); n++) {
            List<BusShare> parent = graphs.get(n).getNode();

            for (int i = 0; i < parent.size(); i++) {
                for (int j = 0; j < child.size(); j++) {
                    if (parent.get(i) == child.get(j))
                        result = n;
                }
            }
        }

        return result;
    }

    public int getMaxRowId(List<BusShare> list) {
        int n = list.size();
        int maxRowId = Integer.MIN_VALUE;
        double max = Double.MIN_VALUE;
        double[] array = new double[n];

        for (int i = 0; i < n; i++) {
            LatLng orig1 = new LatLng(list.get(i).getSLat(), list.get(i).getSLng());
            LatLng dest1 = new LatLng(list.get(i).getDLat(), list.get(i).getDLng());

            for (int j = 0; j < n; j++) {
                LatLng orig2 = new LatLng(list.get(j).getSLat(), list.get(j).getSLng());
                LatLng dest2 = new LatLng(list.get(j).getDLat(), list.get(j).getDLng());

                array[i] += LocationUtils.getEuclideanDistance(orig1, orig2) + LocationUtils.getEuclideanDistance(dest1, dest2);
            }

            if (array[i] > max) {
                max = array[i];
                maxRowId = i;
            }
        }

        return maxRowId;
    }

    public Matrix getMatrix(List<BusShare> list, List<Routes> routesList) {
        int n = list.size();
        int maxRowId = 0;
        double max = Double.MIN_VALUE;
        double[][] matrix = new double[n][n + 1];

        for (int i = 0; i < n; i++) {
            List<LatLng> latLng1 = getTrajectory(routesList, list.get(i).getId());

            for (int j = i; j < n; j++) {
                List<LatLng> latLng2 = getTrajectory(routesList, list.get(j).getId());

                matrix[i][j] = LocationUtils.getDistance(latLng1, latLng2);
                matrix[i][n] += matrix[i][j];
            }

            if (matrix[i][n] > max) {
                max = matrix[i][n];
                maxRowId = i;
            }
        }

        return new Matrix(matrix, maxRowId);
    }

    public List<LatLng> getTrajectory(List<Routes> routesList, String str) {

        final List<LatLng> latLng = new ArrayList();

        List<Routes> t = routesList.stream()
                .filter(r -> r.getBusShareId().equals(str))
                .collect(Collectors.toList());

        Collections.sort(t);

        t.forEach(r -> latLng.add(new LatLng(r.getLat(), r.getLng())));

        return latLng;
    }

    public List<BusShare> getBusShare(List<BusShare> list, List<Routes> routesList) {
        return getBusShare(list, routesList, -1);
    }

    public List<BusShare> getBusShare(List<BusShare> list, List<Routes> routesList, int limit) {
        List<LatLng> latLng1, latLng2;
        List<Cluster> cluster = new ArrayList();
        List<BusShare> result = new ArrayList(limit);

        for (BusShare item1 : list) {
            //latLng1 = getTrajectory(routesList, item1.getId());
            LatLng orig1 = new LatLng(item1.getSLat(), item1.getSLng());
            LatLng dest1 = new LatLng(item1.getDLat(), item1.getDLng());

            double temp = 0;
            for (BusShare item2 : list) {
                LatLng orig2 = new LatLng(item2.getSLat(), item2.getSLng());
                LatLng dest2 = new LatLng(item2.getDLat(), item2.getDLng());

                //latLng2 = getTrajectory(routesList, item2.getId());
                //temp += LocationUtils.getDistance(latLng1, latLng2);
                temp += LocationUtils.getEuclideanDistance(orig1, orig2) + LocationUtils.getEuclideanDistance(dest1, dest2);
            }
            cluster.add(new Cluster(item1, temp));
        }

        Collections.sort(cluster);

        if (limit > 0) {
            cluster.subList(0, limit).forEach(item -> result.add(item.getBusShare()));
        } else {
            cluster.forEach(item -> result.add(item.getBusShare()));
        }

        return result;
    }

    public double compareWeightofGraph(List<BusShare> list, BusShare item) {

        double original = getAverageWeight(list);

        list.add(item);

        double current = getAverageWeight(list);

        list.remove(item);

        return current - original;
    }
}
