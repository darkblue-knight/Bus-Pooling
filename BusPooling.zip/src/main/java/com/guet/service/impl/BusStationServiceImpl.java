package com.guet.service.impl;

import com.guet.dao.BusStationDao;
import com.guet.entity.BusStation;
import com.guet.service.BusStationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BusStationServiceImpl implements BusStationService {

    @Autowired
    private BusStationDao busStationDao;

    public int queryExist(String id) {
        return busStationDao.queryExist(id);
    }

    public boolean add(List<BusStation> list) {
        return busStationDao.add(list);
    }

    public List<BusStation> getList() { return busStationDao.getList(); }
}
