package com.guet.service.impl;

import com.guet.dao.ClusterDao;
import com.guet.entity.Clustering;
import com.guet.service.ClusterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClusterServiceImpl implements ClusterService {

    @Autowired
    private ClusterDao clusterDao;

    public boolean add(List<Clustering> list) {
        return clusterDao.add(list);
    }
}
