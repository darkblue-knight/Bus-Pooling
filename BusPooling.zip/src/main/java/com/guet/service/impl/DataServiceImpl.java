package com.guet.service.impl;

import com.guet.entity.Data;
import com.guet.service.DataService;
import com.guet.dao.DataDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DataServiceImpl implements DataService {

    @Autowired
    private DataDao dataDao;

    public boolean add(List<Data> list) {
        return dataDao.add(list);
    }

    public List<Integer> queryCode() {
        return dataDao.queryCode();
    }

    public List<Data> getModel(int code) { return dataDao.getModel(code); }
}
