package com.guet.service.impl;

import com.guet.dao.DepotDao;
import com.guet.entity.Location;
import com.guet.service.DepotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepotServiceImpl implements DepotService {

    @Autowired
    private DepotDao depotDao;

    public List<Location> queryAll() {
        return depotDao.queryAll();
    }

    public List<Location> queryStation() {
        return depotDao.queryStation();
    }

    public List<Location> queryClusters(int code) {
        return depotDao.queryClusters(code);
    }

    public List<Location> queryAllClusters() {
        return depotDao.queryAllClusters();
    }
}
