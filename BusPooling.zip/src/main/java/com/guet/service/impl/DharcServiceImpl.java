package com.guet.service.impl;

import com.guet.dao.DharcDao;
import com.guet.entity.Arc;
import com.guet.service.DharcService;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Time;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

@Service
public class DharcServiceImpl implements DharcService {

    @Autowired
    private DharcDao dharcDao;

    public boolean queryExist(String s_id, String d_id) {
        int count = -1;
        count = dharcDao.queryExist(s_id, d_id);
        if (count > 0)
            return true;
        else return false;
    }

    public boolean add(List<Arc> list) {
        return dharcDao.add(list);
    }

    public boolean update(Arc model) {
        return dharcDao.update(model);
    }

    public boolean updateCost(@Param("id") String id, @Param("cost") Double cost) {
        return dharcDao.updateCost(id, cost);
    }

    public LinkedList<Arc> queryAll() {

        LinkedList<Arc> list = new LinkedList<Arc>();

        int totalCount = dharcDao.queryCount();
        int PageSize = 990000;
        int PageIndex = (int) Math.ceil(totalCount / PageSize);
        int PageRemainder = totalCount % PageSize;

        for (int i = 0; i < PageIndex; i++) {
            if (i == PageIndex - 1)
                list.addAll(dharcDao.getList(i * PageSize, PageSize + PageRemainder));
            else list.addAll(dharcDao.getList(i * PageSize, PageSize));
        }

        return list;
        //return dharcDao.queryAll();
    }

    public Arc getModel(@Param("s_id") String s_id) {
        return dharcDao.getModel(s_id);
    }

    public boolean delete(List<String> list) {
        return dharcDao.delete(list);
    }

    public List<Integer> queryArcNum(Time departureDt) {
        return dharcDao.queryArcNum(departureDt);
    }
}
