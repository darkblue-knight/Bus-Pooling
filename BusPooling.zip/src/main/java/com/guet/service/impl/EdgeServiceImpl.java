package com.guet.service.impl;

import com.guet.dao.EdgeDao;
import com.guet.entity.Edge;
import com.guet.service.EdgeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EdgeServiceImpl implements EdgeService {

    @Autowired
    private EdgeDao edgeDao;

    public List<Edge> queryAll() {
        return edgeDao.queryAll();
    }

}
