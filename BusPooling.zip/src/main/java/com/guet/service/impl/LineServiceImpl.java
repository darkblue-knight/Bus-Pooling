package com.guet.service.impl;


import com.guet.dao.LineDao;
import com.guet.entity.Line;
import com.guet.service.LineService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LineServiceImpl implements LineService {

    @Autowired
    private LineDao lineDao;

    public List<Line> queryAll() {
        return lineDao.queryAll();
    }

    public boolean update(Line model){ return lineDao.update(model); }
}
