package com.guet.service.impl;

import com.guet.dao.PullarcDao;
import com.guet.entity.Arc;
import com.guet.service.PullarcService;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;

@Service
public class PullarcServiceImpl implements PullarcService {

    @Autowired
    private PullarcDao pullarcDao;

    public boolean add(List<Arc> list) {
        return pullarcDao.add(list);
    }

    public boolean update(Arc model) {
        return pullarcDao.update(model);
    }

    public boolean updateCost(@Param("id") String id, @Param("cost") Double cost) {
        return pullarcDao.updateCost(id, cost);
    }

    public LinkedList<Arc> queryAll() {
        return pullarcDao.queryAll();
    }

    public Arc getModel(@Param("s_id") String s_id) {
        return pullarcDao.getModel(s_id);
    }
}
