package com.guet.service.impl;

import com.guet.dao.RoutesDao;
import com.guet.entity.LatLng;
import com.guet.entity.Routes;

import com.guet.service.RoutesService;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class RoutesServiceImpl implements RoutesService {

    @Autowired
    private RoutesDao routesDao;

    public boolean add(List<Routes> list) {
        return routesDao.add(list);
    }

    public List<Routes> getList() {

        /*
        List<Routes> list = new ArrayList<>();

        int totalCount = routesDao.queryCount();
        int PageSize = 400000;
        int PageIndex = (int) Math.ceil(totalCount / PageSize);
        int PageRemainder = totalCount % PageSize;

        for (int i = 0; i < PageIndex; i++) {
            if (i == PageIndex - 1)
                list.addAll(routesDao.getList(i * PageSize, PageSize + PageRemainder));
            else list.addAll(routesDao.getList(i * PageSize, PageSize));
        }
        */

        return routesDao.getList();
    }
}
