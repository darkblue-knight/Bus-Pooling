package com.guet.service.impl;

import com.guet.dao.SequenceDao;
import com.guet.entity.Sequence;
import com.guet.service.SequenceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class SequenceServiceImpl implements SequenceService {

    @Autowired
    private SequenceDao sequenceDao;

    public boolean truncate() {
        return sequenceDao.truncate();
    }

    public boolean add(List<Sequence> list) {
        return sequenceDao.add(list);
    }

    public void write(String depot_id, List<String> list) {

        List<Sequence> sequenceNos = new ArrayList<Sequence>();

        int sequenceNo = querySequenceNo() + 1;

        //将结果写入数据库
        for (String item : list) {
            //if (!queryExist(sequenceNo, item)) {
            sequenceNos.add(new Sequence(
                    UUID.randomUUID().toString(),
                    sequenceNo,
                    item,
                    depot_id));
            //}
        }

        add(sequenceNos);
    }

    public boolean queryExist(int code, String trip_id) {
        int count = -1;
        count = sequenceDao.queryExist(code, trip_id);
        if (count > 0)
            return true;
        else return false;
    }

    public int querySequenceNo() {
        return sequenceDao.querySequenceNo();
    }

    public List<Sequence> queryAll(int code) {
        return sequenceDao.queryAll(code);
    }

}
