package com.guet.service.impl;

import com.guet.dao.StopDao;
import com.guet.entity.RecommendStops;
import com.guet.service.StopService;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StopServiceImpl implements StopService {

    @Autowired
    private StopDao stopDao;

    public boolean add(RecommendStops model) {
        return stopDao.add(model);
    }

    public boolean updateOrig(@Param("id") String id, @Param("s_lng") double s_lng, @Param("s_lat") double s_lat) {
        return stopDao.updateOrig(id, s_lng, s_lat);
    }

    public boolean updateDest(@Param("id") String id, @Param("d_lng") double d_lng, @Param("d_lat") double d_lat) {
        return stopDao.updateDest(id, d_lng, d_lat);
    }

    public boolean updateDistance(@Param("id") String id, @Param("distance") int distance, @Param("duration") int duration){
        return stopDao.updateDistance(id,distance,duration);
    }

    public List<RecommendStops> queryAll() {
        return stopDao.queryAll();
    }

    public RecommendStops getModel(@Param("code") int code) {
        return stopDao.getModel(code);
    }
}
