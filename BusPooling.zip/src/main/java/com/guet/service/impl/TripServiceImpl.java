package com.guet.service.impl;

import com.guet.dao.TripDao;
import com.guet.entity.Trip;
import com.guet.service.TripService;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

@Service
public class TripServiceImpl implements TripService {

    @Autowired
    private TripDao tripDao;

    public int queryCount(){
        return tripDao.queryCount();
    }

    public boolean add(Trip model) {
        return tripDao.add(model);
    }

    public List<Time> getTimetable() { return tripDao.getTimetable(); }

    public List<Trip> queryAll() {
        return tripDao.queryAll();
    }

    public List<Trip> querySequence(int code) {
        return tripDao.querySequence(code);
    }

    public Trip getModel(@Param("id") String id) {
        return tripDao.getModel(id);
    }

    public boolean delete(List<String> list){ return tripDao.delete(list); }

    public boolean update(Trip model){ return tripDao.update(model); }
}
