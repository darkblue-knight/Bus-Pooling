package com.guet.service.impl;

import com.guet.dao.VertexDao;
import com.guet.entity.Vertex;
import com.guet.service.VertexService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VertexServiceImpl implements VertexService {

    @Autowired
    private VertexDao vertexDao;

    public List<Vertex> queryAll() {
        return vertexDao.queryAll();
    }

}
