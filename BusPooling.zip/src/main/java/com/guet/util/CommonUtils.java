package com.guet.util;

import com.guet.entity.Trip;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 通用工具类
 *
 * @author baidu
 *
 */
public class CommonUtils {

    /**
     * 将异常信息转成字符串
     *
     * @param ex
     * @return
     */
    public static String transExceptionToString(Exception ex) {
        StringWriter sw = new StringWriter();
        ex.printStackTrace(new PrintWriter(sw));
        return sw.toString();
    }

    /**
     * 字符串是否为null或空串
     *
     * @param str
     * @return
     */
    public static boolean isNullOrEmpty(String str) {
        if (null == str || "".equals(str)) {
            return true;
        }
        return false;
    }

    public static List<Time> getTimetable() {

        List<Time> list = new ArrayList<Time>();

        list.add(new Time(6,0,0));
        list.add(new Time(6,0,0));
        list.add(new Time(6,10,0));
        list.add(new Time(6,20,0));
        list.add(new Time(6,30,0));
        list.add(new Time(6,40,0));
        list.add(new Time(6,50,0));
        list.add(new Time(7,0,0));
        list.add(new Time(7,10,0));
        list.add(new Time(7,20,0));
        list.add(new Time(7,30,0));
        list.add(new Time(7,40,0));
        list.add(new Time(7,50,0));
        list.add(new Time(8,0,0));
        list.add(new Time(8,10,0));
        list.add(new Time(8,20,0));
        list.add(new Time(8,30,0));
        list.add(new Time(8,40,0));
        list.add(new Time(8,50,0));
        list.add(new Time(9,0,0));
        list.add(new Time(9,10,0));
        list.add(new Time(9,20,0));
        list.add(new Time(9,30,0));
        list.add(new Time(9,40,0));
        list.add(new Time(9,50,0));
        list.add(new Time(10,0,0));
        list.add(new Time(10,10,0));
        list.add(new Time(10,20,0));
        list.add(new Time(10,30,0));
        list.add(new Time(10,40,0));
        list.add(new Time(10,50,0));
        list.add(new Time(11,0,0));
        list.add(new Time(11,10,0));
        list.add(new Time(11,20,0));
        list.add(new Time(11,30,0));
        list.add(new Time(11,40,0));
        list.add(new Time(11,50,0));
        list.add(new Time(12,0,0));
        list.add(new Time(12,10,0));
        list.add(new Time(12,20,0));
        list.add(new Time(12,30,0));
        list.add(new Time(12,40,0));
        list.add(new Time(12,50,0));
        list.add(new Time(13,0,0));
        list.add(new Time(13,10,0));
        list.add(new Time(13,20,0));
        list.add(new Time(13,30,0));
        list.add(new Time(13,40,0));
        list.add(new Time(13,50,0));
        list.add(new Time(14,0,0));
        list.add(new Time(14,10,0));
        list.add(new Time(14,20,0));
        list.add(new Time(14,30,0));
        list.add(new Time(14,40,0));
        list.add(new Time(14,50,0));
        list.add(new Time(15,0,0));
        list.add(new Time(15,10,0));
        list.add(new Time(15,20,0));
        list.add(new Time(15,30,0));
        list.add(new Time(15,40,0));
        list.add(new Time(15,50,0));
        list.add(new Time(16,0,0));
        list.add(new Time(16,10,0));
        list.add(new Time(16,20,0));
        list.add(new Time(16,30,0));
        list.add(new Time(16,40,0));
        list.add(new Time(16,50,0));
        list.add(new Time(17,0,0));
        list.add(new Time(17,10,0));
        list.add(new Time(17,20,0));
        list.add(new Time(17,30,0));
        list.add(new Time(17,40,0));
        list.add(new Time(17,50,0));
        list.add(new Time(18,0,0));
        list.add(new Time(18,10,0));
        list.add(new Time(18,20,0));
        list.add(new Time(18,30,0));
        list.add(new Time(18,40,0));
        list.add(new Time(18,50,0));
        list.add(new Time(19,0,0));
        list.add(new Time(19,10,0));
        list.add(new Time(19,20,0));
        list.add(new Time(19,30,0));
        list.add(new Time(19,40,0));
        list.add(new Time(19,50,0));
        list.add(new Time(20,0,0));
        list.add(new Time(20,10,0));
        list.add(new Time(20,20,0));
        list.add(new Time(20,30,0));
        list.add(new Time(20,40,0));
        list.add(new Time(20,50,0));
        list.add(new Time(21,0,0));
        list.add(new Time(21,10,0));
        list.add(new Time(21,20,0));
        list.add(new Time(21,30,0));
        list.add(new Time(21,40,0));
        list.add(new Time(21,50,0));
        list.add(new Time(22,0,0));
        list.add(new Time(22,10,0));
        list.add(new Time(22,20,0));
        list.add(new Time(22,30,0));
        list.add(new Time(22,40,0));
        list.add(new Time(22,50,0));
        list.add(new Time(23,0,0));
        list.add(new Time(23,10,0));
        list.add(new Time(23,20,0));
        list.add(new Time(23,30,0));
        list.add(new Time(23,40,0));
        list.add(new Time(23,50,0));
        list.add(new Time(0,0,0));
        list.add(new Time(0,10,0));
        list.add(new Time(0,20,0));

        return list;
    }
}
