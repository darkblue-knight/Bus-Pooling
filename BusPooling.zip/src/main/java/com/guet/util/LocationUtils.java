package com.guet.util;

import com.guet.core.HttpClient;
import com.guet.core.UrlDomain;
import com.guet.entity.*;
import net.sf.json.*;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.*;
import java.util.stream.Collectors;

import static com.guet.util.LocationUtils.GetCenterPointFromListOfCoordinates;
import static java.lang.Math.PI;
import static java.math.BigDecimal.ROUND_HALF_DOWN;

public class LocationUtils {

    private static double EARTH_RADIUS = 6378.137;

    private static double rad(double d) {
        return d * PI / 180.0;
    }

    public static String AccessKey = "oGxB3ag3qsTPujhl73097Ou8OWaAQRnG";

    public static List<String> getAccessKey() {

        List<String> list = new ArrayList<String>();

        list.add("iF0nYCFyqje2vlLzI8tvkog5TrOZna9m");//liuchun
        list.add("lbN2GqgqKgLiR9GSDw6DSVKqjb7GI5hE");//liukaijun
        list.add("oNOBtlqbAqFIUGXiWK3rkQgVZoGfabjr");//chenru
        list.add("qqH06GQAmxc41efOUYK1GjaFSWMwTAFA");//zhouqingqing
        list.add("0bV5wSvEl4Hvd9SUrhA6uUUsNQkN8BXq");//liupingli
        list.add("OOtacGv6RO064j9GVcR8DOKESUZGW8u0");//dumingping
        list.add("5QmOlsT45d3fZNGvAXQcrV4mVwcTBsjY");//tangfengping
        list.add("6domYp2p8afYkvFYUd0COQw19MAbQMBn");//liukeyu
        list.add("szuA0sMnapNA8AEarIVx91loPHbZ5nLM");//duxingrui
        list.add("Zn49Lmil4LANwXtGSCNp0jGuhlopmLbU");//mosuping
        list.add("FZCaeKCgbf3MGePTxZXH8sp4LeNz3hN2");//chenxin
        list.add("ubyyKDry67XIgfRw69hf84ZgiC3GpZfQ");//liumin
        list.add("bDwn2xdG1oRVLqOfQ4CZdYD2dsQ8En8s");//zhongyun
        list.add("PeuHBniS9jBVbGk5BhwBGvHXXPcI1eBb");//yujing
        list.add("K8qy4FhGZfolL7h7Vmq2Hh1ADhNkb1ux");//duchunyan
        list.add("q47TTPQsOi5dgz1Lv9pUS4BSmVKG8dU3");//yangmingyu
        list.add("u3tH58z8ZUsGNrN7XifCGMS73f9Rkc9q");//dumingyong
        list.add("oGxB3ag3qsTPujhl73097Ou8OWaAQRnG");//yangyixiu
        list.add("kCU78UuSVGa6BDcKRQdvjVMeLY3WDjZM");//dengyoufa
        list.add("vfKrEaxdMoeCPT6fOj6lwrh8GUBxPBOW");//jiafei

        return list;
    }

    public static double getDistance(List<LatLng> seqa, List<LatLng> seqb) {
        double distance = 0;
        int lena = seqa.size();
        int lenb = seqb.size();
        double[][] c = new double[lena][lenb];
        for (int i = 0; i < lena; i++) {
            for (int j = 0; j < lenb; j++) {
                c[i][j] = 1;
            }
        }
        for (int i = 0; i < lena; i++) {
            for (int j = 0; j < lenb; j++) {
                //计算两个点的球面距离
                double tmp = getDistance(seqa.get(i), seqb.get(j));
                if (j == 0 && i == 0)
                    c[i][j] = tmp;
                else if (j > 0)
                    c[i][j] = c[i][j - 1] + tmp;
                if (i > 0) {
                    if (j == 0)
                        c[i][j] = tmp + c[i - 1][j];
                    else
                        c[i][j] = tmp + getMin(c[i][j - 1], c[i - 1][j - 1], c[i - 1][j]);
                }
            }
        }
        distance = c[lena - 1][lenb - 1];
        return distance;
    }

    private static double getMin(double a, double b, double c) {
        double min = a;
        if (b > a)
            min = a;
        else if (c > b) {
            min = b;
        } else {
            min = c;
        }
        return min;
    }

    /**
     * 通过经纬度获取距离(单位：米)
     *
     * @param orig
     * @param dest
     * @return
     */
    public static double getDistance(LatLng orig, LatLng dest) {

        double lat1 = orig.getLatitude();
        double lng1 = orig.getLongitude();
        double lat2 = dest.getLatitude();
        double lng2 = dest.getLongitude();

        double radLat1 = rad(lat1);
        double radLat2 = rad(lat2);
        double a = radLat1 - radLat2;
        double b = rad(lng1) - rad(lng2);
        double s = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2)
                + Math.cos(radLat1) * Math.cos(radLat2)
                * Math.pow(Math.sin(b / 2), 2)));
        s = s * EARTH_RADIUS;
        s = Math.round(s * 10000d) / 10000d;
        s = s * 1000;
        return s;
    }

    public static double getEuclideanDistance(LatLng orig, LatLng dest) {
        return Math.sqrt(Math.pow(orig.getLatitude() - dest.getLatitude(), 2) + Math.pow(orig.getLongitude() - dest.getLongitude(), 2));
    }

    /**
     * 计算两个经纬度的步行距离
     *
     * @param orig
     * @param dest
     */
    public static Result Distance(String ak, String action, LatLng orig, LatLng dest) {

        int distance = -1, duration = -1;

        //tactics=12&
        StringBuilder parameters = new StringBuilder("output=json&origins=" + orig.getLatitude() + "," + orig.getLongitude() + "&destinations=" + dest.getLatitude() + "," + dest.getLongitude() + "&ak=" + ak);

        String json = HttpClient.sendRequest(UrlDomain.BAIDU_MAP_API_ROUTEMATRIX_HTTP_URL, action, parameters.toString(), HttpClient.METHOD_GET);

        JSONObject obj = JSONObject.fromObject(json);

        if (obj.get("status").toString().equals("0")) {
            distance = obj.getJSONArray("result").getJSONObject(0).getJSONObject("distance").getInt("value");
            duration = obj.getJSONArray("result").getJSONObject(0).getJSONObject("duration").getInt("value");
        }

        return new Result(distance, duration);
    }

    /**
     * 计算两个经纬度的步行距离
     *
     * @param action
     * @param orig
     * @param dest
     */
    private static List<Result> Distance(String action, List<LatLng> orig, List<LatLng> dest) {

        StringBuilder origins = new StringBuilder();
        StringBuilder destinations = new StringBuilder();

        for (LatLng item : orig) {
            origins.append(item.getLatitude() + "," + item.getLongitude() + "|");
        }

        for (LatLng item : dest) {
            destinations.append(item.getLatitude() + "," + item.getLongitude() + "|");
        }

        origins = origins.deleteCharAt(origins.length() - 1);
        destinations = destinations.deleteCharAt(destinations.length() - 1);

        StringBuilder parameters = new StringBuilder("output=json&origins=" + origins.toString() + "&destinations=" + destinations.toString() + "&ak=lbN2GqgqKgLiR9GSDw6DSVKqjb7GI5hE");

        List<Result> result = new ArrayList<Result>();

        String json = HttpClient.sendRequest(UrlDomain.BAIDU_MAP_API_ROUTEMATRIX_HTTP_URL, action, parameters.toString(), HttpClient.METHOD_GET);

        JSONObject obj = JSONObject.fromObject(json);

        if (obj.get("status").toString().equals("0")) {

            JSONArray arr = obj.getJSONArray("result");

            int distance = -1, duration = -1;

            for (int i = 0; i < arr.size(); i++) {
                distance = arr.getJSONObject(i).getJSONObject("distance").getInt("value");
                duration = arr.getJSONObject(i).getJSONObject("duration").getInt("value");

                result.add(new Result(distance, duration));
            }
        }

        return result;
    }

    public static Terminal getTerminalTraverse(List<LatLng> list, LatLng latLng) {

        //定义网格
        double lng1 = list.stream().mapToDouble(LatLng::getLongitude).max().getAsDouble();
        double lng2 = list.stream().mapToDouble(LatLng::getLongitude).min().getAsDouble();
        double lat1 = list.stream().mapToDouble(LatLng::getLatitude).max().getAsDouble();
        double lat2 = list.stream().mapToDouble(LatLng::getLatitude).min().getAsDouble();

        /*
        double lng1 = latLng.getLongitude() + 0.006;
        double lng2 = latLng.getLongitude() - 0.006;
        double lat1 = latLng.getLatitude() + 0.006;
        double lat2 = latLng.getLatitude() - 0.006;
         */

        List<Grid> grid = new ArrayList();

        double lng_lower, lng_upper, lat_lower, lat_upper;
        BigDecimal lng_b, lat_b, I, I1, J, J1;

        lng_b = new BigDecimal(lng2);
        lat_b = new BigDecimal(lat2);

        double z = 0.0006;
        BigDecimal power = new BigDecimal(z);
        int x = (int) Math.ceil((lng1 - lng2) / z);
        int y = (int) Math.ceil((lat1 - lat2) / z);

        //System.out.println(x+"/"+y);

        for (int i = 0; i < x; i++) {
            I = new BigDecimal(i);
            I1 = new BigDecimal(i - 1);

            for (int j = 0; j < y; j++) {
                J = new BigDecimal(j);
                J1 = new BigDecimal(j - 1);

                lng_lower = lng_b.add(I1.multiply(power)).doubleValue();
                lng_upper = lng_b.add(I.multiply(power)).doubleValue();
                lat_lower = lat_b.add(J1.multiply(power)).doubleValue();
                lat_upper = lat_b.add(J.multiply(power)).doubleValue();

                grid.add(new Grid((i * y + j), lng_lower, lng_upper, lat_lower, lat_upper));
            }
        }

        List<Terminal> temp = new ArrayList();

        for (Grid cell : grid) {
            temp.addAll(getTerminalResult(cell, list, 1));
        }

        temp.removeIf(g -> g.getDistance() == Integer.MAX_VALUE);

        return Collections.min(temp);
    }

    public static Terminal getTerminal(List<LatLng> list) {

        //定义网格
        double lng1 = list.stream().mapToDouble(LatLng::getLongitude).max().getAsDouble();
        double lng2 = list.stream().mapToDouble(LatLng::getLongitude).min().getAsDouble();
        double lat1 = list.stream().mapToDouble(LatLng::getLatitude).max().getAsDouble();
        double lat2 = list.stream().mapToDouble(LatLng::getLatitude).min().getAsDouble();

        int z = 5;
        BigDecimal power = new BigDecimal(z);
        List<Grid> grid = new ArrayList();

        double lng_lower, lng_upper, lat_lower, lat_upper;
        BigDecimal lng, lat, lng_b, lat_b, I, I1, J, J1;
        MathContext mc = new MathContext(10, RoundingMode.DOWN);

        lng = new BigDecimal((lng1 - lng2));
        lat = new BigDecimal((lat1 - lat2));
        lng_b = new BigDecimal(lng2);
        lat_b = new BigDecimal(lat2);

        for (int i = 0; i < z; i++) {
            I = new BigDecimal(i);
            I1 = new BigDecimal(i - 1);

            for (int j = 0; j < z; j++) {
                J = new BigDecimal(j);
                J1 = new BigDecimal(j - 1);

                lng_lower = lng_b.add(lng.multiply(I1.divide(power, mc))).doubleValue();
                lng_upper = lng_b.add(lng.multiply(I.divide(power, mc))).doubleValue();
                lat_lower = lat_b.add(lat.multiply(J1.divide(power, mc))).doubleValue();
                lat_upper = lat_b.add(lat.multiply(J.divide(power, mc))).doubleValue();

                grid.add(new Grid((i * z + j), lng_lower, lng_upper, lat_lower, lat_upper));
            }
        }

        //随机选点
        int k = 100, v = 250;
        List<Terminal> initialSolution = new ArrayList();
        List<Integer> initialDeviation = new ArrayList();

        for (Grid cell : grid) {
            List<Terminal> temp = getTerminalResult(cell, list, k);
            initialSolution.add(Collections.min(temp));

            temp.removeIf(g -> g.getDistance() == Integer.MAX_VALUE);

            //计算网格单元格分数的上限和下限
            if (temp.size() > 1)
                initialDeviation.add(Collections.max(temp).getDistance() - Collections.min(temp).getDistance());
        }

        int standardDeviation = (int) (initialDeviation.stream().mapToInt((x) -> x).summaryStatistics().getAverage() / 2);

        //评估
        grid = getTerminalEvaluation(initialSolution, grid, standardDeviation);

        List<Terminal> candidateSolution = new ArrayList();

        //冷启动
        candidateSolution.addAll(initialSolution);

        for (int i = 0; i < 30; i++) {
            for (Grid cell : grid) {
                int compution = (int) Math.round(v * cell.getProbability());
                if (compution > 0) {
                    Terminal t = Collections.min(getTerminalResult(cell, list, compution));
                    if (t.getDistance() < candidateSolution.get(t.getId()).getDistance()) {
                        candidateSolution.set(t.getId(), t);
                        grid = getTerminalEvaluation(candidateSolution, grid, standardDeviation);
                    }
                }
            }

            Collections.min(candidateSolution);
        }

        return Collections.min(candidateSolution);
    }

    private static List<Terminal> getTerminalResult(Grid cell, List<LatLng> list, int k) {

        List<Terminal> temp = new ArrayList();

        List<String> accessKey = getAccessKey();

        for (int i = 0; i < k; i++) {

            Random random = new Random();
            double seed1 = random.nextDouble();
            double seed2 = random.nextDouble();
            double longitude = cell.getLngLower() + seed1 * (cell.getLngUpper() - cell.getLngLower());
            double latitude = cell.getLatLower() + seed2 * (cell.getLatUpper() - cell.getLatLower());

            LatLng terminal = new LatLng(latitude, longitude);

            List<Integer> distance = new ArrayList<Integer>();
            int sum = 0;

            //计算距离
            for (LatLng vertex : list) {

                try {
                    if (accessKey.size() > 0) {
                        String ak = accessKey.get(0);

                        Result result = Distance(ak, UrlDomain.ACTION_RIDING, terminal, vertex);

                        distance.add(result.getDistance());

                        if (result.getDistance() < 0) {
                            accessKey.remove(ak);
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            if (distance.contains(-1)) {
                sum = Integer.MAX_VALUE;
            } else {
                for (Integer item : distance) {
                    sum += item;
                }

                if (sum <= 0)
                    sum = Integer.MAX_VALUE;
                else
                    System.out.println(sum);
            }

            temp.add(new Terminal(cell.getId(), terminal, sum));
        }

        return temp;
    }

    public static LatLng randPoint(Circle circle) {
        double r, theta;

        r = Math.sqrt(Math.pow(circle.getR(), 2) * Math.random());
        theta = 2 * Math.random() * Math.PI;
        double longitude = circle.getX() + r * Math.cos(theta);
        double latitude = circle.getY() + r * Math.sin(theta);
        return new LatLng(latitude, longitude);
    }

    private static List<Terminal> getTerminalResult(Circle circle, List<Circle> exclude, List<LatLng> list, int k) {

        List<Terminal> temp = new ArrayList();

        List<String> accessKey = getAccessKey();

        LatLng center = new LatLng(circle.getY(), circle.getX());

        for (int i = 0; i < k; i++) {

            LatLng latLng = new LatLng(0, 0);

            boolean invalid = true;

            while (invalid) {

                //在圆内随机生成点
                latLng = randPoint(circle);

                //求得随机点到圆心的欧氏距离
                double dist = getEuclideanDistance(center, latLng);

                if (dist < circle.getR()) {

                    if (exclude.isEmpty()) {
                        invalid = false;
                    } else {
                        for (Circle c : exclude) {
                            if (getEuclideanDistance(new LatLng(c.getY(), c.getX()), latLng) > c.getR()) {
                                invalid = false;
                            }
                        }
                    }
                }
            }

            LatLng terminal = latLng;

            List<Integer> distance = new ArrayList<Integer>();
            int sum = 0;

            //计算距离
            for (LatLng vertex : list) {

                try {
                    if (accessKey.size() > 0) {

                        String ak = accessKey.get(0);

                        Result result = Distance(ak, UrlDomain.ACTION_RIDING, terminal, vertex);

                        distance.add(result.getDistance());

                        if (result.getDistance() < 0) {
                            accessKey.remove(ak);
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            if (distance.contains(-1)) {
                sum = Integer.MAX_VALUE;
            } else {
                for (Integer item : distance) {
                    sum += item;
                }

                if (sum <= 0)
                    sum = Integer.MAX_VALUE;
                else
                    System.out.println(sum);
            }

            temp.add(new Terminal(0, terminal, sum));
        }

        return temp;
    }

    private static List<Grid> getTerminalEvaluation(List<Terminal> list, List<Grid> grids, int standardDeviation) {

        BigDecimal sum = new BigDecimal(0);
        int max = Collections.max(list).getDistance();
        int min = Collections.min(list).getDistance();
        BigDecimal range = new BigDecimal(max - min);

        for (Terminal t : list) {
            if (t.getDistance() > min + standardDeviation) {
                Terminal item = new Terminal(t.getId(), t.getLatLng(), max);
                list.set(t.getId(), item);
            }
        }

        for (Terminal t : list) {
            sum = sum.add(new BigDecimal(max - t.getDistance()).divide(range, 10, ROUND_HALF_DOWN));
        }

        for (Terminal t : list) {
            BigDecimal product = sum.multiply(range);

            double probability = new BigDecimal(max - t.getDistance()).divide(product, 10, ROUND_HALF_DOWN).doubleValue();

            grids.get(t.getId()).setProbability(probability);
        }

        return grids;
    }

    public static Terminal getCircleSearch(List<LatLng> list) {

        //构造资源链
        int v = 100;

        List<Terminal> candidateSolution = new ArrayList();
        List<Circle> exclude = new ArrayList();

        //计算坐标之间的最大距离
        double max_center_dist = Double.MIN_VALUE;

        //距离
        double dist;

        //实例圆
        Circle circle;

        //交叉点集合
        double[] intersect;

        //相交圆
        CirIntersect cirIntersect;

        LatLng optLoc;

        for (int i = 0; i < list.size(); i++) {
            for (int j = i + 1; j < list.size(); j++) {

                dist = getEuclideanDistance(list.get(i), list.get(j));

                if (max_center_dist < dist)
                    max_center_dist = dist;
            }
        }

        //设定半径的增长步长
        double stepSize = (max_center_dist / 2) / 5;

        //构造半径
        double radius = max_center_dist/ 2 + stepSize;

        //构造圆的集合
        List<Circle> circles = new ArrayList();

        for (LatLng item : list) {
            circles.add(new Circle(item.getLongitude(), item.getLatitude(), radius));
        }

        List<LatLng> intersection = new ArrayList();

        //构造两圆之间的交集
        for (int i = 0; i < circles.size(); i++) {
            for (int j = i + 1; j < circles.size(); j++) {
                cirIntersect = new CirIntersect(circles.get(i), circles.get(j));
                intersect = cirIntersect.intersect();

                if (intersect.length > 0) {
                    //两个交点
                    intersection.add(new LatLng(intersect[1], intersect[0]));
                    intersection.add(new LatLng(intersect[3], intersect[2]));
                }
            }
        }

        List<LatLng> deleteList = new ArrayList();

        //移除在相交区域以外的点
        for (LatLng p : intersection) {
            for (Circle c : circles) {

                //计算点到圆心的距离
                dist = getEuclideanDistance(p, new LatLng(c.getY(), c.getX()));

                if (Math.floor(dist * 10000000) > Math.floor(c.getR() * 10000000))
                    deleteList.add(p);
            }
        }

        intersection.removeAll(deleteList);

        //确定搜索区域的初始中心点
        LatLng center = LocationUtils.GetCenterPointFromListOfCoordinates(intersection);

        for (int i = 0; i < 100; i++) {

            //构造最大可能性覆盖的搜索区域
            circle = new Circle(center.getLongitude(), center.getLatitude(), stepSize);

            //求得设施的集合
            candidateSolution.addAll(getTerminalResult(circle, exclude, list, v));

            //求得最优位置
            optLoc = Collections.min(candidateSolution).getLatLng();

            //更新圆心
            if (center != optLoc) {
                center = optLoc;
            } else {
                center = LocationUtils.GetCenterPointFromListOfCoordinates(intersection);
            }

            exclude.add(circle);
        }

        return Collections.min(candidateSolution);
    }

    /**
     * 根据输入的地点坐标计算中心点
     *
     * @param List
     */
    public static LatLng GetCenterPointFromListOfCoordinates(List<LatLng> List) {
        int total = List.size();
        double X = 0, Y = 0, Z = 0;

        for (LatLng item : List) {
            double lat, lon, x, y, z;
            lat = item.getLatitude() * PI / 180;
            lon = item.getLongitude() * PI / 180;
            x = Math.cos(lat) * Math.cos(lon);
            y = Math.cos(lat) * Math.sin(lon);
            z = Math.sin(lat);
            X += x;
            Y += y;
            Z += z;
        }

        X = X / total;
        Y = Y / total;
        Z = Z / total;
        double Lon = Math.atan2(Y, X);
        double Hyp = Math.sqrt(X * X + Y * Y);
        double Lat = Math.atan2(Z, Hyp);
        return new LatLng(Lat * 180 / PI, Lon * 180 / PI);
    }

    /**
     * 根据中心坐标获取指定距离的随机坐标点
     *
     * @param center   中心坐标
     * @param distance 离中心坐标距离（单位：米）
     * @return 随机坐标
     */
    public static LatLng GetRandomLocation(LatLng center, double distance) {
        if (distance <= 0) distance = 50;
        double lat, lon, brg;
        double dist = 0;
        double rad360 = 2 * PI;
        distance = distance / 1000;
        LatLng location = new LatLng();
        double maxdist = distance;
        maxdist = maxdist / EARTH_RADIUS;
        double startlat = rad(center.getLatitude());
        double startlon = rad(center.getLongitude());
        double cosdif = Math.cos(maxdist) - 1;
        double sinstartlat = Math.sin(startlat);
        double cosstartlat = Math.cos(startlat);
        dist = Math.acos((new Random().nextDouble() * cosdif + 1));
        brg = rad360 * new Random().nextDouble();
        lat = Math.asin(sinstartlat * Math.cos(dist) + cosstartlat * Math.sin(dist) * Math.cos(brg));
        lon = deg(normalizeLongitude(startlon * 1 + Math.atan2(Math.sin(brg) * Math.sin(dist) * cosstartlat, Math.cos(dist) - sinstartlat * Math.sin(lat))));
        lat = deg(lat);
        location.setLatitude(padZeroRight(lat));
        location.setLongitude(padZeroRight(lon));
        return location;
    }

    /**
     * 角度
     *
     * @param rd
     * @return
     */
    static double deg(double rd) {
        return (rd * 180 / Math.PI);
    }

    static double normalizeLongitude(double lon) {
        double n = PI;
        if (lon > n) {
            lon = lon - 2 * n;
        } else if (lon < -n) {
            lon = lon + 2 * n;
        }
        return lon;
    }

    static double padZeroRight(double s) {
        double sigDigits = 8;
        s = Math.round(s * Math.pow(10, sigDigits)) / Math.pow(10, sigDigits);
        return s;
    }

    /**
     * 推荐上车点
     *
     * @param latLng
     */
    public static List<LatLng> getRecommendStops(String ak, LatLng latLng) {

        StringBuilder parameters = new StringBuilder("location=" + latLng.getLongitude() + "," + latLng.getLatitude() + "&coordtype=bd09ll&ak=" + ak);

        List<LatLng> List = new ArrayList<LatLng>();

        String json = HttpClient.sendRequest(UrlDomain.BAIDU_MAP_API_PARKING_HTTP_URL, UrlDomain.ACTION_SEARCH, parameters.toString(), HttpClient.METHOD_GET);

        JSONObject obj = JSONObject.fromObject(json);

        try {
            JSONArray arr = obj.getJSONArray("recommendStops");

            for (int i = 0; i < arr.size(); i++) {

                //推荐上车点经度（百度经纬度 bd09ll）
                Double longitude = arr.getJSONObject(i).getDouble("bd09ll_x");

                //推荐上车点纬度（百度经纬度 bd09ll）
                Double latitude = arr.getJSONObject(i).getDouble("bd09ll_y");

                List.add(new LatLng(latitude, longitude));
            }
        } catch (Exception e) {
        }

        return List;
    }

    /**
     * 路线规划
     *
     * @param action
     * @param orig
     * @param dest
     */
    public static List<LatLng> getRoutes(String ak, String action, LatLng orig, LatLng dest) {

        List<LatLng> List = new ArrayList<LatLng>();

        StringBuilder parameters = new StringBuilder("origin=" + orig.getLatitude() + "," + orig.getLongitude() + "&destination=" + dest.getLatitude() + "," + dest.getLongitude() + "&ak=" + ak);

        String json = HttpClient.sendRequest(UrlDomain.BAIDU_MAP_API_DIRECTION_HTTP_URL, action, parameters.toString(), HttpClient.METHOD_GET);

        JSONObject obj = JSONObject.fromObject(json);

        if (obj.get("status").toString().equals("0")) {

            if (obj.getJSONObject("result").getJSONArray("routes").size() > 0) {

                String latitude = obj.getJSONObject("result").getJSONArray("routes").getJSONObject(0).getJSONObject("origin").get("lat").toString();
                String longitude = obj.getJSONObject("result").getJSONArray("routes").getJSONObject(0).getJSONObject("origin").get("lng").toString();

                Float lat = Float.parseFloat(latitude);
                Float lng = Float.parseFloat(longitude);

                List.add(new LatLng(lat, lng));

                JSONArray arr = obj.getJSONObject("result").getJSONArray("routes").getJSONObject(0).getJSONArray("steps");

                for (int i = 0; i < arr.size(); i++) {

                    latitude = arr.getJSONObject(i).getJSONObject("end_location").get("lat").toString();
                    longitude = arr.getJSONObject(i).getJSONObject("end_location").get("lng").toString();

                    lat = Float.parseFloat(latitude);
                    lng = Float.parseFloat(longitude);

                    List.add(new LatLng(lat, lng));
                }
            }
        } else {
            List.add(new LatLng(-1, -1));
        }

        return List;
    }

    public static LatLng getOptimalBusStation(List<LatLng> list, List<BusStation> busStationlist) {

        //List<String> accessKey = LocationUtils.getAccessKey();

        List<BusStation> candidateList = new ArrayList();
        List<Integer> distance = new ArrayList();

        double lng_lower = list.get(0).getLongitude(), lng_upper = list.get(0).getLongitude(),
                lat_lower = list.get(0).getLatitude(), lat_upper = list.get(0).getLatitude();

        for (LatLng item : list) {
            if (item.getLatitude() < lat_lower) lat_lower = item.getLatitude();
            if (item.getLongitude() < lng_lower) lng_lower = item.getLongitude();
            if (item.getLatitude() > lat_upper) lat_upper = item.getLatitude();
            if (item.getLongitude() > lng_upper) lng_upper = item.getLongitude();
        }

        while (candidateList.isEmpty()) {

            for (BusStation item : busStationlist) {
                if ((item.getLat() > lat_lower && item.getLat() < lat_upper) && (item.getLng() > lng_lower && item.getLng() < lng_upper)) {
                    candidateList.add(item);
                }
            }

            lng_lower -= 0.001;
            lng_upper += 0.001;
            lat_lower -= 0.001;
            lat_upper += 0.001;
        }

        //计算距离最短的站台
        int minRowId = -1;

        for (BusStation item : candidateList) {
            int d = 0;
            for (LatLng latLng : list) {
                /*
                if (accessKey.size() > 0) {

                    String ak = accessKey.get(0);

                    Result result = LocationUtils.Distance(ak, UrlDomain.ACTION_WALKING, latLng, new LatLng(item.getLat(), item.getLng()));

                    if (result.getDistance() < 0) {
                        accessKey.remove(ak);
                    } else {
                        d += result.getDistance();
                    }
                }
                */

                d += LocationUtils.getDistance(latLng, new LatLng(item.getLat(), item.getLng()));

            }
            distance.add(d);
        }

        int min = Collections.min(distance);

        for (int i = 0; i < distance.size(); i++) {
            if (distance.get(i) == min)
                minRowId = i;
        }

        BusStation busStation = candidateList.get(minRowId);

        return new LatLng(busStation.getLat(), busStation.getLng());
    }

    /**
     * 圆形区域检索
     *
     * @param location
     * @param radius
     */
    public static List<BusStation> Place(String ak, LatLng location, int radius) {

        List<BusStation> List = new ArrayList<BusStation>();

        StringBuilder parameters = new StringBuilder("query=公交站&output=json&location=" + location.getLatitude() + "," + location.getLongitude() + "&radius=" + radius + "&page_size=20&ak=" + ak);

        String json = HttpClient.sendRequest(UrlDomain.BAIDU_MAP_API_PLACE_HTTP_URL, UrlDomain.ACTION_SEARCH, parameters.toString(), HttpClient.METHOD_GET);

        JSONObject obj = JSONObject.fromObject(json);

        if (obj.get("status").toString().equals("0")) {

            JSONArray arr = obj.getJSONArray("results");

            for (int i = 0; i < arr.size(); i++) {

                String name = arr.getJSONObject(i).getString("name");
                String latitude = arr.getJSONObject(i).getJSONObject("location").get("lat").toString();
                String longitude = arr.getJSONObject(i).getJSONObject("location").get("lng").toString();
                String address = arr.getJSONObject(i).getString("address");
                String uid = arr.getJSONObject(i).getString("uid");

                Float lat = Float.parseFloat(latitude);
                Float lng = Float.parseFloat(longitude);

                List.add(new BusStation(uid, name, lng, lat, address));
            }
        }

        return List;
    }

    private static List<List<LatLng>> createList(List<LatLng> targe, int size) {
        List<List<LatLng>> listArr = new ArrayList<List<LatLng>>();
        //获取被拆分的数组个数
        int arrSize = targe.size() % size == 0 ? targe.size() / size : targe.size() / size + 1;
        for (int i = 0; i < arrSize; i++) {
            List<LatLng> sub = new ArrayList<LatLng>();
            //把指定索引数据放入到list中
            for (int j = i * size; j <= size * (i + 1) - 1; j++) {
                if (j <= targe.size() - 1) {
                    sub.add(targe.get(j));
                }
            }
            listArr.add(sub);
        }
        return listArr;
    }

    public static LatLng randomLatLng(double MinLon, double MaxLon, double MinLat, double MaxLat) {
        BigDecimal db = new BigDecimal(Math.random() * (MaxLon - MinLon) + MinLon);
        double lon = db.setScale(6, BigDecimal.ROUND_HALF_UP).doubleValue();
        db = new BigDecimal(Math.random() * (MaxLat - MinLat) + MinLat);
        double lat = db.setScale(6, BigDecimal.ROUND_HALF_UP).doubleValue();
        Map<String, String> map = new HashMap<String, String>();
        return new LatLng(lat, lon);
    }
}
