package com.guet.util;

import com.guet.entity.Arc;
import com.guet.entity.Duty;
import com.guet.entity.Location;
import com.guet.entity.Trip;

import java.sql.Time;
import java.util.*;
import java.util.concurrent.RecursiveTask;
import java.util.stream.Collectors;

import static com.guet.util.TimeUtils.getTimeDifference;
import static com.guet.web.ScheduleController.*;

public class SeqGeneratorTask extends RecursiveTask<List<Duty>> {

    private static final int THRESHOLD = 2;
    private int start;
    private int end;
    private Date time;
    private List<Trip> tripList;
    private List<Location> depotList;
    private LinkedList<Arc> dharcList;
    private LinkedList<Arc> pullarcList;

    public SeqGeneratorTask(int start, int end, Date time, List<Trip> tripList, List<Location> depotList, LinkedList<Arc> dharcList, LinkedList<Arc> pullarcList) {
        this.start = start;
        this.end = end;
        this.time = time;
        this.depotList = depotList;
        this.tripList = tripList;
        this.dharcList = dharcList;
        this.pullarcList = pullarcList;
    }

    @Override
    protected List<Duty> compute() {

        List<Duty> candidate = new ArrayList<Duty>();

        //判断任务是否足够小
        boolean canCompute = (end - start) <= THRESHOLD;
        if (canCompute) {
            //如果小于阈值，就进行运算
            for (int i = start; i <= end; i++) {

                //随机生成一个行程序列
                List<Trip> trips = sequenceGenerator(time, tripList, dharcList);

                //生成工作时间
                long duration = durationGenerator(trips, depotList, pullarcList);

                //对工作时间进行可行性判断
                while (duration > max_working_time) {

                    //修剪
                    trips.remove(trips.size() - 1);

                    //行程序列分析报告
                    duration = durationGenerator(trips, depotList, pullarcList);
                }

                Duty duty = dutyGenerator(trips, depotList, pullarcList, dharcList);

                //加入到候选集
                if (!candidate.contains(duty)) {
                    candidate.add(duty);
                }
            }
        } else {

            //如果大于阈值，就再进行任务拆分
            int middle = (start + end) / 2;
            SeqGeneratorTask leftTask = new SeqGeneratorTask(start, middle, time, tripList, depotList, dharcList, pullarcList);
            SeqGeneratorTask rightTask = new SeqGeneratorTask(middle + 1, end, time, tripList, depotList, dharcList, pullarcList);

            //执行子任务
            leftTask.fork();
            rightTask.fork();

            //等待子任务执行完，并得到执行结果
            List<Duty> leftResult = leftTask.join();
            List<Duty> rightResult = rightTask.join();

            //合并子任务
            candidate.addAll(leftResult);
            candidate.addAll(rightResult);
        }

        return candidate;
    }

    private List<Trip> sequenceGenerator(Date time, List<Trip> tripList, LinkedList<Arc> dharcList) {

        List<Trip> trips = new ArrayList<Trip>();

        //构建时间段最前的顶点
        List<Trip> vertices = tripList.stream().filter(x -> x.getDeparture().equals(time)).collect(Collectors.toList());

        //随机选择一个顶点
        Trip vertex = vertices.get(new Random().nextInt(vertices.size()));
        trips.add(vertex);

        while (true) {

            String id = vertex.getId();

            //获得当前起点的所有边
            List<Arc> arcs = dharcList.stream().filter(x -> x.getSId().equals(id)).collect(Collectors.toList());

            //触底，则跳出；没有，则继续。
            if (arcs.size() > 0) {

                //计算总和
                double sum = 0;

                for (Arc item : arcs) {
                    sum += 1 / item.getCost();
                }

                for (Arc item : arcs) {
                    item.setProbability(10000 / (sum * item.getCost()));
                }

                //排序
                Collections.sort(arcs);

                double bound = 0;

                for (Arc item : arcs) {

                    item.setMin(bound);

                    bound += item.getProbability();

                    item.setMax(bound);
                }

                double max = arcs.get(arcs.size() - 1).getMax();
                double min = arcs.get(0).getMin();

                Double seed = Math.random() * (max - min);

                //随机选择一个边
                Arc arc = arcs.stream().filter(x -> x.getMin() <= seed && seed < x.getMax()).collect(Collectors.toList()).get(0);

                //候选一个顶点
                vertex = tripList.stream().filter(x -> x.getId().equals(arc.getDId())).collect(Collectors.toList()).get(0);

                //放入顶点集
                trips.add(vertex);

            } else {
                //跳出循环
                break;
            }
        }

        return trips;
    }

    private long durationGenerator(List<Trip> list, List<Location> depotList, LinkedList<Arc> pullarcList) {
        //排序
        Collections.sort(list);

        Trip first = list.get(0);
        Trip last = list.get(list.size() - 1);

        String depot_id = queryDepot(list, depotList, pullarcList).getId();

        //构建出场的边
        Arc pull_out = pullarcList.stream().filter(x -> x.getSId().equals(depot_id) && x.getDId().equals(first.getId())).collect(Collectors.toList()).get(0);
        Arc pull_in = pullarcList.stream().filter(x -> x.getSId().equals(last.getId()) && x.getDId().equals(depot_id)).collect(Collectors.toList()).get(0);

        Date start_time = TimeUtils.getTimeMinusSeconds(first.getDeparture(), pull_out.getDuration());
        Date last_time = TimeUtils.getTimePlusSeconds(last.getDeparture(), last.getDuration());
        Date end_time = TimeUtils.getTimePlusSeconds(last_time, pull_in.getDuration());
        long duration = getTimeDifference(start_time, end_time);

        return duration;
    }

    private Duty dutyGenerator(List<Trip> list, List<Location> depotList, LinkedList<Arc> pullarcList, LinkedList<Arc> dharcList) {

        //排序
        Collections.sort(list);

        Trip first = list.get(0);
        Trip last = list.get(list.size() - 1);

        String depot_id = queryDepot(list, depotList, pullarcList).getId();

        //构建出场的边
        Arc pull_out = pullarcList.stream().filter(x -> x.getSId().equals(depot_id) && x.getDId().equals(first.getId())).collect(Collectors.toList()).get(0);
        Arc pull_in = pullarcList.stream().filter(x -> x.getSId().equals(last.getId()) && x.getDId().equals(depot_id)).collect(Collectors.toList()).get(0);

        Date start_time = TimeUtils.getTimeMinusSeconds(first.getDeparture(), pull_out.getDuration());
        Date last_time = TimeUtils.getTimePlusSeconds(last.getDeparture(), last.getDuration());
        Date end_time = TimeUtils.getTimePlusSeconds(last_time, pull_in.getDuration());
        long duration = getTimeDifference(start_time, end_time);

        //实际时间消耗
        int travelTime = 0;
        int idleTime = pull_out.getDuration() + pull_in.getDuration();
        int travelMileage = 0;
        int idleMileage = pull_out.getDistance() + pull_in.getDistance();
        Double travelCost = 0.0;
        Double idleCost = pull_out.getCost() + pull_in.getCost();
        List<Arc> arcs = new ArrayList<Arc>();

        //构建边
        for (int i = 0; i < list.size() - 1; i++) {
            Trip prior = list.get(i);
            Trip next = list.get(i + 1);
            arcs.addAll(dharcList.stream().filter(x -> x.getSId().equals(prior.getId()) && x.getDId().equals(next.getId())).collect(Collectors.toList()));
        }

        for (Arc item : arcs) {
            idleMileage += item.getDistance();
            idleTime += item.getDuration();
            idleCost += item.getCost();
        }

        for (Trip item : list) {
            travelMileage += item.getDistance();
            travelTime += item.getDuration();
            travelCost += item.getCost();
        }

        Double totalCost = travelCost + idleCost;

        return new Duty(depot_id, list, arcs, start_time, end_time, duration, (int) duration - travelTime - idleTime, travelTime, idleTime, travelMileage, idleMileage, travelCost, idleCost, totalCost);
    }

    private Location queryDepot(List<Trip> list, List<Location> depotList, LinkedList<Arc> pullarcList) {

        Trip first = list.get(0);
        Trip last = list.get(list.size() - 1);

        List<Double> cost = new ArrayList<Double>();

        for (Location item : depotList) {
            Arc pull_out = pullarcList.stream().filter(x -> x.getSId().equals(item.getId()) && x.getDId().equals(first.getId())).collect(Collectors.toList()).get(0);
            Arc pull_in = pullarcList.stream().filter(x -> x.getSId().equals(last.getId()) && x.getDId().equals(item.getId())).collect(Collectors.toList()).get(0);
            cost.add(pull_out.getCost() + pull_in.getCost());
        }

        double min = Collections.min(cost);

        return depotList.get(cost.indexOf(min));
    }
}
