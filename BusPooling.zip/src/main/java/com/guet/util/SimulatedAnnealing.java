package com.guet.util;

import com.guet.core.UrlDomain;
import com.guet.entity.LatLng;
import com.guet.entity.Result;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.lang.Math;

public class SimulatedAnnealing {

    public List<LatLng> list;
    public double lngUpper;
    public double lngLower;
    public double latUpper;
    public double latLower;
    private List<String> accessKey = LocationUtils.getAccessKey();

    public double[] SimulatedAnnealing()//Simulated Annealing Function
    {
        double[] array = new double[3];

        Random random = new Random();
        double seed1 = random.nextDouble();
        double seed2 = random.nextDouble();
        double xZero = lngLower + seed1 * (lngUpper - lngLower);
        double yZero = latLower + seed2 * (latUpper - latLower);

        double tZero = 140;
        double alpha = 0.98;
        int m = 100;
        int n = 100;

        double t = tZero;
        double x = xZero;
        double y = yZero;
        double xFinal = xZero;
        double yFinal = yZero;

        int global = func(x, y);

        Random ranat = new Random();
        for (int i = 1; i <= m; i++) {
            for (int j = 1; j <= n; j++) {

                int min = Integer.MAX_VALUE;
                double xTemp = moveOpX(x);
                double yTemp = moveOpY(y);

                while (xTemp > lngUpper || xTemp < lngLower) {
                    xTemp = moveOpX(x);
                }

                while (yTemp > latUpper || yTemp < latLower) {
                    yTemp = moveOpY(y);
                }

                int temp = func(xTemp, yTemp);

                if (temp <= global) {
                    min = temp;
                    x = xTemp;
                    y = yTemp;
                } else {
                    if (ranat.nextGaussian() <= metroPol(temp, global, t)) {
                        min = temp;
                        x = xTemp;
                        y = yTemp;
                    }
                }
                if (min <= global) {
                    xFinal = x;
                    yFinal = y;
                    global = min;
                }
            }
            t = t * alpha;
        }
        array[0] = xFinal;
        array[1] = yFinal;
        array[2] = global;
        return array;
    }

    public static double moveOpX(double num) {//Move Operator for X
        Random random = new Random();
        double neigh = num + random.nextGaussian();
        return neigh;
    }

    public static double moveOpY(double num2) {//Move Operator Y
        Random random2 = new Random();
        double neigh2 = num2 + random2.nextGaussian();
        return neigh2;
    }

    private int func(double longitude, double latitude) {//Function that is operated

        LatLng terminal = new LatLng(latitude, longitude);

        //���Ż��ĺ���(�������)
        List<Integer> distance = new ArrayList<Integer>();
        int sum = 0;

        //�������
        for (LatLng vertex : list) {
            try {
                if (accessKey.size() > 0) {
                    String ak = accessKey.get(0);

                    Result result = LocationUtils.Distance(ak, UrlDomain.ACTION_RIDING, terminal, vertex);

                    distance.add(result.getDistance());

                    if (result.getDistance() < 0) {
                        accessKey.remove(ak);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (distance.contains(-1)) {
            sum = Integer.MAX_VALUE;
        } else {
            for (Integer item : distance) {
                sum += item;
            }

            if (sum <= 0)
                sum = Integer.MAX_VALUE;
        }
        System.out.println(sum);
        return sum;
    }

    static double metroPol(double z1, double z2, double temperature) {//Metropolis statement
        double res = Math.pow(Math.E, -((z1 - z2) / temperature));
        return res;
    }
}