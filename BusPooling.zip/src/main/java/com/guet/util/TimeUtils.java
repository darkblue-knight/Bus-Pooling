package com.guet.util;

import java.time.ZoneId;
import java.time.LocalDateTime;
import java.util.Date;

import static java.lang.Math.abs;

/**
 * 时间工具类
 *
 * @author baidu
 *
 */
public class TimeUtils {

    public static final int MILLIS_TO_SECONDS = 1000;

    public static final int MILLIS_TO_MINUTES = 60 * 1000;

    /**
     * 获取当前分钟数
     *
     * @return
     */
    public static long getCurrentTimeOfMinutes() {
        return System.currentTimeMillis() / MILLIS_TO_MINUTES;
    }

    /**
     * 获取当前数
     *
     * @return
     */
    public static long getCurrentTimeOfSeconds() {
        return System.currentTimeMillis() / MILLIS_TO_SECONDS;
    }


    /**
     * 计算时间差
     */
    public static long getTimeDifference(Date d1, Date d2) {
        return (d2.getTime() - d1.getTime()) / MILLIS_TO_SECONDS;
    }

    /**
     * 计算时间差
     */
    public static Date getTimePlusSeconds(Date d1, int duration) {

        LocalDateTime localDateTime = d1.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();

        localDateTime = localDateTime.plusSeconds(duration);

        return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
    }

    public static Date getTimeMinusSeconds(Date d1, int duration) {

        LocalDateTime localDateTime = d1.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();

        localDateTime = localDateTime.minusSeconds(duration);

        return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
    }
}
