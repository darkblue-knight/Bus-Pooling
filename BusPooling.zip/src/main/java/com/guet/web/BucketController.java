package com.guet.web;

import com.guet.core.UrlDomain;
import com.guet.entity.*;
import com.guet.service.BucketService;
import com.guet.service.BusShareService;
import com.guet.service.RoutesService;
import com.guet.service.StopService;
import com.guet.util.LocationUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;

import static com.guet.util.LocationUtils.getAccessKey;

@Controller
@RequestMapping(value = "/Bucket", method = RequestMethod.GET)
public class BucketController {

    @Autowired
    private BusShareService busShareService;

    @Autowired
    private BucketService bucketService;

    @Autowired
    private StopService stopService;

    @Autowired
    private RoutesService routesService;

    @RequestMapping(value = "/Update", method = RequestMethod.GET)
    private String Update(Model model) {
        List<String> accessKey = getAccessKey();

        LatLng pickup = new LatLng();
        LatLng delivery = new LatLng();

        List<RecommendStops> recommendStops = stopService.queryAll();

        List<Bucket> ls = bucketService.queryUpdateBucketNo();

        List<String> rs = new ArrayList<String>();

        for (int i = 0; i < ls.size(); i++) {

            for (RecommendStops item : recommendStops) {
                if (item.getCode() == ls.get(i).getCode() && item.getChild() == ls.get(i).getChild()) {
                    pickup = new LatLng(item.getSLat(), item.getSLng());
                    delivery = new LatLng(item.getDLat(), item.getDLng());
                }
            }

            LatLng orgi;
            LatLng dest;

            BusShare busShare = busShareService.getModel(ls.get(i).getBusShareId());

            orgi = new LatLng(busShare.getSLat(), busShare.getSLng());
            dest = new LatLng(busShare.getDLat(), busShare.getDLng());

            try {
                if (accessKey.size() > 0) {

                    String ak = accessKey.get(0);

                    Result orgiToPickup = LocationUtils.Distance(ak, UrlDomain.ACTION_WALKING, orgi, pickup);
                    Result deliveryToDest = LocationUtils.Distance(ak, UrlDomain.ACTION_WALKING, delivery, dest);
                    Result riding = LocationUtils.Distance(ak, UrlDomain.ACTION_RIDING, orgi, dest);
                    Result driving = LocationUtils.Distance(ak, UrlDomain.ACTION_DRIVING, orgi, dest);

                    bucketService.update(
                            ls.get(i).getId(),
                            orgiToPickup.getDistance(), orgiToPickup.getDuration(),
                            deliveryToDest.getDistance(), deliveryToDest.getDuration(),
                            riding.getDistance(), riding.getDuration(),
                            driving.getDistance(), driving.getDuration()
                    );

                    if (orgiToPickup.getDistance() < 0 && deliveryToDest.getDistance() < 0 && riding.getDistance() < 0 && driving.getDistance() < 0) {
                        accessKey.remove(ak);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            //rs.add("update taxi070220.bucket set s_distance=" + orgiToPickup.getDistance() + ",s_duration=" + orgiToPickup.getDuration() + ",d_distance=" + deliveryToDest.getDistance() + ",d_duration=" + deliveryToDest.getDuration() + ",riding_distance=" + riding.getDistance() + ",riding_duration=" + riding.getDuration() +",driving_duration="+ driving.getDistance() + ",driving_duration=" + driving.getDuration() + " where id='" + ls.get(i).getId() + "'；");
        }


        model.addAttribute("list", rs);
        model.addAttribute("msg", "Bucket Update completed!");
        model.addAttribute("name", "Console");

        return "cluster";
    }

    @RequestMapping(value = "/List", method = RequestMethod.GET)
    private String List(@RequestParam int id, Model model) {
        //加载所有轨迹的路径
        List<Routes> routesList = routesService.getList();
        List<Bucket> bucketList = new ArrayList<Bucket>();
        List<BusShare> busShareList = new ArrayList<BusShare>();
        busShareList = busShareService.getList(id);
        List<String[]> list = new ArrayList();

        for (int i = 0; i < busShareList.size(); i++) {
            String[] item = new String[5];
            item[0] = Integer.toString(i);
            item[1] = busShareList.get(i).getSLng().toString();
            item[2] = busShareList.get(i).getSLat().toString();
            item[3] = busShareList.get(i).getDLng().toString();
            item[4] = busShareList.get(i).getDLat().toString();
            list.add(item);
        }

        Matrix matrix = busShareService.getMatrix(busShareList, routesList);

        model.addAttribute("ls", bucketList);
        model.addAttribute("list", list);
        model.addAttribute("matrix", matrix.getEntry());
        return "cluster";
    }
}
