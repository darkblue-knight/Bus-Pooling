package com.guet.web;

import com.guet.entity.*;
import com.guet.service.BusShareService;
import com.guet.service.BucketService;
import com.guet.service.RoutesService;

import com.guet.util.TimeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Controller
@RequestMapping(value = "/BusShare", method = RequestMethod.GET)
public class BusShareController {

    @Autowired
    private BusShareService busShareService;

    @Autowired
    private BucketService bucketService;

    @Autowired
    private RoutesService routesService;

    private static final int limit = 10;//设置每个聚类的容量
    private static final double lng1 = 121.98, lng2 = 121.05, lat1 = 31.5, lat2 = 30.7;

    @RequestMapping(value = "/List3", method = RequestMethod.GET)
    private String List3(Model model) {
        long begin = TimeUtils.getCurrentTimeOfSeconds();

        List<BusShare> list = busShareService.getAll();
        List<Routes> routesList = routesService.getList();

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

        List<Grid> grids;
        double lng_lower, lng_upper, lat_lower, lat_upper;
        BigDecimal lng, lat, lng_b, lat_b, I, I1, J, J1;
        MathContext mc = new MathContext(10, RoundingMode.DOWN);

        lng = new BigDecimal((lng1 - lng2));
        lat = new BigDecimal((lat1 - lat2));
        lng_b = new BigDecimal(lng2);
        lat_b = new BigDecimal(lat2);

        for (int z = 185; z >= 45; z--) {

            BigDecimal power = new BigDecimal(z);

            grids = new ArrayList();

            for (int i = 0; i < z; i++) {
                I = new BigDecimal(i);
                I1 = new BigDecimal(i - 1);

                for (int j = 0; j < z; j++) {
                    J = new BigDecimal(j);
                    J1 = new BigDecimal(j - 1);

                    lng_lower = lng_b.add(lng.multiply(I1.divide(power, mc))).doubleValue();
                    lng_upper = lng_b.add(lng.multiply(I.divide(power, mc))).doubleValue();
                    lat_lower = lat_b.add(lat.multiply(J1.divide(power, mc))).doubleValue();
                    lat_upper = lat_b.add(lat.multiply(J.divide(power, mc))).doubleValue();

                    grids.add(new Grid((i * z + j), lng_lower, lng_upper, lat_lower, lat_upper));
                }
            }

            System.out.println(z + ":[0]" + dateFormat.format(new Date()));

            for (BusShare item : list) {
                item.setSidx(-1);
                item.setDidx(-1);

                for (Grid g : grids) {
                    if (item.getSLng() > g.getLngLower() && item.getSLng() < g.getLngUpper() && item.getSLat() > g.getLatLower() && item.getSLat() < g.getLatUpper())
                        item.setSidx(g.getId());

                    if (item.getDLng() > g.getLngLower() && item.getDLng() < g.getLngUpper() && item.getDLat() > g.getLatLower() && item.getDLat() < g.getLatUpper())
                        item.setDidx(g.getId());
                }
            }

            System.out.println(z + ":[1]" + dateFormat.format(new Date()));

            int[][] matrix = new int[z * z][z * z];

            for (BusShare item : list) {
                if (item.getSIdx() > 0 && item.getDIdx() > 0)
                    matrix[item.getSIdx()][item.getDIdx()] += 1;
            }

            System.out.println(z + ":[2]" + dateFormat.format(new Date()));

            for (int i = 0; i < matrix.length; i++) {
                for (int j = 0; j < matrix[i].length; j++) {
                    if (matrix[i][j] >= limit) {
                        System.out.println(z + ":[#]" + (i * matrix[i].length + j) + "(" + matrix[i][j] + ")," + dateFormat.format(new Date()));

                        final int s_idx = i, d_idx = j;

                        List<BusShare> result = list.stream()
                                .filter(r -> (r.getSIdx() == s_idx) && (r.getDIdx() == d_idx))
                                .collect(Collectors.toList());

                        List<BusShare> candidateList = busShareService.getBusShare(result, routesList, limit);

                        List<String> ids = new ArrayList();

                        candidateList.forEach(item -> ids.add(item.getId()));

                        bucketService.write(ids);

                        busShareService.delete(candidateList);

                        list.removeAll(candidateList);

                        System.out.println(z + ":[#]" + (i * matrix[i].length + j) + ",[list.size]" + list.size() + "(" + candidateList.size() + ")");
                    }
                }
            }
        }

        long end = TimeUtils.getCurrentTimeOfSeconds();

        model.addAttribute("msg", end - begin);
        model.addAttribute("list", list);
        return "detail";
    }

    @RequestMapping(value = "/List2", method = RequestMethod.GET)
    private String List2(Model model) {
        long begin = TimeUtils.getCurrentTimeOfSeconds();

        List<BusShare> list = busShareService.getAll();

        int num = (int) Math.ceil(list.size() / limit);
        int total = list.size();

        List<Graph> candidateList = new ArrayList();

        for (int i = 0; i < 2*num; i++) {
            for (int j = i; j < 2*num; j++) {
                if (i != j) {

                    List<BusShare> node = new ArrayList();
                    node.add(list.get(i));
                    node.add(list.get(j));

                    candidateList.add(new Graph(node, busShareService.getAverageWeight(node)));
                }
            }
        }

        Collections.sort(candidateList);

        List<Graph> eliteList = new ArrayList();

        for (Graph item : candidateList) {
            if (busShareService.getExistNodeNo(eliteList, item) < 0) {
                eliteList.add(item);
            }
        }

        //构建已选中为精英解的集合
        List<String> deleteList = new ArrayList();
        eliteList = eliteList.subList(0, num);
        eliteList.forEach(g -> g.getNode().forEach(x -> deleteList.add(x.getId())));

        //从全解中移除精英解
        List<BusShare> all = new ArrayList();

        for (BusShare item : list) {
            if (!deleteList.contains(item.getId()))
                all.add(item);
        }

        int total2 = all.size();

        //从候选解逐一依次加入到以精英解构成的聚类中
        while (all.size() > total - eliteList.size() * limit) {

            List<BusShare> nodes;
            int x_id = Integer.MIN_VALUE, y_id = Integer.MIN_VALUE;
            double min = Double.MAX_VALUE;

            //构建矩阵，计算当前解对于全局的影响，找到当前对全局影响最小的最优解
            for (int i = 0; i < all.size(); i++) {
                for (int j = 0; j < eliteList.size(); j++) {

                    //若当前聚类的数量已满，不再参加计算
                    if (eliteList.get(j).getNode().size() < limit) {

                        double val = busShareService.compareWeightofGraph(eliteList.get(j).getNode(), all.get(i));

                        if (val < min) {
                            min = val;
                            x_id = i;
                            y_id = j;
                        }
                    }
                }
            }

            //从全解中移除当gid/前的最优解，加入到聚类中
            nodes = eliteList.get(y_id).getNode();
            nodes.add(all.get(x_id));
            all.remove(x_id);

            //重新计算聚类被影响的成员和平均权重
            eliteList.get(y_id).setNode(nodes);
            eliteList.get(y_id).setWeight(busShareService.getAverageWeight(nodes));

            //System.out.println("Phase II:" + all.size() + "/" + total2);
        }

        for (Graph graph : eliteList) {
            List<String> ids = new ArrayList();
            graph.getNode().forEach(item -> ids.add(item.getId()));
            bucketService.write(ids);
        }

        long end = TimeUtils.getCurrentTimeOfSeconds();

        model.addAttribute("msg", end - begin);
        model.addAttribute("candidateList", eliteList);
        model.addAttribute("list", all);
        return "detail";
    }

    @RequestMapping(value = "/List1", method = RequestMethod.GET)
    private String List1(Model model) {
        long begin = TimeUtils.getCurrentTimeOfSeconds();

        while (busShareService.queryCount() > 0) {

            List<BusShare> candidateList = busShareService.getList(0, limit);
            List<BusShare> list = busShareService.getList(limit + 1, 200000);

            for (int i = 0; i < list.size(); i++) {
                candidateList.add(list.get(i));

                /* OD-Pair */

                int maxRowId = busShareService.getMaxRowId(candidateList);
                candidateList.remove(maxRowId);

                //Matrix matrix = busShareService.getMatrix(list, routesList);
                //candidateList.remove(matrix.getMaxRowId());*/
            }

            List<String> ids = new ArrayList();
            candidateList.forEach(b -> ids.add(b.getId()));
            bucketService.write(ids);
            busShareService.delete(candidateList);
        }

        long end = TimeUtils.getCurrentTimeOfSeconds();

        //model.addAttribute("list", list);
        model.addAttribute("msg", end - begin);
        return "detail";
    }

    @RequestMapping(value = "/Insert", method = RequestMethod.GET)
    private String Insert(Model model) {
        List<BusShare> list = busShareService.getAll();

        Collections.shuffle(list);

        while (!list.isEmpty()) {
            List<BusShare> temp = list.subList(0, limit);
            List<String> ids = new ArrayList();
            temp.forEach(b -> ids.add(b.getId()));
            bucketService.write(ids);
            list.removeAll(temp);
        }

        model.addAttribute("msg", null);
        return "detail";
    }

    @RequestMapping(value = "/Statistics", method = RequestMethod.GET)
    private String Statistics(Model model) {

        Double total = 0.0;
        List<Double> ls = new ArrayList<>();

        int count = bucketService.queryBucketNo();

        for (int i = 1; i <= count; i++) {
            List<BusShare> list = busShareService.getList(i);
            Double weight = busShareService.getAverageWeight(list);
            ls.add(weight);
            total += weight;
        }

        model.addAttribute("list", ls);
        model.addAttribute("msg", total / count);
        model.addAttribute("name", "Console");

        return "feedback";
    }
}
