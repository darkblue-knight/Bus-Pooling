package com.guet.web;

import com.guet.core.UrlDomain;
import com.guet.entity.*;
import com.guet.service.*;
import com.guet.util.Genetic;
import com.guet.util.LocationUtils;

import com.guet.util.SimulatedAnnealing;
import com.guet.util.TimeUtils;
import org.apache.commons.math3.ml.clustering.Cluster;
import org.apache.commons.math3.ml.clustering.DoublePoint;
import org.apache.commons.math3.ml.clustering.KMeansPlusPlusClusterer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.text.DecimalFormat;
import java.util.*;

import static com.guet.util.LocationUtils.AccessKey;

@Controller
@RequestMapping(value = "/Depot", method = RequestMethod.GET)
public class DepotController {

    @Autowired
    private BusShareService busShareService;

    @Autowired
    private TripService tripService;

    @Autowired
    private DepotService depotService;

    @Autowired
    private LineService lineService;

    @Autowired
    private ClusterService clusterService;

    @RequestMapping(value = "/cluster", method = RequestMethod.GET)
    private String cluster(Model model) {

        LinkedList<BusShare> busShares = busShareService.queryList();
        List<DoublePoint> points = new ArrayList<DoublePoint>();

        double[] s, d;

        for (BusShare item : busShares) {
            s = new double[2];
            d = new double[2];
            s[0] = item.getSLat();
            s[1] = item.getSLng();
            d[0] = item.getDLat();
            d[1] = item.getDLng();
            points.add(new DoublePoint(s));
            points.add(new DoublePoint(d));
        }

        List<List<DoublePoint>> list = new ArrayList<List<DoublePoint>>();

        int min = Integer.MIN_VALUE;

        while (min < 287803) {
            //for (int j = 0; j < 1000; j++) {

            List<Integer> size = new ArrayList<Integer>();

            KMeansPlusPlusClusterer kMeansPlusPlus = new KMeansPlusPlusClusterer(10);
            List<Cluster<DoublePoint>> cluster = kMeansPlusPlus.cluster(points);

            list = new ArrayList<List<DoublePoint>>();

            for (int i = 0; i < cluster.size(); i++) {
                list.add(cluster.get(i).getPoints());
                size.add(cluster.get(i).getPoints().size());
            }

            //if (min < Collections.min(size))
            min = Collections.min(size);

            //System.out.println("min:" + min);
        }

        for (int i = 0; i < list.size(); i++) {

            List<Clustering> cluster = new ArrayList<Clustering>();

            for (DoublePoint item : list.get(i)) {
                cluster.add(new Clustering(UUID.randomUUID().toString(), i, item.getPoint()[0], item.getPoint()[1]));
            }

            clusterService.add(cluster);
        }

        model.addAttribute("list", list);
        return "cluster";
    }

    @RequestMapping(value = "/exhaustion", method = RequestMethod.GET)
    private String exhaustion(Model model) {

        List<Long> dist = new ArrayList<Long>();

        List<Terminal> coordinates = new ArrayList<Terminal>();

        List<Location> locationList = depotService.queryClusters(1);

        List<LatLng> list = new ArrayList();

        for (Location item : locationList) {
            list.add(new LatLng(item.getLat(), item.getLng()));
        }

        List<LatLng> temp = new ArrayList();
        temp.add(new LatLng(29.828036556044886, 106.43090551046215));
        temp.add(new LatLng(29.824798681425147, 106.42951939534301));
        temp.add(new LatLng(29.82802442952876, 106.4285081902963));
        temp.add(new LatLng(29.828057953198314, 106.43065369391418));
        temp.add(new LatLng(29.827987469043915, 106.42978651924105));
        temp.add(new LatLng(29.827941012510472, 106.42963881831923));
        temp.add(new LatLng(29.828015085416855, 106.4306777102777));
        temp.add(new LatLng(29.825177223579857, 106.42968907653386));
        temp.add(new LatLng(29.828732212355686, 106.43064724734141));
        temp.add(new LatLng(29.824520358880577, 106.43205885514924));
        temp.add(new LatLng(29.826775788892085, 106.43017854797094));
        temp.add(new LatLng(29.827940880008406, 106.43077469469144));
        temp.add(new LatLng(29.830584510167064, 106.43066453069589));
        temp.add(new LatLng(29.827784832233817, 106.43113508120214));
        temp.add(new LatLng(29.82957745, 106.4312666));
        temp.add(new LatLng(29.82465213957906, 106.43282266416958));
        temp.add(new LatLng(29.82790939979658, 106.43090080238548));
        temp.add(new LatLng(29.82843106644674, 106.43162091358897));
        temp.add(new LatLng(29.824466812556658, 106.43232252476277));
        temp.add(new LatLng(29.82971952760052, 106.43108824081186));
        temp.add(new LatLng(29.82930230975999, 106.43160466867063));
        temp.add(new LatLng(29.82772836823898, 106.4312987490943));
        temp.add(new LatLng(29.826907097291215, 106.43219125991573));
        temp.add(new LatLng(29.830596328706616, 106.43058341011223));
        temp.add(new LatLng(29.830583120813383, 106.43062069873086));
        temp.add(new LatLng(29.82781186667083, 106.43107342273444));
        temp.add(new LatLng(29.831996372153647, 106.43086172485664));
        temp.add(new LatLng(29.82942824956717, 106.43163108044114));
        temp.add(new LatLng(29.829425344005845, 106.43165407749163));
        temp.add(new LatLng(29.83104312526248, 106.43231303015777));
        temp.add(new LatLng(29.827728205166217, 106.43127578601654));
        temp.add(new LatLng(29.82649857228983, 106.43207497617892));
        temp.add(new LatLng(29.82693876609164, 106.43217703052103));
        temp.add(new LatLng(29.83259582748956, 106.4307922848194));
        temp.add(new LatLng(29.829449374723968, 106.4315208485469));
        temp.add(new LatLng(29.830117275670244, 106.4321789585039));
        temp.add(new LatLng(29.829021989065385, 106.43307013551872));
        temp.add(new LatLng(29.82899001720896, 106.43314041330368));
        temp.add(new LatLng(29.83160772544637, 106.4314308149732));
        temp.add(new LatLng(29.832715905159425, 106.43270431469139));
        temp.add(new LatLng(29.831362773804813, 106.43426245235666));
        temp.add(new LatLng(29.827780783745908, 106.43127919936542));
        temp.add(new LatLng(29.830084772476745, 106.43229059342919));
        temp.add(new LatLng(29.829397816106777, 106.43166235302775));
        temp.add(new LatLng(29.829626545007407, 106.43307144175203));
        temp.add(new LatLng(29.832558082507152, 106.43274628492142));
        temp.add(new LatLng(29.82880706179364, 106.43359088739895));
        temp.add(new LatLng(29.831550387271896, 106.4337586832376));
        temp.add(new LatLng(29.828881829889657, 106.4336263515799));
        temp.add(new LatLng(29.831465999700857, 106.43385355693817));
        temp.add(new LatLng(30.9922794, 104.2822578));
        temp.add(new LatLng(30.987321553786998, 104.28669994886748));
        temp.add(new LatLng(30.98923988517955, 104.2902514064145));
        temp.add(new LatLng(30.971773687835505, 104.28708780060533));
        temp.add(new LatLng(30.976611177835668, 104.28732978498621));
        temp.add(new LatLng(30.973006314648128, 104.2893910606357));
        temp.add(new LatLng(30.98798186506794, 104.28277082110306));
        temp.add(new LatLng(30.961120452149785, 104.28694955870604));
        temp.add(new LatLng(30.984891300569917, 104.29240091669955));
        temp.add(new LatLng(30.984834410612418, 104.28612482242666));
        temp.add(new LatLng(30.96597427121461, 104.28794436251421));
        temp.add(new LatLng(30.989264468237167, 104.28433193068228));
        temp.add(new LatLng(30.971810669704546, 104.29076170090781));
        temp.add(new LatLng(30.972071972390353, 104.28911115374349));
        temp.add(new LatLng(30.979298480548135, 104.28665291408505));
        temp.add(new LatLng(30.97462220879998, 104.29235840366344));
        temp.add(new LatLng(30.99827227921125, 104.28598252525356));
        temp.add(new LatLng(30.973884907101663, 104.29121373278814));
        temp.add(new LatLng(30.98688466888004, 104.28799197741803));
        temp.add(new LatLng(30.98487677021507, 104.28616300278652));
        temp.add(new LatLng(31.002386267356325, 104.28366810892197));
        temp.add(new LatLng(30.980731108720157, 104.28986918990711));
        temp.add(new LatLng(30.982697827691897, 104.2898035290938));
        temp.add(new LatLng(30.956170040339675, 104.28789418158769));
        temp.add(new LatLng(30.991586407732356, 104.29004610231931));
        temp.add(new LatLng(31.002163989945476, 104.29601629111276));
        temp.add(new LatLng(30.98445916598803, 104.29286619421381));
        temp.add(new LatLng(30.97465697428012, 104.28656066306125));
        temp.add(new LatLng(31.001077412557983, 104.29147165581703));
        temp.add(new LatLng(30.981848176742595, 104.29171424264767));
        temp.add(new LatLng(31.002014732977933, 104.29179901363659));
        temp.add(new LatLng(30.98261748232093, 104.29111083449943));
        temp.add(new LatLng(30.98919522722334, 104.29023418368106));
        temp.add(new LatLng(30.974737882280408, 104.29400878265155));
        temp.add(new LatLng(31.006904697854345, 104.29752937221049));
        temp.add(new LatLng(30.985452016630358, 104.29156160077473));
        temp.add(new LatLng(31.00112141991147, 104.29133171387741));
        temp.add(new LatLng(30.97947697898131, 104.29127179775672));
        temp.add(new LatLng(30.98456796315243, 104.292770216555));
        temp.add(new LatLng(30.991247968977568, 104.2914769801983));
        temp.add(new LatLng(30.97749580276991, 104.29438361734894));
        temp.add(new LatLng(31.001602913056242, 104.29247686765233));
        temp.add(new LatLng(30.98780108591947, 104.29164960610223));
        temp.add(new LatLng(30.979568605985325, 104.29175390424886));
        temp.add(new LatLng(31.00194068716753, 104.29178079683132));
        temp.add(new LatLng(30.984584850468885, 104.29280240905302));
        temp.add(new LatLng(30.980420799735246, 104.29495598364323));
        temp.add(new LatLng(30.995576517839655, 104.30016494120302));
        temp.add(new LatLng(30.991500672209348, 104.29728441734684));
        temp.add(new LatLng(30.979546358566488, 104.29564501757685));
        temp.add(new LatLng(31.146715900531227, 121.39828335290396));
        temp.add(new LatLng(31.263925902072046, 121.35270942554574));
        temp.add(new LatLng(31.182068684736414, 121.3806687762364));
        temp.add(new LatLng(31.227700389371986, 121.32660195555096));
        temp.add(new LatLng(31.199391332950995, 121.37985535992243));
        temp.add(new LatLng(31.161889378608585, 121.35526470471717));
        temp.add(new LatLng(31.20844316291091, 121.38234079523644));
        temp.add(new LatLng(31.257549728785982, 121.37901096979948));
        temp.add(new LatLng(31.239361151525564, 121.37312039773663));
        temp.add(new LatLng(31.287585531571523, 121.42868299775738));
        temp.add(new LatLng(31.24875607588942, 121.32642056031729));
        temp.add(new LatLng(31.0401030877118, 121.42091446346859));
        temp.add(new LatLng(31.204534978159803, 121.44493409540004));
        temp.add(new LatLng(30.97662051137851, 121.45653554812567));
        temp.add(new LatLng(31.23611121486038, 121.41673104362422));
        temp.add(new LatLng(31.08697545877771, 121.43064639728661));
        temp.add(new LatLng(31.2056218034837, 121.40508237446176));
        temp.add(new LatLng(31.09469255138856, 121.42524888490672));
        temp.add(new LatLng(31.147617504552905, 121.32909958697586));
        temp.add(new LatLng(31.221452232053608, 121.40677197055304));
        temp.add(new LatLng(31.2536687865907, 121.39847972959973));
        temp.add(new LatLng(31.217408083420615, 121.41414329836189));
        temp.add(new LatLng(31.237687997512836, 121.4147032700891));
        temp.add(new LatLng(31.081209902319028, 121.44938603988962));
        temp.add(new LatLng(31.200650067843725, 121.4197990127685));
        temp.add(new LatLng(31.341496603322703, 121.40999897968378));
        temp.add(new LatLng(31.2854978070517, 121.41692213779704));
        temp.add(new LatLng(31.291562390760344, 121.47020857426651));
        temp.add(new LatLng(31.03984813751195, 121.4192371033979));
        temp.add(new LatLng(31.08996487031083, 121.46670008289627));
        temp.add(new LatLng(31.224047788024137, 121.4242889872182));
        temp.add(new LatLng(31.28394730058491, 121.41825345088179));
        temp.add(new LatLng(31.15122168024836, 121.4517373325946));
        temp.add(new LatLng(31.126826352665965, 121.46923581418189));
        temp.add(new LatLng(31.221629972483807, 121.43860123843459));
        temp.add(new LatLng(31.235784727287268, 121.50956075301391));
        temp.add(new LatLng(31.195321811895486, 121.47547947629917));
        temp.add(new LatLng(31.099278759911346, 121.51010558797175));
        temp.add(new LatLng(31.4213355669401, 121.37802921575886));
        temp.add(new LatLng(31.20899624118238, 121.51217485377002));
        temp.add(new LatLng(31.24285972171253, 121.46656488110011));
        temp.add(new LatLng(31.08860194142058, 121.40141396205252));
        temp.add(new LatLng(31.197810980046974, 121.4776842583112));
        temp.add(new LatLng(31.072039057709297, 121.59328628464714));
        temp.add(new LatLng(30.938527212806004, 121.5590246399287));
        temp.add(new LatLng(31.24389832189344, 121.4695208949705));
        temp.add(new LatLng(31.060177308156575, 121.51850741948947));
        temp.add(new LatLng(31.223596322775272, 121.48050434415931));
        temp.add(new LatLng(31.227688952798925, 121.50800252621409));
        temp.add(new LatLng(31.24105222654179, 121.527062573659));

        long begin = System.currentTimeMillis();


        for (int j = 0; j < 1000; j++) {
            for (int i = 1; i < 100; i++) {
                Terminal terminal = LocationUtils.getTerminalTraverse(list, temp.get(i - 1));
            }

            long end = System.currentTimeMillis();

            dist.add(end - begin);
        }
        //dist.add(terminal.getDistance());
        //coordinates.add(terminal);

        //System.out.println(terminal.getDistance());
        //System.out.println(terminal.getLatLng().getLongitude() + "," + terminal.getLatLng().getLatitude());

        /*
        for (Integer item : dist) {
            System.out.println(item);
        }

        for (Terminal item : coordinates) {
            System.out.println(item.getLatLng().getLongitude() + "," + item.getLatLng().getLatitude());
        }

         */

        //long end = TimeUtils.getCurrentTimeOfSeconds();
        for (Long item : dist) {
            System.out.println(item);
        }
        model.addAttribute("msg", "msg");
        return "cluster";
    }

    @RequestMapping(value = "/location", method = RequestMethod.GET)
    private String location(Model model) {

        long begin = System.currentTimeMillis();

        List<Terminal> coordinates = new ArrayList<Terminal>();
        List<Integer> dist = new ArrayList<Integer>();

        for (int i = 101; i < 102; i++) {

            List<Location> locationList = depotService.queryClusters(i);

            List<LatLng> list = new ArrayList();

            for (Location item : locationList) {
                list.add(new LatLng(item.getLat(), item.getLng()));
            }

            //实验一
            //Terminal terminal = LocationUtils.getTerminal(list);

            //实验二
            Terminal terminal = LocationUtils.getCircleSearch(list);

            dist.add(terminal.getDistance());
            coordinates.add(terminal);
        }

        //System.out.println(j + ":" + terminal.getDistance() + "/" + Collections.min(dist) + "/" + terminal.getLatLng().getLongitude() + "," + terminal.getLatLng().getLatitude());

        for (Integer item : dist) {
            System.out.println(item);
        }

        for (Terminal terminal : coordinates) {
            System.out.println(terminal.getLatLng().getLongitude() + "," + terminal.getLatLng().getLatitude());
        }

        long end = System.currentTimeMillis();

        model.addAttribute("msg", end - begin);
        return "cluster";
    }

    @RequestMapping(value = "/genetic", method = RequestMethod.GET)
    private String genetic(Model model) {

        long begin = System.currentTimeMillis();

        List<LatLng> coordinates = new ArrayList<LatLng>();
        List<Integer> dist = new ArrayList<Integer>();

        for (int i = 1; i < 151; i++) {

            List<Location> locationList = depotService.queryClusters(i);

            List<LatLng> list = new ArrayList();

            for (Location item : locationList) {
                list.add(new LatLng(item.getLat(), item.getLng()));
            }

            Genetic Tryer = new Genetic();
            Tryer.map = new HashMap<String, Integer>();

            Tryer.list = list;
            Tryer.lngUpper = list.stream().mapToDouble(LatLng::getLongitude).max().getAsDouble();
            Tryer.lngLower = list.stream().mapToDouble(LatLng::getLongitude).min().getAsDouble();
            Tryer.latUpper = list.stream().mapToDouble(LatLng::getLatitude).max().getAsDouble();
            Tryer.latLower = list.stream().mapToDouble(LatLng::getLatitude).min().getAsDouble();

            Tryer.ipop = Tryer.initPop();

            //迭代次数
            for (int j = 0; j < 30; j++) {
                Tryer.select();
                Tryer.cross();
                Tryer.mutation();
                Tryer.generation = j;
            }

            dist.add((int) Tryer.bestfitness);
            coordinates.add(Tryer.beststr);
        }

        for (Integer item : dist) {
            System.out.println(item);
        }

        for (LatLng latLng : coordinates) {
            System.out.println(latLng.getLongitude() + "," + latLng.getLatitude());
        }

        long end = System.currentTimeMillis();

        model.addAttribute("msg", end - begin);
        return "cluster";
    }

    @RequestMapping(value = "/sa", method = RequestMethod.GET)
    private String sa(Model model) {

        long begin = System.currentTimeMillis();

        List<LatLng> coordinates = new ArrayList<LatLng>();
        List<Integer> dist = new ArrayList<Integer>();

        for (int i = 20; i < 21; i++) {

            List<Location> locationList = depotService.queryClusters(i);

            List<LatLng> list = new ArrayList();

            for (Location item : locationList) {
                list.add(new LatLng(item.getLat(), item.getLng()));
            }

            SimulatedAnnealing Tryer = new SimulatedAnnealing();
            Tryer.list = list;
            Tryer.lngUpper = list.stream().mapToDouble(LatLng::getLongitude).max().getAsDouble();
            Tryer.lngLower = list.stream().mapToDouble(LatLng::getLongitude).min().getAsDouble();
            Tryer.latUpper = list.stream().mapToDouble(LatLng::getLatitude).max().getAsDouble();
            Tryer.latLower = list.stream().mapToDouble(LatLng::getLatitude).min().getAsDouble();

            double[] arr = Tryer.SimulatedAnnealing();

            dist.add((int) arr[2]);
            coordinates.add(new LatLng(arr[1], arr[0]));
        }

        for (Integer item : dist) {
            System.out.println(item);
        }

        for (LatLng latLng : coordinates) {
            System.out.println(latLng.getLongitude() + "," + latLng.getLatitude());
        }

        long end = System.currentTimeMillis();

        model.addAttribute("msg", end - begin);
        return "cluster";
    }

    @RequestMapping(value = "/gmc", method = RequestMethod.GET)
    private String gmc(Model model) {

        long begin = System.currentTimeMillis();

        List<LatLng> coordinates = new ArrayList<LatLng>();
        List<Integer> dist = new ArrayList<Integer>();

        for (int i = 1; i < 151; i++) {

            List<Location> locationList = depotService.queryClusters(i);

            List<LatLng> list = new ArrayList();

            for (Location item : locationList) {
                list.add(new LatLng(item.getLat(), item.getLng()));
            }

            LatLng midpoint = LocationUtils.GetCenterPointFromListOfCoordinates(list);

            List<Integer> distance = new ArrayList<Integer>();
            int sum = 0;

            for (LatLng item : list) {

                Result result = LocationUtils.Distance(AccessKey, UrlDomain.ACTION_RIDING, item, midpoint);

                distance.add(result.getDistance());
            }

            if (distance.contains(-1)) {
                sum = Integer.MAX_VALUE;
            } else {
                for (Integer item : distance) {
                    sum += item;
                }

                if (sum <= 0)
                    sum = Integer.MAX_VALUE;
            }

            dist.add(sum);
            coordinates.add(midpoint);
        }

        for (Integer item : dist) {
            System.out.println(item);
        }

        for (LatLng latLng : coordinates) {
            System.out.println(latLng.getLongitude() + "," + latLng.getLatitude());
        }

        long end = System.currentTimeMillis();

        model.addAttribute("msg", end - begin);
        return "cluster";
    }

    @RequestMapping(value = "/updateline", method = RequestMethod.GET)
    private String updateline(Model model) {

        List<Line> lineList = lineService.queryAll();
        List<Location> stationList = depotService.queryStation();

        for (Line item : lineList) {

            Trip first = tripService.getModel(item.getStrip());
            Trip last = tripService.getModel(item.getDtrip());

            //选择最佳的车站
            LatLng orgi = new LatLng(first.getSLat(), first.getSLng());
            LatLng dest = new LatLng(last.getDLat(), last.getDLng());

            List<Integer> outs = new ArrayList<Integer>();
            List<Integer> ins = new ArrayList<Integer>();

            for (Location station : stationList) {

                LatLng latLng = new LatLng(station.getLat(), station.getLng());

                Result pull_out = LocationUtils.Distance(AccessKey, UrlDomain.ACTION_RIDING, latLng, orgi);
                Result pull_in = LocationUtils.Distance(AccessKey, UrlDomain.ACTION_RIDING, dest, latLng);

                outs.add(pull_out.getDuration());
                ins.add(pull_in.getDuration());
            }

            int min1 = Collections.min(outs);
            int min2 = Collections.min(ins);

            int out = outs.indexOf(min1);
            int in = ins.indexOf(min2);

            Date start_time = TimeUtils.getTimeMinusSeconds(first.getDeparture(), min1);
            Date last_time = TimeUtils.getTimePlusSeconds(last.getDeparture(), last.getDuration());
            Date end_time = TimeUtils.getTimePlusSeconds(last_time, min2);

            lineService.update(new Line(
                    item.getId(),
                    item.getCode(),
                    item.getStrip(),
                    item.getDtrip(),
                    stationList.get(out).getId(),
                    stationList.get(in).getId(),
                    start_time,
                    end_time
            ));
        }

        return "cluster";
    }

    @RequestMapping(value = "/efficiency", method = RequestMethod.GET)
    private String efficiency(Model model) {

        List<Long> time = new ArrayList<Long>();

        //随机构造坐标
        List<LatLng> list = new ArrayList();

        for (int i = 0; i < 10; i++) {
            list.add(LocationUtils.randomLatLng(121.457803, 121.675696, 30.848542, 31.296473));
        }

        long begin = System.currentTimeMillis();

        for (int k = 0; k < 100; k++) {

            //算法1
            Terminal terminal = LocationUtils.getTerminalTraverse(list, LocationUtils.randomLatLng(121.457803, 121.675696, 30.848542, 31.296473));

            //算法2
            //Terminal terminal = LocationUtils.getTerminal(list);

            //算法3
            //Terminal terminal = LocationUtils.getCircleSearch(list);

            //算法4
        /*
            Genetic Tryer = new Genetic();
            Tryer.map = new HashMap<String, Integer>();

            Tryer.list = list;
            Tryer.lngUpper = list.stream().mapToDouble(LatLng::getLongitude).max().getAsDouble();
            Tryer.lngLower = list.stream().mapToDouble(LatLng::getLongitude).min().getAsDouble();
            Tryer.latUpper = list.stream().mapToDouble(LatLng::getLatitude).max().getAsDouble();
            Tryer.latLower = list.stream().mapToDouble(LatLng::getLatitude).min().getAsDouble();

            Tryer.ipop = Tryer.initPop();

            //迭代次数
            for (int j = 0; j < 15; j++) {
                Tryer.select();
                Tryer.cross();
                Tryer.mutation();
                Tryer.generation = j;
            }
*/
                /*
            //算法5
            SimulatedAnnealing Tryer = new SimulatedAnnealing();
            Tryer.list = list;
            Tryer.lngUpper = list.stream().mapToDouble(LatLng::getLongitude).max().getAsDouble();
            Tryer.lngLower = list.stream().mapToDouble(LatLng::getLongitude).min().getAsDouble();
            Tryer.latUpper = list.stream().mapToDouble(LatLng::getLatitude).max().getAsDouble();
            Tryer.latLower = list.stream().mapToDouble(LatLng::getLatitude).min().getAsDouble();

            double[] arr = Tryer.SimulatedAnnealing();
*/
            //算法5
            //LatLng midpoint = LocationUtils.GetCenterPointFromListOfCoordinates(list);

            long end = System.currentTimeMillis();

            time.add(end - begin);

            System.out.println(end - begin);
        }

        for (Long item : time) {
            System.out.println(item);
        }

        model.addAttribute("msg", "msg");
        return "cluster";
    }
}
