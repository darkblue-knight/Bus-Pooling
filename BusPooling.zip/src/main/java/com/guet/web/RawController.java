package com.guet.web;

import com.guet.core.UrlDomain;
import com.guet.entity.*;
import com.guet.service.BusShareService;
import com.guet.service.BusStationService;
import com.guet.service.DataService;
import com.guet.service.RoutesService;
import com.guet.util.CommonUtils;
import com.guet.util.LocationUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.io.File;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.guet.util.LocationUtils.AccessKey;

@Controller
@RequestMapping(value = "/raw", method = RequestMethod.GET)
public class RawController {

    private static final double lng1 = 121.98, lng2 = 121.05, lat1 = 31.5, lat2 = 30.7;

    @Autowired
    private BusShareService busShareService;

    @Autowired
    private RoutesService routesService;

    @Autowired
    private DataService dataService;

    @Autowired
    private BusStationService busStationService;

    @RequestMapping(value = "/write", method = RequestMethod.GET)
    public String write(ModelMap model) {

        //临时变量时间
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
        Date date = null;

        Date s_dt = null;//出发时间
        Double s_lng = Double.MIN_VALUE;//出发经度
        Double s_lat = Double.MIN_VALUE;//出发维度

        try {
            String path = "E:\\Taxi_180401\\";
            List<File> fileList = getFiles(path);

            for (int i = 0; i < fileList.size(); i++) {
                String pathname = fileList.get(i).getCanonicalPath(); // 绝对路径或相对路径都可以，这里是绝对路径，写入文件时演示相对路径
                File filename = new File(pathname); // 要读取以上路径的input。txt文件
                InputStreamReader isr = new InputStreamReader(new FileInputStream(filename), "utf-8");
                BufferedReader br = new BufferedReader(isr);
                String lineTxt = null;

                //是否为首
                int mutex = 0;

                List<Data> temp = new ArrayList();
                List<BusShare> list = new ArrayList();

                while ((lineTxt = br.readLine()) != null) {
                    String[] as = lineTxt.split("\\|");

                    date = as[9].trim().length() > 10 ? sdf.parse(as[9]) : sdf2.parse(as[9]);

                    temp.add(new Data(
                            Integer.parseInt(as[0].trim()),
                            Float.parseFloat(as[11].trim()),
                            Float.parseFloat(as[10].trim()),
                            Integer.parseInt(as[3].trim()),
                            date)
                    );
                }

                dataService.add(temp);

                /*
                for (int j = 0; j < temp.size(); j++) {
                    if (temp.get(j).getiscarry() > 0) {
                        if (mutex == 0) {
                            s_dt = temp.get(j).getDt();
                            s_lng = temp.get(j).getLng();
                            s_lat = temp.get(j).getLat();

                            //将mutex置为1
                            mutex = 1;
                        } else {
                            if (j < temp.size() - 1) {
                                if (temp.get(j + 1).getiscarry() == 0) {

                                    //将mutex置为0
                                    mutex = 0;

                                    LatLng orig = new LatLng(s_lat, s_lng);
                                    LatLng dest = new LatLng(temp.get(j).getLat(), temp.get(j).getLng());

                                    list.add(new BusShare(
                                            UUID.randomUUID().toString(),
                                            String.valueOf(temp.get(j).getCode()),
                                            s_dt,
                                            s_lng,
                                            s_lat,
                                            temp.get(j).getDt(),
                                            temp.get(j).getLng(),
                                            temp.get(j).getLat()));

                                }
                            }
                        }
                    } else {
                        //将mutex置为0
                        mutex = 0;
                    }
                }

                if (list.size() > 0) {
                    busShareService.add(list);
                }
                */

                br.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        model.addAttribute("msg", "Write data completed!");
        model.addAttribute("name", "Console");

        return "feedback";
    }

    @RequestMapping(value = "/routes", method = RequestMethod.GET)
    public String routes(ModelMap model) {

        List<BusShare> list = busShareService.getList();

        LatLng orgi;
        LatLng dest;

        for (BusShare item : list) {
            orgi = new LatLng(item.getSLat(), item.getSLng());
            dest = new LatLng(item.getDLat(), item.getDLng());

            List<LatLng> ls = LocationUtils.getRoutes(AccessKey, UrlDomain.ACTION_RIDING, orgi, dest);

            //去掉重复项目
            for (int i = 0; i < ls.size() - 1; i++) {
                for (int j = ls.size() - 1; j > i; j--) {
                    if (ls.get(j).getLatitude() == ls.get(i).getLatitude()
                            &&
                            ls.get(j).getLongitude() == ls.get(i).getLongitude()) {
                        ls.remove(j);
                    }
                }
            }

            if (ls.size() > 0) {

                List<Routes> Routes = new ArrayList<Routes>();

                for (int i = 0; i < ls.size(); i++) {
                    Routes.add(new Routes(
                                    UUID.randomUUID().toString(),
                                    item.getId(),
                                    i,
                                    ls.get(i).getLongitude(),
                                    ls.get(i).getLatitude()
                            )
                    );
                }

                routesService.add(Routes);
            }
        }

        model.addAttribute("msg", "Routes data completed!");
        model.addAttribute("name", "Console");

        return "feedback";
    }

    @RequestMapping(value = "/station", method = RequestMethod.GET)
    public String station(ModelMap model) {

        List<String> accessKey = LocationUtils.getAccessKey();

        List<Grid> grids;
        double lng_lower, lng_upper, lat_lower, lat_upper;
        BigDecimal lng, lat, lng_b, lat_b, I, I1, J, J1;
        MathContext mc = new MathContext(10, RoundingMode.DOWN);

        lng = new BigDecimal((lng1 - lng2));
        lat = new BigDecimal((lat1 - lat2));
        lng_b = new BigDecimal(lng2);
        lat_b = new BigDecimal(lat2);

        int z = 185;

        BigDecimal power = new BigDecimal(z);

        grids = new ArrayList();

        for (int i = 0; i < z; i++) {
            I = new BigDecimal(i);
            I1 = new BigDecimal(i - 1);

            for (int j = 0; j < z; j++) {
                J = new BigDecimal(j);
                J1 = new BigDecimal(j - 1);

                lng_lower = lng_b.add(lng.multiply(I1.divide(power, mc))).doubleValue();
                lng_upper = lng_b.add(lng.multiply(I.divide(power, mc))).doubleValue();
                lat_lower = lat_b.add(lat.multiply(J1.divide(power, mc))).doubleValue();
                lat_upper = lat_b.add(lat.multiply(J.divide(power, mc))).doubleValue();

                grids.add(new Grid((i * z + j), lng_lower, lng_upper, lat_lower, lat_upper));
            }
        }

        for (Grid g : grids) {
            LatLng location = new LatLng(g.getLatUpper(), g.getLngUpper());

            System.out.println("[" + g.getId() + "] " + g.getLngUpper() + "," + g.getLatUpper());

            List<BusStation> busStation = LocationUtils.Place(AccessKey, location, 2000);

            if (busStation.size() > 0) {
                try {
                    busStationService.add(busStation);
                } catch (Exception e) {

                }
            }
        }

        return "feedback";
    }

    @RequestMapping(value = "/append", method = RequestMethod.GET)
    public String append(ModelMap model) {

        Date s_dt = null;//出发时间
        Double s_lng = Double.MIN_VALUE;//出发经度
        Double s_lat = Double.MIN_VALUE;//出发维度
        List<Data> temp;
        List<BusShare> list;

        List<Integer> codeList = dataService.queryCode();

        for (Integer item : codeList) {

            //是否为首
            int mutex = 0;

            temp = dataService.getModel(item);
            list = new ArrayList();

            for (int i = 0; i < temp.size(); i++) {
                if (temp.get(i).getiscarry() > 0) {
                    if (mutex == 0) {
                        s_dt = temp.get(i).getDt();
                        s_lng = temp.get(i).getLng();
                        s_lat = temp.get(i).getLat();

                        //将mutex置为1
                        mutex = 1;
                    } else {
                        if (i < temp.size() - 1) {
                            if (temp.get(i + 1).getiscarry() == 0) {

                                //将mutex置为0
                                mutex = 0;

                                list.add(new BusShare(
                                        UUID.randomUUID().toString(),
                                        String.valueOf(temp.get(i).getCode()),
                                        s_dt,
                                        s_lng,
                                        s_lat,
                                        temp.get(i).getDt(),
                                        temp.get(i).getLng(),
                                        temp.get(i).getLat()));

                            }
                        }
                    }
                } else {
                    //将mutex置为0
                    mutex = 0;
                }
            }

            if (list.size() > 0) {
                busShareService.add(list);
            }
        }

        model.addAttribute("msg", "Write data completed!");
        model.addAttribute("name", "Console");

        return "feedback";
    }

    public static List<File> getFiles(String path){
        File root = new File(path);
        List<File> files = new ArrayList<File>();
        if(!root.isDirectory()){
            files.add(root);
        }else{
            File[] subFiles = root.listFiles();
            for(File f : subFiles){
                files.addAll(getFiles(f.getAbsolutePath()));
            }
        }
        return files;
    }
}
