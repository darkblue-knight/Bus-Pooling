package com.guet.web;

import com.guet.core.UrlDomain;
import com.guet.entity.*;
import com.guet.service.*;
import com.guet.util.LocationUtils;
import com.guet.util.TimeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Controller
@RequestMapping(value = "/Ridesharing", method = RequestMethod.GET)
public class RidesharingController {

    @Autowired
    private BusShareService busShareService;

    @Autowired
    private BusStationService busStationService;

    @Autowired
    private BucketService bucketService;

    @Autowired
    private RoutesService routesService;

    @Autowired
    private StopService stopService;

    private static final int limit = 30;//设置每个聚类的容量
    private static final double lng1 = 121.98, lng2 = 121.05, lat1 = 31.5, lat2 = 30.7;

    private List<String> outputs;

    @RequestMapping(value = "/List", method = RequestMethod.GET)
    private String List(Model model) {
        long begin = TimeUtils.getCurrentTimeOfSeconds();

        List<String> accessKey = LocationUtils.getAccessKey();
        List<BusShare> list = busShareService.getAll();
        List<BusStation> busStationlist = busStationService.getList();
        List<Routes> routesList = routesService.getList();
        List<BusShare> busShares;
        List<BusShare> tempList;
        List<LatLng> origList;
        List<LatLng> destList;
        LatLng orig;
        LatLng dest;

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

        List<Grid> grids;
        double lng_lower, lng_upper, lat_lower, lat_upper;
        BigDecimal lng, lat, lng_b, lat_b, I, I1, J, J1;
        MathContext mc = new MathContext(10, RoundingMode.DOWN);

        lng = new BigDecimal((lng1 - lng2));
        lat = new BigDecimal((lat1 - lat2));
        lng_b = new BigDecimal(lng2);
        lat_b = new BigDecimal(lat2);

        for (int z = 74; z > 0; z--) {

            BigDecimal power = new BigDecimal(z);

            grids = new ArrayList();

            for (int i = 0; i < z; i++) {
                I = new BigDecimal(i);
                I1 = new BigDecimal(i - 1);

                for (int j = 0; j < z; j++) {
                    J = new BigDecimal(j);
                    J1 = new BigDecimal(j - 1);

                    lng_lower = lng_b.add(lng.multiply(I1.divide(power, mc))).doubleValue();
                    lng_upper = lng_b.add(lng.multiply(I.divide(power, mc))).doubleValue();
                    lat_lower = lat_b.add(lat.multiply(J1.divide(power, mc))).doubleValue();
                    lat_upper = lat_b.add(lat.multiply(J.divide(power, mc))).doubleValue();

                    grids.add(new Grid((i * z + j), lng_lower, lng_upper, lat_lower, lat_upper));
                }
            }

            System.out.println(z + ":[0]" + dateFormat.format(new Date()));

            for (BusShare item : list) {
                item.setSidx(-1);
                item.setDidx(-1);

                for (Grid g : grids) {
                    if (item.getSLng() > g.getLngLower() && item.getSLng() < g.getLngUpper() && item.getSLat() > g.getLatLower() && item.getSLat() < g.getLatUpper())
                        item.setSidx(g.getId());

                    if (item.getDLng() > g.getLngLower() && item.getDLng() < g.getLngUpper() && item.getDLat() > g.getLatLower() && item.getDLat() < g.getLatUpper())
                        item.setDidx(g.getId());
                }
            }

            System.out.println(z + ":[1]" + dateFormat.format(new Date()));

            int[][] matrix = new int[z * z][z * z];

            for (BusShare item : list) {
                if (item.getSIdx() > 0 && item.getDIdx() > 0)
                    matrix[item.getSIdx()][item.getDIdx()] += 1;
            }

            System.out.println(z + ":[2]" + dateFormat.format(new Date()));

            for (int i = 0; i < matrix.length; i++) {
                for (int j = 0; j < matrix[i].length; j++) {

                    if (matrix[i][j] >= limit) {

                        System.out.println(z + ":[#]" + (i * matrix[i].length + j) + "(" + matrix[i][j] + ")," + dateFormat.format(new Date()));

                        /**计算上下车点**/
                        final int s_idx = i, d_idx = j;

                        List<BusShare> result = list.stream()
                                .filter(r -> (r.getSIdx() == s_idx) && (r.getDIdx() == d_idx))
                                .collect(Collectors.toList());

                        List<BusShare> candidateList = busShareService.getBusShare(result, routesList, limit);

                        if (candidateList.isEmpty())
                            break;

                        List<String> ids = new ArrayList();

                        candidateList.forEach(item -> ids.add(item.getId()));

                        int bucketNo = bucketService.queryBucketNo() + 1;

                        origList = new ArrayList();
                        destList = new ArrayList();

                        for (BusShare item : candidateList) {
                            origList.add(new LatLng(item.getSLat(), item.getSLng()));
                            destList.add(new LatLng(item.getDLat(), item.getDLng()));
                        }

                        orig = LocationUtils.getOptimalBusStation(origList, busStationlist);
                        dest = LocationUtils.getOptimalBusStation(destList, busStationlist);

                        stopService.add(new RecommendStops(
                                UUID.randomUUID().toString(), bucketNo, 0,
                                orig.getLongitude(), orig.getLatitude(),
                                dest.getLongitude(), dest.getLatitude(),
                                0, 0
                        ));

                        bucketService.write(ids);

                        busShareService.delete(candidateList);

                        list.removeAll(candidateList);

                        System.out.println(z + ":[a]" + (i * matrix[i].length + j) + ",[list.size]" + list.size() + "(" + candidateList.size() + ")");

                    } else if (matrix[i][j] >= limit / 3) {

                        List<List<BusShare>> busShareList = new ArrayList();
                        List<RecommendStops> recommendStopsList = new ArrayList();

                        /**计算上、下车点**/
                        final int s_idx = i, d_idx = j;

                        List<BusShare> result = list.stream().filter(r -> (r.getSIdx() == s_idx) && (r.getDIdx() == d_idx)).collect(Collectors.toList());

                        if (result.isEmpty())
                            break;

                        origList = new ArrayList();
                        destList = new ArrayList();

                        for (BusShare item : result) {
                            origList.add(new LatLng(item.getSLat(), item.getSLng()));
                            destList.add(new LatLng(item.getDLat(), item.getDLng()));
                        }

                        orig = LocationUtils.getOptimalBusStation(origList, busStationlist);
                        dest = LocationUtils.getOptimalBusStation(destList, busStationlist);

                        /**计算行驶路径**/
                        List<Zone> zones = new ArrayList();
                        List<Integer> ids = new ArrayList();

                        if (!accessKey.isEmpty()) {
                            String ak = accessKey.get(0);

                            List<LatLng> routes = LocationUtils.getRoutes(ak, UrlDomain.ACTION_DRIVING, orig, dest);

                            if (routes.size() == 1) {
                                if (routes.get(0).getLatitude() == -1 && routes.get(0).getLongitude() == -1) {
                                    accessKey.remove(ak);
                                }
                            } else {
                                /**求得穿越区域**/
                                int idx = 0;

                                for (LatLng item : routes) {
                                    for (Grid g : grids) {
                                        if (item.getLongitude() > g.getLngLower() && item.getLongitude() < g.getLngUpper() && item.getLatitude() > g.getLatLower() && item.getLatitude() < g.getLatUpper()) {
                                            if (!ids.contains(g.getId())) {
                                                ids.add(g.getId());
                                                zones.add(new Zone(g.getId(), idx++));
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (zones.size()<2)
                            break;

                        int first = zones.get(0).getCode();
                        int last = zones.get(zones.size() - 1).getCode();
                        List<Zone> zonesList = zones.subList(1,zones.size() - 1);

                        int[] input = new int[zonesList.size()];

                        for (int n = 0; n < zonesList.size(); n++) {
                            input[n] = zonesList.get(n).getCode();
                        }

                        outputs = new ArrayList();

                        /**统计区域的可能组合**/
                        for (int n = 0; n <= zonesList.size(); n++) {
                            int[] output = new int[n];
                            dfs(input, output, 0, 0, first, last);
                        }

                        List<Combination> combinations = new ArrayList();

                        zones.stream().sorted(Comparator.comparing(Zone::getIdx));

                        /**排序**/
                        for (String output : outputs) {
                            output = output.replaceAll("\\[", "").replaceAll("]", "").replaceAll(" ", "");
                            String[] array = output.split(",");

                            List<Integer> c = new ArrayList();

                            for (Zone item1 : zones) {
                                for (String item2 : array) {
                                    if (item1.getCode() == Integer.valueOf(item2)) {
                                        c.add(item1.getCode());
                                    }
                                }
                            }

                            combinations.add(new Combination(c));
                        }

                        tempList = list;

                        /**统计穿越区域到同一目的地的人数**/
                        for (Combination item : combinations) {

                            //登记上车情况
                            List<Travel> c = item.getList();

                            if (c == null) {
                                c = new ArrayList();
                            }

                            //最大座位
                            List<Integer> capacity = new ArrayList();

                            int seats = 0;

                            for (int n = 0; n < item.getCode().size(); n++) {

                                int demands = 0;

                                for (int m = n + 1; m < item.getCode().size(); m++) {
                                    final int s = n, d = m;

                                    List<BusShare> temp = tempList.stream()
                                            .filter(r -> (r.getSIdx() == item.getCode().get(s)) && (r.getDIdx() == item.getCode().get(d)))
                                            .collect(Collectors.toList());

                                    //增加上车人数
                                    demands += temp.size();

                                    c.add(new Travel(item.getCode().get(s), item.getCode().get(d), temp));
                                }

                                for (int m = 0; m < n; m++) {
                                    final int s = m, d = n;

                                    List<BusShare> temp = tempList.stream()
                                            .filter(r -> (r.getSIdx() == item.getCode().get(s)) && (r.getDIdx() == item.getCode().get(d)))
                                            .collect(Collectors.toList());

                                    //增加下车人数
                                    demands -= temp.size();
                                }

                                seats += demands;
                                capacity.add(seats);
                            }

                            if(!capacity.isEmpty()) {
                                item.setCapacity(Collections.max(capacity));
                                item.setList(c);
                            }
                        }

                        /**过滤**/
                        combinations.removeAll(combinations.stream().filter(x -> x.getCapacity() > limit).collect(Collectors.toList()));

                        /**排序**/
                        combinations.sort(Comparator.comparing(Combination::getCapacity).reversed().thenComparing(Combination::getCodeSize));

                        if (combinations.isEmpty())
                            break;

                        /**选择**/
                        Combination combination = combinations.get(0);

                        if (combination.getCode().isEmpty()||combination.getList().isEmpty())
                            break;

                        if (combination.getCount() > limit * 2 / 3) {

                            List<Integer> stops = new ArrayList<Integer>();
                            List<Stops> stopsList = new ArrayList<Stops>();

                            List<Travel> travels = combination.getList();

                            for (Travel item : travels) {
                                if (!stops.contains(item.getS())) stops.add(item.getS());
                                if (!stops.contains(item.getD())) stops.add(item.getD());
                            }

                            /**求得穿越区域的上车点**/
                            List<LatLng> locationList;
                            List<Travel> travelList;

                            for (Integer code : stops) {

                                locationList = new ArrayList();

                                travelList = travels.stream().filter(x -> x.getS() == code).collect(Collectors.toList());

                                for (Travel item : travelList) {
                                    for (BusShare busShare : item.getList()) {
                                        locationList.add(new LatLng(busShare.getSLat(), busShare.getSLng()));
                                    }
                                }

                                travelList = travels.stream().filter(x -> x.getD() == code).collect(Collectors.toList());

                                for (Travel item : travelList) {
                                    for (BusShare busShare : item.getList()) {
                                        locationList.add(new LatLng(busShare.getDLat(), busShare.getDLng()));
                                    }
                                }

                                if (!locationList.isEmpty()) {
                                    LatLng stop = LocationUtils.getOptimalBusStation(locationList, busStationlist);
                                    stopsList.add(new Stops(code, stop));
                                }
                            }

                            /**计算分组**/
                            List<Bucket> buckets = new ArrayList<Bucket>();

                            int bucketNo = bucketService.queryBucketNo() + 1;

                            for (int n = 0; n < travels.size(); n++) {
                                int s = travels.get(n).getS();
                                int d = travels.get(n).getD();

                                busShares = travels.get(n).getList();

                                if (!busShares.isEmpty()) {
                                    for (BusShare busShare : busShares) {
                                        buckets.add(new Bucket(UUID.randomUUID().toString(), bucketNo, n, busShare.getId(), 0, 0, 0, 0, 0, 0, 0, 0));
                                    }

                                    orig = stopsList.stream().filter(x -> x.getCode() == s).collect(Collectors.toList()).get(0).getLatLng();
                                    dest = stopsList.stream().filter(x -> x.getCode() == d).collect(Collectors.toList()).get(0).getLatLng();

                                    recommendStopsList.add(new RecommendStops(UUID.randomUUID().toString(), bucketNo, n, orig.getLongitude(), orig.getLatitude(), dest.getLongitude(), dest.getLatitude(), 0, 0));

                                    busShareList.add(busShares);
                                    list.removeAll(busShares);
                                    matrix[s][d] -= busShares.size();
                                }
                            }

                            /**插入bucket**/
                            bucketService.add(buckets);

                            /**插入RecommendStops**/
                            for (RecommendStops item : recommendStopsList) {
                                stopService.add(item);
                            }

                            /**删除**/
                            for (List<BusShare> item : busShareList) {
                                busShareService.delete(item);
                            }

                            System.out.println(z + ":[b]" + (i * matrix[i].length + j) + ",[list.size]" + list.size() + "(" + busShareList.size() + ")");
                        }
                    }
                }
            }
        }

        long end = TimeUtils.getCurrentTimeOfSeconds();

        model.addAttribute("msg", end - begin);
        model.addAttribute("list", list);
        return "detail";
    }

    @RequestMapping(value = "/Insert", method = RequestMethod.GET)
    private String Insert(Model model) {
        List<BusShare> list = busShareService.getAll();

        Collections.shuffle(list);

        while (!list.isEmpty()) {
            List<BusShare> temp = list.subList(0, limit);
            List<String> ids = new ArrayList();
            temp.forEach(b -> ids.add(b.getId()));
            bucketService.write(ids);
            list.removeAll(temp);
        }

        model.addAttribute("msg", null);
        return "detail";
    }

    @RequestMapping(value = "/Statistics", method = RequestMethod.GET)
    private String Statistics(Model model) {

        Double total = 0.0;
        List<Double> ls = new ArrayList<>();

        int count = bucketService.queryBucketNo();

        for (int i = 1; i <= count; i++) {
            List<BusShare> list = busShareService.getList(i);
            Double weight = busShareService.getAverageWeight(list);
            ls.add(weight);
            total += weight;
        }

        model.addAttribute("list", ls);
        model.addAttribute("msg", total / count);
        model.addAttribute("name", "Console");

        return "feedback";
    }

    public void dfs(int[] input, int[] output, int index, int start, int first, int last) {

        if (index == output.length) {

            //产生一个组合序列
            int[] temp = new int[output.length + 2];

            temp[0] = first;

            for (int i = 0; i < output.length; i++) {
                temp[i + 1] = output[i];
            }

            temp[temp.length - 1] = last;

            outputs.add(Arrays.toString(temp));
        } else {
            for (int j = start; j < input.length; j++) {

                //记录选取的元素
                output[index] = input[j];

                //选取下一个元素，可选下标区间为[j+1,input.length]
                dfs(input, output, index + 1, j + 1, first, last);
            }
        }
    }
}