package com.guet.web;

import com.guet.core.UrlDomain;
import com.guet.entity.*;
import com.guet.service.*;
import com.guet.util.LocationUtils;
import com.guet.util.SeqGeneratorTask;
import com.guet.util.TimeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

import static com.guet.util.LocationUtils.AccessKey;
import static com.guet.util.TimeUtils.getTimeDifference;


@Controller
@RequestMapping(value = "/Schedule", method = RequestMethod.GET)
public class ScheduleController {

    /*遗传算法*/
    private int ChrNum = 10;//染色体数量
    public Solution[] ipop = new Solution[ChrNum];
    public int generation = 0;//染色体代号
    public double bestfitness = Double.MAX_VALUE;//函数最优解
    public int bestgenerations;//所有子代与父代中最好的染色体
    public Solution beststr;//最优解的染色体的二进制码
    private List<List<Trip>> temp, temp1, temp2;
    private List<Trip> trip = new ArrayList();
    private List<List<Trip>> tripList = new ArrayList();

    /*设定参数*/
    public static final String depot_id = "71dad709-4b83-11e9-896e-00d8611fa8b7";
    public static final int max_working_time = 28800;           //最长工作时间     （单位：秒）
    public static final double fuel = 0.0006;                   //营运油料成本     （单位：元/米）
    public static final double wage = 0.0053846153846154;       //驾驶员工资       （单位：元/秒）    40320/(52*40*60*60)
    public static final double rent = 200;                      //租金            （单位：元/辆）

    @Autowired
    private TripService tripService;

    @Autowired
    private DepotService depotService;

    @Autowired
    private DharcService dharcService;

    @Autowired
    private PullarcService pullarcService;

    @Autowired
    private SequenceService sequenceService;

    @RequestMapping(value = "/updatetrip", method = RequestMethod.GET)
    private String updatetrip(Model model) {

        List<Trip> tripList = tripService.queryAll();

        LatLng orig;
        LatLng dest;

        for (Trip item : tripList) {

            orig = new LatLng(item.getSLat(), item.getSLng());
            dest = new LatLng(item.getDLat(), item.getDLng());

            Result result = LocationUtils.Distance(AccessKey, UrlDomain.ACTION_DRIVING, orig, dest);

            item.setDistance(result.getDistance());
            item.setDuration(result.getDuration());

            tripService.update(item);
        }

        model.addAttribute("msg", "Bucket Update completed!");
        model.addAttribute("name", "Console");
        return "feedback";
    }

    //生成Pull-in/out
    @RequestMapping(value = "/depot", method = RequestMethod.GET)
    private String depot(Model model) {

        List<Location> depots = depotService.queryAll();
        List<Trip> trips = tripService.queryAll();

        List<String> rs = new ArrayList<String>();

        for (int i = 0; i < depots.size(); i++) {

            Location depot = depots.get(i);

            //pull-out
            LatLng dest = new LatLng(depot.getLat(), depot.getLng());
            LatLng orig;

            List<Arc> ls = new ArrayList<Arc>();

            for (Trip item : trips) {

                //head
                orig = new LatLng(item.getDLat(), item.getDLng());

                Result result = LocationUtils.Distance(AccessKey, UrlDomain.ACTION_DRIVING, orig, dest);

                ls.add(new Arc(UUID.randomUUID().toString(), item.getId(), depot.getId(), result.getDistance(), result.getDuration(), Double.MAX_VALUE));
                //rs.add("INSERT INTO dharc (id,s_id,d_id,distance,duration) VALUES ('" + UUID.randomUUID().toString() + "','" + obj.getId() + "','" + item.getId() + "',0,0) ;");

            }

            pullarcService.add(ls);
        }

        //找到第一个出发点

        model.addAttribute("list", rs);
        model.addAttribute("msg", "Bucket Update completed!");
        model.addAttribute("name", "Console");
        return "feedback";
    }

    //生成Dharc
    @RequestMapping(value = "/work", method = RequestMethod.GET)
    private String work(Model model) {

        List<Trip> list = tripService.queryAll();

        List<String> rs = new ArrayList<String>();

        for (int i = 0; i < list.size(); i++) {

            Trip obj = list.get(i);

            //dead
            LatLng orig = new LatLng(obj.getDLat(), obj.getDLng());
            LatLng dest;

            List<Arc> ls = new ArrayList<Arc>();

            for (Trip item : list) {

                //head
                dest = new LatLng(item.getSLat(), item.getSLng());

                if (item.getDeparture().after(obj.getDeparture())) {

                    //Result result = LocationUtils.Distance(UrlDomain.ACTION_DRIVING, orig, dest);
                    //result.getDistance(), result.getDuration()

                    ls.add(new Arc(UUID.randomUUID().toString(), obj.getId(), item.getId(), 0, 0, Double.MAX_VALUE));
                    //rs.add("INSERT INTO dharc (id,s_id,d_id,distance,duration) VALUES ('" + UUID.randomUUID().toString() + "','" + obj.getId() + "','" + item.getId() + "',0,0) ;");

                }
            }

            dharcService.add(ls);
        }

        //找到第一个出发点

        model.addAttribute("list", rs);
        model.addAttribute("msg", "Bucket Update completed!");
        model.addAttribute("name", "Console");
        return "feedback";
    }

    //使用LBS查询Dharc的Distance和Duration
    @RequestMapping(value = "/update", method = RequestMethod.GET)
    private String update(Model model) {

        List<Arc> list = dharcService.queryAll();

        List<String> accessKey = LocationUtils.getAccessKey();

        for (Arc item : list) {

            //dead
            Trip dead = tripService.getModel(item.getSId());
            LatLng orig = new LatLng(dead.getDLat(), dead.getDLng());

            //head
            Trip head = tripService.getModel(item.getDId());
            LatLng dest = new LatLng(head.getSLat(), head.getSLng());

            if (accessKey.size() > 0) {

                String ak = accessKey.get(0);

                Result result = LocationUtils.Distance(ak, UrlDomain.ACTION_DRIVING, orig, dest);

                if (result.getDistance() < 0) {
                    accessKey.remove(ak);
                } else {
                    dharcService.update(new Arc(UUID.randomUUID().toString(), dead.getId(), head.getId(), result.getDistance(), result.getDuration(), Double.MAX_VALUE));
                }
            } else {
                break;
            }
        }

        //找到第一个出发点

        model.addAttribute("msg", "Bucket Update completed!");
        model.addAttribute("name", "Console");
        return "feedback";
    }

    @RequestMapping(value = "/prune", method = RequestMethod.GET)
    private String prune(Model model) {

        List<Trip> tripList = tripService.queryAll();
        List<Arc> list = dharcService.queryAll();
        List<String> arcList = new ArrayList<String>();

        for (Arc arc : list) {

            //找到出发时间
            Trip s_trip = tripList.stream().filter(x -> x.getId().equals(arc.getSId())).collect(Collectors.toList()).get(0);
            Trip d_trip = tripList.stream().filter(x -> x.getId().equals(arc.getDId())).collect(Collectors.toList()).get(0);

            Date departure = TimeUtils.getTimePlusSeconds(s_trip.getDeparture(), s_trip.getDuration());

            //判断这个顶点是否逾期
            if (TimeUtils.getTimePlusSeconds(departure, arc.getDuration()).after(d_trip.getDeparture())) {
                arcList.add(arc.getId());
                System.out.println(arcList.size() + ":" + new Date());
            }
        }

        if (arcList.size() > 0) {
            dharcService.delete(arcList);
        }

        model.addAttribute("msg", "Bucket Update completed!");
        model.addAttribute("name", "Console");
        return "feedback";
    }

    @RequestMapping(value = "/updatecost", method = RequestMethod.GET)
    private String updatecost(Model model) {

        List<Arc> dharcList = dharcService.queryAll();

        for (Arc item : dharcList) {
            Date dp1 = tripService.getModel(item.getSId()).getDeparture();
            Date dp2 = tripService.getModel(item.getDId()).getDeparture();
            long timeDiff = getTimeDifference(dp1, dp2);
            long duration = (long) item.getDuration();

            if (timeDiff > duration) {
                double driveCost = (timeDiff - duration) * wage;
                double vehicleCost = item.getDistance() * fuel;
                double totalCost = vehicleCost + driveCost;
                dharcService.updateCost(item.getId(), Math.min(totalCost, rent));
            }
        }

        model.addAttribute("msg", "Price Update completed!");
        model.addAttribute("name", "Console");
        return "feedback";
    }

    @RequestMapping(value = "/sa", method = RequestMethod.GET)
    private String sa(Model model) {

        long begin = TimeUtils.getCurrentTimeOfSeconds();

        //获得所有集合
        List<Location> depotList = depotService.queryAll();
        LinkedList<Arc> dharcList = dharcService.queryAll();
        LinkedList<Arc> pullarcList = pullarcService.queryAll();

        //随机创建一个解
        List<List<Trip>> xZero = solutionGenerator(depotList, dharcList, pullarcList);

        double tZero = 140;
        double alpha = 0.98;
        int m = 40;
        int n = 25;

        double t = tZero;
        List<List<Trip>> x = xZero;
        List<List<Trip>> xFinal = xZero;

        int global = func(x, depotList, dharcList, pullarcList);

        Random ranat = new Random();
        for (int i = 1; i <= m; i++) {

            for (int j = 1; j <= n; j++) {
                int min = Integer.MAX_VALUE;
                List<List<Trip>> xTemp = solutionGenerator(depotList, dharcList, pullarcList);

                int temp = func(xTemp, depotList, dharcList, pullarcList);

                if (temp <= global) {
                    min = temp;
                    x = xTemp;
                } else {
                    if (ranat.nextGaussian() <= metroPol(temp, global, t)) {
                        min = temp;
                        x = xTemp;
                    }
                }
                if (min <= global) {
                    xFinal = x;
                    global = min;
                }
            }
            t = t * alpha;
        }

        for (List<Trip> trips : xFinal) {

            List<String> sequence = new ArrayList<String>();

            String depot_id = queryDepot(trips, depotList, pullarcList).getId();

            for (Trip trip : trips) {
                sequence.add(trip.getId());
            }

            //添加
            sequenceService.write(depot_id, sequence);

            //移除
            tripService.delete(sequence);
        }

        long end = TimeUtils.getCurrentTimeOfSeconds();

        model.addAttribute("msg", end - begin);
        return "feedback";
    }

    @RequestMapping(value = "/genetic", method = RequestMethod.GET)
    private String genetic(Model model) {

        long begin = TimeUtils.getCurrentTimeOfSeconds();

        //获得所有集合
        List<Location> depotList = depotService.queryAll();
        LinkedList<Arc> dharcList = dharcService.queryAll();
        LinkedList<Arc> pullarcList = pullarcService.queryAll();

        //初始化一个种群(10条染色体)
        for (int i = 0; i < ChrNum; i++) {
            ipop[i] = new Solution(solutionGenerator(depotList, dharcList, pullarcList));
        }

        //迭代次数
        for (int j = 0; j < 90; j++) {
            System.out.println(j + ":" + new Date());
            select(depotList, dharcList, pullarcList);
            cross();
            mutation(depotList, dharcList, pullarcList);
            generation = j;

            sequenceService.truncate();

            for (List<Trip> trips : beststr.getTrip()) {
                List<String> sequence = new ArrayList<String>();
                String depot_id = queryDepot(trips, depotList, pullarcList).getId();
                for (Trip trip : trips) {
                    sequence.add(trip.getId());
                }
                sequenceService.write(depot_id, sequence);
            }
        }

        long end = TimeUtils.getCurrentTimeOfSeconds();

        model.addAttribute("msg", end - begin);
        return "feedback";
    }

    public void cross() {
        for (int i = 0; i < ipop.length; i++) {
            int n = (int) (Math.random() * ipop.length);// 染色体号

            temp = new ArrayList();

            temp.addAll(ipop[i].getTrip());
            temp.addAll(ipop[n].getTrip());

            Collections.shuffle(temp);
            temp1 = setPartitioning2(temp);

            Collections.shuffle(temp);
            temp2 = setPartitioning2(temp);

            ipop[i] = new Solution(temp1);
            ipop[n] = new Solution(temp2);
        }
    }

    public void mutation(List<Location> depotList, LinkedList<Arc> dharcList, LinkedList<Arc> pullarcList) {
        //for (int i = 0; i < 1; i++) {
            int n = (int) (Math.random() * ipop.length);// 染色体号
            ipop[n] = new Solution(solutionGenerator(depotList, dharcList, pullarcList));
        //}
    }

    public void select(List<Location> depotList, LinkedList<Arc> dharcList, LinkedList<Arc> pullarcList) {

        // 所有染色体适应值
        double evals[] = new double[ChrNum];

        // 各染色体选择概率
        double[] p = new double[ChrNum];

        // 累计概率
        double[] q = new double[ChrNum];

        // 累计适应值总和
        double F = 0;

        for (int i = 0; i < ChrNum; i++) {

            evals[i] = func(ipop[i].getTrip(), depotList, dharcList, pullarcList);

            if (evals[i] < bestfitness && evals[i] > 0) {
                // 记录下种群中的最小值，即最优解
                bestfitness = evals[i];
                bestgenerations = generation;
                beststr = new Solution(ipop[i].getTrip());
            }

            if (evals[i] > 0) {
                F = F + (1 / evals[i]); // 所有染色体适应值总和
            }
        }

        for (int i = 0; i < ChrNum; i++) {
            if (evals[i] > 0)
                p[i] = ((1 / evals[i]) / F);
            else p[i] = 0.0;

            if (i == 0)
                q[i] = p[i];
            else {
                q[i] = q[i - 1] + p[i];
            }
        }

        Solution[] newpop = new Solution[ChrNum];

        for (int i = 0; i < ChrNum; i++) {
            double r = Math.random();
            for (int j = 0; j < ChrNum; j++) {
                if (r < q[j]) {
                    newpop[i] = ipop[j];
                    break;
                }
            }
        }

        ipop = newpop;
    }

    @RequestMapping(value = "/run", method = RequestMethod.GET)
    private String run(Model model) {

        long begin = TimeUtils.getCurrentTimeOfSeconds();

        int n = 100;

        //获得所有集合
        List<Trip> tripList = tripService.queryAll();
        List<Location> depotList = depotService.queryAll();
        LinkedList<Arc> dharcList = dharcService.queryAll();
        LinkedList<Arc> pullarcList = pullarcService.queryAll();

        Date time;
        List<Duty> duties;
        List<String> sequence;

        while (tripList.size() > 0) {

            System.out.println(tripList.size() + "-0:" + new Date());

            //FCFS
            time = tripList.stream().min(Comparator.comparing(Trip::getDeparture)).get().getDeparture();

            //RANDOM SEARCH
            //time = timetableGenerator(tripList);

            duties = new ArrayList<Duty>();

            ForkJoinPool forkJoinPool = new ForkJoinPool();
            SeqGeneratorTask task = new SeqGeneratorTask(1, n, time, tripList, depotList, dharcList, pullarcList);

            //执行一个任务
            ForkJoinTask<List<Duty>> forkJoinTask = forkJoinPool.submit(task);

            try {
                duties = forkJoinTask.get();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }

            System.out.println(tripList.size() + "-1:" + new Date());

            if (!duties.isEmpty()) {

                //集合划分
                List<Duty> result = setPartitioning(duties);

                List<Trip> delList = new ArrayList<Trip>();

                //加入正式库
                for (Duty item : result) {

                    sequence = new ArrayList<String>();

                    for (Trip trip : item.getTrip()) {
                        sequence.add(trip.getId());
                    }

                    //添加
                    sequenceService.write(item.getDepotId(), sequence);

                    //移除
                    tripService.delete(sequence);

                    //添加
                    delList.addAll(item.getTrip());
                }

                Set<Arc> des = new TreeSet<>();

                //删除
                for (Trip item : delList) {

                    //移除
                    tripList.remove(item);

                    //查找
                    des.addAll(dharcList.stream().filter(x -> x.getSId().equals(item.getId()) || x.getDId().equals(item.getId())).collect(Collectors.toSet()));
                }

                //移除
                dharcList = deWeightListByNewList(des, dharcList);
            }
        }

        long end = TimeUtils.getCurrentTimeOfSeconds();

        model.addAttribute("msg", end - begin);
        return "feedback";
    }

    public static LinkedList<Arc> deWeightListByNewList(Set<Arc> des, LinkedList<Arc> sourse) {

        Iterator<Arc> listStr = sourse.iterator();

        LinkedList<Arc> existList = new LinkedList<Arc>();

        while (listStr.hasNext()) {
            Arc item = listStr.next();
            if (!des.contains(item)) {
                existList.add(item);
            }
        }

        sourse.clear();
        sourse = existList;
        return sourse;
    }

    @RequestMapping(value = "/display", method = RequestMethod.GET)
    private String display(Model model) {

        List<Duty> list = new ArrayList<Duty>();

        Double duration = 0.0, waitTime = 0.0, travelTime = 0.0, idleTime = 0.0, travelMileage = 0.0, idleMileage = 0.0, travelCost = 0.0, idleCost = 0.0, totalCost = 0.0, originalCost = 0.0;

        List<Location> depotList = depotService.queryAll();
        LinkedList<Arc> dharcList = dharcService.queryAll();
        LinkedList<Arc> pullarcList = pullarcService.queryAll();

        int max = sequenceService.querySequenceNo();

        for (int i = 1; i < max + 1; i++) {

            List<Trip> trips = tripService.querySequence(i);

            Collections.sort(trips);

            Duty duty = dutyGenerator(trips, depotList, pullarcList, dharcList);

            list.add(duty);

            originalCost += originalCostGenerator(trips, depotList, pullarcList);
            duration += duty.getDuration();
            waitTime += duty.getWaitTime();
            travelTime += duty.getTravelTime();
            idleTime += duty.getIdleTime();
            travelMileage += duty.getTravelMileage();
            idleMileage += duty.getIdleMileage();
            travelCost += duty.getTravelCost();
            idleCost += duty.getIdleCost();
            totalCost += duty.getTotalCost();
        }

        totalCost += max * rent;

        model.addAttribute("list", list);
        model.addAttribute("msg", "Vehicle And Crew Scheduling Timetable");
        model.addAttribute("name", "Vehicles:[" + max + "]&nbsp;  Duration:[" + duration / 3600 + "]&nbsp;  Wait Time:[" + waitTime / 3600 + "]&nbsp;  Travel Time:[" + travelTime / 3600 + "]&nbsp;  Idle Time:[" + idleTime / 3600 + "]&nbsp;  Travel Mileage:[" + travelMileage / 1000 + "]&nbsp;  Idle Mileage:[" + idleMileage / 1000 + "]&nbsp;  Travel Cost:[" + travelCost / 1000 + "]&nbsp;  Idle Cost:[" + idleCost / 1000 + "]&nbsp;  Total Cost:[" + totalCost / 1000 + "]&nbsp;  Original Cost:[" + originalCost / 1000 + "]");
        return "feedback";
    }

    @RequestMapping(value = "/combination", method = RequestMethod.GET)
    private String combination(Model model) {

        java.text.NumberFormat nf = java.text.NumberFormat.getInstance();
        //

        //List<Time> timetable = tripService.getTimetable();

        //int m = timetable.size();

        int m = 9;

        for (int i = 1; i <= m - 1; i++) {

            int sum = 0;
            //List<Integer> list = dharcService.queryArcNum(timetable.get(i));

            for (int j = 1; j <= i; j++) {

                sum += combin(i, j) * Math.pow(20, j);
            }

            System.out.println(nf.format(sum));
        }

        //model.addAttribute("msg", sum);
        return "feedback";
    }

    private int combin(int n, int m) {
        if (n == m) {
            return 1;
        } else {
            return clac(n) / (clac(m) * clac(n - m));
        }
    }

    private int clac(int n) {
        if (n == 1) {
            return 1;
        } else {
            return n * (clac(n - 1));
        }
    }

    private Date timetableGenerator(List<Trip> tripList) {

        List<Timetable> timetable = new ArrayList<Timetable>();

        List<Date> tt = new ArrayList<Date>();

        for (Trip item : tripList) {
            if (!tt.contains(item.getDeparture()))
                tt.add(item.getDeparture());
        }

        //取得最后一个时间
        Date end_time = TimeUtils.getTimePlusSeconds(new Date(2019, 5, 6, 23, 0, 0), 2451);

        //先求和
        long sum = 0;

        for (Date item : tt) {
            sum += getTimeDifference(item, end_time);
        }

        for (Date item : tt) {
            double probability = getTimeDifference(item, end_time) * 10000 / sum;
            timetable.add(new Timetable(item, probability));
        }

        //排序
        Collections.sort(timetable);

        double bound = 0;

        for (Timetable item : timetable) {

            item.setMin(bound);

            bound += item.getProbability();

            item.setMax(bound);
        }

        //排序
        Collections.sort(timetable);

        double max = timetable.get(0).getMax();
        double min = timetable.get(timetable.size() - 1).getMin();

        Double seed = Math.random() * (max - min);

        Date time = timetable.stream().filter(x -> x.getMin() <= seed && seed < x.getMax()).collect(Collectors.toList()).get(0).getDepartureDt();

        return time;
    }

    private int func(List<List<Trip>> list, List<Location> depotList, LinkedList<Arc> dharcList, LinkedList<Arc> pullarcList) {

        int totalCost = (int) (list.size() * rent);

        for (List<Trip> trips : list) {
            Duty duty = dutyGenerator(trips, depotList, pullarcList, dharcList);
            totalCost += duty.getTotalCost();
        }

        return totalCost;
    }

    static double metroPol(double z1, double z2, double temperature) {//Metropolis statement
        double res = Math.pow(Math.E, -((z1 - z2) / temperature));
        return res;
    }

    private List<List<Trip>> sequenceGenerator(Date time, List<Location> depotList, LinkedList<Arc> dharcList, LinkedList<Arc> pullarcList) {

        List<Trip> temp = tripService.queryAll();

        List<List<Trip>> list = new ArrayList();

        while (temp.size() > 0) {
            List<Trip> trips = new ArrayList();
            List<Duty> duties = new ArrayList();

            //构建时间段最前的顶点
            List<Trip> vertices = temp.stream().filter(x -> x.getDeparture().equals(time)).collect(Collectors.toList());

            //遍历每一个顶点
            for (Trip vertex : vertices) {

                trips.add(vertex);

                while (true) {

                    String id = vertex.getId();

                    //获得当前起点的所有边
                    List<Arc> arcs = dharcList.stream().filter(x -> x.getSId().equals(id)).collect(Collectors.toList());

                    //触底，则跳出；没有，则继续。
                    if (arcs.size() > 0) {

                        //随机选择一个边
                        for (Arc arc : arcs) {
                            //候选一个顶点
                            vertex = temp.stream().filter(x -> x.getId().equals(arc.getDId())).collect(Collectors.toList()).get(0);

                            //放入顶点集
                            trips.add(vertex);
                        }

                    } else {
                        //跳出循环
                        break;
                    }
                }

                //生成工作时间
                long duration = durationGenerator(trips, depotList, pullarcList);

                //对工作时间进行可行性判断
                while (duration > max_working_time) {

                    //修剪
                    trips.remove(trips.size() - 1);

                    //行程序列分析报告
                    duration = durationGenerator(trips, depotList, pullarcList);
                }

                Duty duty = dutyGenerator(trips, depotList, pullarcList, dharcList);

                //加入到候选集
                if (!duties.contains(duty)) {
                    duties.add(duty);
                }

                if (!duties.isEmpty()) {

                    //集合划分
                    List<Duty> result = setPartitioning(duties);

                    List<Trip> delList = new ArrayList<Trip>();

                    //加入正式库
                    for (Duty item : result) {

                        List<String> sequence = new ArrayList<String>();

                        for (Trip trip : item.getTrip()) {
                            sequence.add(trip.getId());
                        }

                        //添加
                        delList.addAll(item.getTrip());

                        //提交
                        list.add(item.getTrip());
                    }

                    Set<Arc> des = new TreeSet<>();

                    //删除
                    for (Trip item : delList) {

                        //移除
                        temp.remove(item);

                        //查找
                        des.addAll(dharcList.stream().filter(x -> x.getSId().equals(item.getId()) || x.getDId().equals(item.getId())).collect(Collectors.toSet()));
                    }

                    //移除
                    dharcList = deWeightListByNewList(des, dharcList);
                }
            }

        }
        return list;
    }

    private List<List<Trip>> solutionGenerator(List<Location> depotList, LinkedList<Arc> dharcList, LinkedList<Arc> pullarcList) {

        trip = tripService.queryAll();

        tripList = new ArrayList();

        while (trip.size() > 0) {

            Date time = trip.stream().min(Comparator.comparing(Trip::getDeparture)).get().getDeparture();

            List<Trip> trips = new ArrayList();
            List<Duty> duties = new ArrayList();

            //构建时间段最前的顶点
            List<Trip> vertices = trip.stream().filter(x -> x.getDeparture().equals(time)).collect(Collectors.toList());

            //随机选择一个顶点
            Trip vertex = vertices.get(new Random().nextInt(vertices.size()));
            trips.add(vertex);

            while (true) {

                String id = vertex.getId();

                //获得当前起点的所有边
                List<Arc> arcs = dharcList.stream().filter(x -> x.getSId().equals(id)).collect(Collectors.toList());

                //触底，则跳出；没有，则继续。
                if (arcs.size() > 0) {

                    //随机选择一个边
                    Arc arc = arcs.get(new Random().nextInt(arcs.size()));

                    //候选一个顶点
                    vertex = trip.stream().filter(x -> x.getId().equals(arc.getDId())).collect(Collectors.toList()).get(0);

                    //放入顶点集
                    trips.add(vertex);

                } else {
                    //跳出循环
                    break;
                }
            }

            //生成工作时间
            long duration = durationGenerator(trips, depotList, pullarcList);

            //对工作时间进行可行性判断
            while (duration > max_working_time) {

                //修剪
                trips.remove(trips.size() - 1);

                //行程序列分析报告
                duration = durationGenerator(trips, depotList, pullarcList);
            }

            Duty duty = dutyGenerator(trips, depotList, pullarcList, dharcList);

            //加入到候选集
            if (!duties.contains(duty)) {
                duties.add(duty);
            }

            if (!duties.isEmpty()) {

                //集合划分
                List<Duty> result = setPartitioning(duties);

                List<Trip> delList = new ArrayList<Trip>();

                //加入正式库
                for (Duty item : result) {

                    List<String> sequence = new ArrayList<String>();

                    for (Trip trip : item.getTrip()) {
                        sequence.add(trip.getId());
                    }

                    //添加
                    delList.addAll(item.getTrip());

                    //提交
                    tripList.add(item.getTrip());
                }

                Set<Arc> des = new TreeSet<>();

                //删除
                for (Trip item : delList) {

                    //移除
                    trip.remove(item);

                    //查找
                    des.addAll(dharcList.stream().filter(x -> x.getSId().equals(item.getId()) || x.getDId().equals(item.getId())).collect(Collectors.toSet()));
                }

                //移除
                dharcList = deWeightListByNewList(des, dharcList);
            }
        }

        return tripList;
    }

    private long durationGenerator(List<Trip> list, List<Location> depotList, LinkedList<Arc> pullarcList) {
        //排序
        Collections.sort(list);

        Trip first = list.get(0);
        Trip last = list.get(list.size() - 1);

        String depot_id = queryDepot(list, depotList, pullarcList).getId();

        //构建出场的边
        Arc pull_out = pullarcList.stream().filter(x -> x.getSId().equals(depot_id) && x.getDId().equals(first.getId())).collect(Collectors.toList()).get(0);
        Arc pull_in = pullarcList.stream().filter(x -> x.getSId().equals(last.getId()) && x.getDId().equals(depot_id)).collect(Collectors.toList()).get(0);

        Date start_time = TimeUtils.getTimeMinusSeconds(first.getDeparture(), pull_out.getDuration());
        Date last_time = TimeUtils.getTimePlusSeconds(last.getDeparture(), last.getDuration());
        Date end_time = TimeUtils.getTimePlusSeconds(last_time, pull_in.getDuration());
        long duration = getTimeDifference(start_time, end_time);

        return duration;
    }

    private Duty dutyGenerator(List<Trip> list, List<Location> depotList, LinkedList<Arc> pullarcList, LinkedList<Arc> dharcList) {

        //排序
        Collections.sort(list);

        Trip first = list.get(0);
        Trip last = list.get(list.size() - 1);

        String depot_id = queryDepot(list, depotList, pullarcList).getId();

        //构建出场的边
        Arc pull_out = pullarcList.stream().filter(x -> x.getSId().equals(depot_id) && x.getDId().equals(first.getId())).collect(Collectors.toList()).get(0);
        Arc pull_in = pullarcList.stream().filter(x -> x.getSId().equals(last.getId()) && x.getDId().equals(depot_id)).collect(Collectors.toList()).get(0);

        Date start_time = TimeUtils.getTimeMinusSeconds(first.getDeparture(), pull_out.getDuration());
        Date last_time = TimeUtils.getTimePlusSeconds(last.getDeparture(), last.getDuration());
        Date end_time = TimeUtils.getTimePlusSeconds(last_time, pull_in.getDuration());
        long duration = getTimeDifference(start_time, end_time);

        //实际时间消耗
        int travelTime = 0;
        int idleTime = pull_out.getDuration() + pull_in.getDuration();
        int travelMileage = 0;
        int idleMileage = pull_out.getDistance() + pull_in.getDistance();
        Double travelCost = 0.0;
        Double idleCost = pull_out.getCost() + pull_in.getCost();
        List<Arc> arcs = new ArrayList<Arc>();

        //构建边
        for (int i = 0; i < list.size() - 1; i++) {
            Trip prior = list.get(i);
            Trip next = list.get(i + 1);
            arcs.addAll(dharcList.stream().filter(x -> x.getSId().equals(prior.getId()) && x.getDId().equals(next.getId())).collect(Collectors.toList()));
        }

        for (Arc item : arcs) {
            idleMileage += item.getDistance();
            idleTime += item.getDuration();
            idleCost += item.getCost();
        }

        for (Trip item : list) {
            travelMileage += item.getDistance();
            travelTime += item.getDuration();
            travelCost += item.getCost();
        }

        Double totalCost = travelCost + idleCost;

        return new Duty(depot_id, list, arcs, start_time, end_time, duration, (int) duration - travelTime - idleTime, travelTime, idleTime, travelMileage, idleMileage, travelCost, idleCost, totalCost);
    }

    private Location queryDepot(List<Trip> list, List<Location> depotList, LinkedList<Arc> pullarcList) {

        Trip first = list.get(0);
        Trip last = list.get(list.size() - 1);

        List<Double> cost = new ArrayList<Double>();

        for (Location item : depotList) {
            Arc pull_out = pullarcList.stream().filter(x -> x.getSId().equals(item.getId()) && x.getDId().equals(first.getId())).collect(Collectors.toList()).get(0);
            Arc pull_in = pullarcList.stream().filter(x -> x.getSId().equals(last.getId()) && x.getDId().equals(item.getId())).collect(Collectors.toList()).get(0);
            cost.add(pull_out.getCost() + pull_in.getCost());
        }

        double min = Collections.min(cost);

        return depotList.get(cost.indexOf(min));
    }

    private Double originalCostGenerator(List<Trip> list, List<Location> depotList, LinkedList<Arc> pullarcList) {

        Double totalCost = 0.0;

        String depot_id = queryDepot(list, depotList, pullarcList).getId();

        for (Trip item : list) {

            Arc pull_out = pullarcList.stream().filter(x -> x.getSId().equals(depot_id) && x.getDId().equals(item.getId())).collect(Collectors.toList()).get(0);
            Arc pull_in = pullarcList.stream().filter(x -> x.getSId().equals(item.getId()) && x.getDId().equals(depot_id)).collect(Collectors.toList()).get(0);

            totalCost += pull_out.getCost();
            totalCost += item.getCost();
            totalCost += pull_in.getCost();
        }

        totalCost += list.size() * rent;

        return totalCost;
    }

    private List<Duty> setPartitioning(List<Duty> list) {

        List<Duty> delList = new ArrayList<Duty>();
        List<Trip> tabuList = new ArrayList<Trip>();

        //排序
        Collections.sort(list);

        for (Duty duty : list) {
            for (Trip trip : duty.getTrip()) {
                if (tabuList.contains(trip)) {
                    if (!delList.contains(duty)) {
                        delList.add(duty);
                    }
                }
            }

            if (!delList.contains(duty)) {
                tabuList.addAll(duty.getTrip());
            }
        }

        list.removeAll(delList);

        return list;
    }

    private List<List<Trip>> setPartitioning2(List<List<Trip>> list) {

        List<List<Trip>> delList = new ArrayList();
        List<Trip> tabuList = new ArrayList();

        for (List<Trip> trips : list) {
            for (Trip trip : trips) {
                if (tabuList.contains(trip)) {
                    if (!delList.contains(trips)) {
                        delList.add(trips);
                    }
                }
            }

            if (!delList.contains(trips)) {
                tabuList.addAll(trips);
            }
        }

        list.removeAll(delList);

        return list;
    }
}
