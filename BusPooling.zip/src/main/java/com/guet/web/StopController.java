package com.guet.web;

import com.guet.core.UrlDomain;
import com.guet.entity.BusShare;
import com.guet.entity.LatLng;
import com.guet.entity.RecommendStops;
import com.guet.entity.Result;
import com.guet.service.BucketService;
import com.guet.service.BusShareService;
import com.guet.service.StopService;

import com.guet.util.LocationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static com.guet.util.LocationUtils.AccessKey;
import static com.guet.util.LocationUtils.getAccessKey;

@Controller
@RequestMapping(value = "/Stop", method = RequestMethod.GET)
public class StopController {
    @Autowired
    private BusShareService busShareService;

    @Autowired
    private BucketService bucketService;

    @Autowired
    private StopService stopService;
    @RequestMapping(value = "/Add", method = RequestMethod.GET)
    private String add(Model model) {
        List<BusShare> busShareList;
        List<LatLng> origList;
        List<LatLng> destList;

        int max = bucketService.queryBucketNo();

        for (int i = 1; i <= max; i++) {

            busShareList = busShareService.getList(i);

            origList = new ArrayList();
            destList = new ArrayList();

            for (BusShare item : busShareList) {
                origList.add(new LatLng(item.getSLat(), item.getSLng()));
                destList.add(new LatLng(item.getDLat(), item.getDLng()));
            }

            LatLng origStop = LocationUtils.getCircleSearch(origList).getLatLng();
            LatLng destStop = LocationUtils.getCircleSearch(destList).getLatLng();

            stopService.add(new RecommendStops(
                    UUID.randomUUID().toString(), i,0,
                    origStop.getLongitude(), origStop.getLatitude(),
                    destStop.getLongitude(), destStop.getLatitude(),
                    0, 0
            ));
        }

        model.addAttribute("msg", "Stop Add completed!");
        model.addAttribute("name", "Console");

        return "feedback";
    }

    @RequestMapping(value = "/Fix", method = RequestMethod.GET)
    private String fix(Model model) {
        List<RecommendStops> list = stopService.queryAll();
        LatLng test = new LatLng(31.193913, 121.5512);

        for (RecommendStops item : list) {
            LatLng orig = new LatLng(item.getSLat(), item.getSLng());
            LatLng dest = new LatLng(item.getDLat(), item.getDLng());

            int dist1 = LocationUtils.Distance(AccessKey,UrlDomain.ACTION_RIDING, orig, test).getDistance();
            int dist2 = LocationUtils.Distance(AccessKey,UrlDomain.ACTION_RIDING, dest, test).getDistance();

            if (dist1 <= 0) {
                LatLng orig1;
                int i = 0;
                do {
                    orig1 = LocationUtils.GetRandomLocation(orig, i * 10);
                    dist1 = LocationUtils.Distance(AccessKey,UrlDomain.ACTION_RIDING, orig1, test).getDistance();
                    i++;
                } while (dist1 <= 0);
                stopService.updateOrig(item.getId(), orig1.getLongitude(), orig1.getLatitude());
            }

            if (dist2 <= 0) {
                LatLng dest1;
                int i = 0;
                do {
                    dest1 = LocationUtils.GetRandomLocation(orig, i * 10);
                    dist1 = LocationUtils.Distance(AccessKey,UrlDomain.ACTION_RIDING, dest1, test).getDistance();
                    i++;
                } while (dist1 <= 0);
                stopService.updateDest(item.getId(), dest1.getLongitude(), dest1.getLatitude());
            }
        }

        model.addAttribute("msg", "GetRecommendStop completed!");
        model.addAttribute("name", "Console");

        return "feedback";
    }

    @RequestMapping(value = "/Add1", method = RequestMethod.GET)
    private String add1(Model model) {

        List<BusShare> busShareList;
        List<LatLng> origList;
        List<LatLng> destList;

        int max = bucketService.queryBucketNo();

        for (int i = 1; i <= max; i++) {

            busShareList = busShareService.getList(i);

            origList = new ArrayList();
            destList = new ArrayList();

            for (BusShare item : busShareList) {
                origList.add(new LatLng(item.getSLat(), item.getSLng()));
                destList.add(new LatLng(item.getDLat(), item.getDLng()));
            }

            LatLng origStop = LocationUtils.getTerminal(origList).getLatLng();
            LatLng destStop = LocationUtils.getTerminal(destList).getLatLng();

            stopService.add(new RecommendStops(
                    UUID.randomUUID().toString(), i,0,
                    origStop.getLongitude(), origStop.getLatitude(),
                    destStop.getLongitude(), destStop.getLatitude(),
                    0, 0
            ));
        }

        model.addAttribute("msg", "Stop Add completed!");
        model.addAttribute("name", "Console");

        return "feedback";
    }

    @RequestMapping(value = "/Add2", method = RequestMethod.GET)
    private String add2(Model model) {

        List<BusShare> busShareList;
        List<LatLng> origList;
        List<LatLng> destList;

        int max = bucketService.queryBucketNo();

        for (int i = 1; i <= max; i++) {

            busShareList = busShareService.getList(i);

            origList = new ArrayList();
            destList = new ArrayList();

            for (BusShare item : busShareList) {
                origList.add(new LatLng(item.getSLat(), item.getSLng()));
                destList.add(new LatLng(item.getDLat(), item.getDLng()));
            }

            LatLng origStop = LocationUtils.getCircleSearch(origList).getLatLng();
            LatLng destStop = LocationUtils.getCircleSearch(destList).getLatLng();

            stopService.add(new RecommendStops(
                    UUID.randomUUID().toString(), i,0,
                    origStop.getLongitude(), origStop.getLatitude(),
                    destStop.getLongitude(), destStop.getLatitude(),
                    0, 0
            ));
        }

        model.addAttribute("msg", "Stop Add completed!");
        model.addAttribute("name", "Console");

        return "feedback";
    }

    @RequestMapping(value = "/GetRecommendStop", method = RequestMethod.GET)
    private String getRecommendStop(Model model) {

        List<RecommendStops> list = stopService.queryAll();

        for (RecommendStops item : list) {

            List<LatLng> origStopList = LocationUtils.getRecommendStops(AccessKey,new LatLng(item.getSLat(), item.getSLng()));
            List<LatLng> destStopList = LocationUtils.getRecommendStops(AccessKey,new LatLng(item.getDLat(), item.getDLng()));

            if (origStopList.size() > 0) {
                LatLng origStop = bucketService.getMinDistanceStop(origStopList);
                stopService.updateOrig(item.getId(), origStop.getLongitude(), origStop.getLatitude());
            }

            if (destStopList.size() > 0) {
                LatLng destStop = bucketService.getMinDistanceStop(destStopList);
                stopService.updateDest(item.getId(), destStop.getLongitude(), destStop.getLatitude());
            }
        }

        model.addAttribute("msg", "GetRecommendStop completed!");
        model.addAttribute("name", "Console");

        return "feedback";
    }

    @RequestMapping(value = "/Update", method = RequestMethod.GET)
    private String Update(Model model) {
        List<RecommendStops> list = stopService.queryAll();

        for (RecommendStops item : list) {
            LatLng pickup = new LatLng(item.getSLat(), item.getSLng());
            LatLng delivery = new LatLng(item.getDLat(), item.getDLng());

            Result result = LocationUtils.Distance(AccessKey,UrlDomain.ACTION_DRIVING, pickup, delivery);

            stopService.updateDistance(item.getId(), result.getDistance(), result.getDuration());
        }

        model.addAttribute("msg", "Stop Update completed!");
        model.addAttribute("name", "Console");

        return "feedback";
    }

    @RequestMapping(value = "/Statistics", method = RequestMethod.GET)
    private String Statistics(Model model) {
        List<BusShare> busShareList;
        List<LatLng> origList;
        List<LatLng> destList;

        for (int i = 0; i < 51; i++) {

            busShareList = busShareService.getList(i);

            origList = new ArrayList();
            destList = new ArrayList();

            for (BusShare item : busShareList) {
                origList.add(new LatLng(item.getSLat(), item.getSLng()));
                destList.add(new LatLng(item.getDLat(), item.getDLng()));
            }

            RecommendStops recommendStops = stopService.getModel(i);

            LatLng origStop = new LatLng(recommendStops.getSLat(), recommendStops.getSLng());
            LatLng destStop = new LatLng(recommendStops.getDLat(), recommendStops.getSLng());

            int score1 = 0;
            for (LatLng orig : origList) {
                score1 += LocationUtils.Distance(AccessKey,UrlDomain.ACTION_RIDING, orig, origStop).getDistance();
            }

            int score2 = 0;
            for (LatLng dest : destList) {
                score2 += LocationUtils.Distance(AccessKey,UrlDomain.ACTION_RIDING, dest, destStop).getDistance();
            }

            System.out.println(score1+"/"+score2);
        }

        model.addAttribute("msg", "Stop Add completed!");
        model.addAttribute("name", "Console");

        return "feedback";
    }

    @RequestMapping(value = "/Convergence", method = RequestMethod.GET)
    private String convergence(Model model) {

        List<BusShare> busShareList;
        List<LatLng> origList;
        List<LatLng> destList;
        List<Integer> ls = new ArrayList<>();

        for (int i = 50; i < 51; i++) {

            busShareList = busShareService.getList(i);

            origList = new ArrayList();
            destList = new ArrayList();

            for (BusShare item : busShareList) {
                origList.add(new LatLng(item.getSLat(), item.getSLng()));
                destList.add(new LatLng(item.getDLat(), item.getDLng()));
            }

            LatLng origStop = LocationUtils.getCircleSearch(origList).getLatLng();
            LatLng destStop = LocationUtils.getCircleSearch(destList).getLatLng();

            int score1 = 0;
            for (LatLng orig : origList) {
                score1 += LocationUtils.Distance(AccessKey,UrlDomain.ACTION_RIDING, orig, origStop).getDistance();
            }
            ls.add(score1);
            int score2 = 0;
            for (LatLng dest : destList) {
                score2 += LocationUtils.Distance(AccessKey,UrlDomain.ACTION_RIDING, dest, destStop).getDistance();
            }
            ls.add(score2);

            System.out.println("score:" + score1);
            System.out.println("score:" + score2);
        }

        model.addAttribute("list", ls);
        model.addAttribute("msg", "Stop Add completed!");
        model.addAttribute("name", "Console");

        return "feedback";
    }
}
